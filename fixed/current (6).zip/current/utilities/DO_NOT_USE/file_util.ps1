# --- CONFIGURATION ---
# The root folder of your existing structure where the files are located.
# This script will search recursively starting from here.
$sourceFolderStructureRoot = "C:\Users\jhnhe\Documents\GitHub\pmc-terminal\modular\experimental features\new testgtound\fixed\current"

# The separate folder where files will be copied and renamed.
$destDir = "C:\Users\jhnhe\Documents\GitHub\pmc-terminal\modular\experimental features\new testgtound\fixed\current\Copies"

# Path to the text file listing the filenames to process.
$fileListPath = "C:\Users\jhnhe\Documents\GitHub\pmc-terminal\modular\experimental features\new testgtound\fixed\current\file_list.txt"


#
# === KEY RENAMING SETTINGS ===
#
# The NEW file extension for all processed files.
# IMPORTANT: Include the dot (e.g., ".log", ".txt", ".dat").
$newExtension = ".txt"

# A prefix to add to the renamed files in the destination folder (optional, can be "").
$newPrefix = "Processed_"

#
# === CONCATENATION SETTINGS ===
#
# Set to $true to concatenate the files after renaming, $false otherwise.
# WARNING: This works best for plain text files (.txt, .log, .csv).
# It will corrupt binary files (like .docx, .zip, .jpg).
$doConcatenate = $true

# Name for the final concatenated file (optional).
$concatenatedFile = "all.txt" # Match the new extension if it makes sense

# --- SCRIPT (No need to edit below this line) ---

Write-Host "--- Starting File Processing ---" -ForegroundColor Green

# Get the absolute paths for robustness
try {
    $sourceFolderStructureRoot = (Resolve-Path $sourceFolderStructureRoot -ErrorAction Stop).Path
    $destDir = (Resolve-Path $destDir -ErrorAction Stop).Path
    $fileListPath = (Resolve-Path $fileListPath -ErrorAction Stop).Path
} catch {
    Write-Error "Error resolving paths. Check your configuration variables."
    Write-Error $_.Exception.Message
    Read-Host "Press Enter to exit"; Exit
}

# Read the list of filenames
if (-not (Test-Path $fileListPath)) { Write-Error "File list not found: $fileListPath"; Read-Host "Press Enter to exit"; Exit }
$filesToProcess = Get-Content $fileListPath -ErrorAction Stop
if ($filesToProcess.Count -eq 0) { Write-Warning "File list is empty. Nothing to process."; Read-Host "Press Enter to exit"; Exit }

# Ensure destination directory exists
if (-not (Test-Path $destDir -PathType Container)) {
    Write-Host "Destination directory '$destDir' not found. Creating it..." -ForegroundColor Yellow
    New-Item -Path $destDir -ItemType Directory | Out-Null
}

Write-Host "`n--- Step 1 & 2: Searching, Copying, and Renaming Files ---" -ForegroundColor Green
$renamedFiles = @()

foreach ($fileName in $filesToProcess) {
    Write-Host "Searching for '$fileName'..." -ForegroundColor Cyan
    $foundFiles = Get-ChildItem -Path $sourceFolderStructureRoot -Recurse -Filter $fileName -ErrorAction SilentlyContinue

    if ($null -eq $foundFiles -or $foundFiles.Count -eq 0) {
        Write-Warning "  File '$fileName' not found in the structure."
    } else {
        foreach ($foundFile in $foundFiles) {
            Write-Host "  Found: $($foundFile.FullName)"

            # === NEW RENAMING LOGIC IS HERE ===
            # Get the original filename without its extension
            $baseFileName = $foundFile.BaseName
            # Get the original parent folder name for uniqueness
            $originalParentFolder = $foundFile.Directory.Name
            # Handle edge case where the file is directly in the root folder
            if ($foundFile.Directory.FullName -ceq $sourceFolderStructureRoot) { $originalParentFolder = "" }

            # Construct the new name with the NEW extension
            $baseNewName = if ($originalParentFolder) {
                "$newPrefix${baseFileName}_$originalParentFolder$newExtension"
            } else {
                "$newPrefix$baseFileName$newExtension"
            }
            
            # Copy the file first (we rename the copy)
            try {
                $copiedFile = Copy-Item -Path $foundFile.FullName -Destination $destDir -PassThru -ErrorAction Stop
                
                # Now rename the COPY using the new name we constructed
                $targetRenamePath = Join-Path -Path $destDir -ChildPath $baseNewName
                $renamedFile = Rename-Item -Path $copiedFile.FullName -NewName $targetRenamePath -PassThru -ErrorAction Stop
                
                Write-Host "    Copied and renamed to '$($renamedFile.Name)'"
                $renamedFiles += $renamedFile
            } catch {
                Write-Error "    Error copying or renaming file '$($foundFile.FullName)'"
                Write-Error "    $($_.Exception.Message)"
            }
        }
    }
}

# --- Step 3: (Optional) Concatenate the Files ---
if ($doConcatenate -and $renamedFiles.Count -gt 0) {
    Write-Host "`n--- Step 3: Concatenating Files ---" -ForegroundColor Green
    $concatenatedFilePath = Join-Path -Path $destDir -ChildPath $concatenatedFile
    if (Test-Path $concatenatedFilePath) { Remove-Item -Path $concatenatedFilePath -Force }
    Write-Host "Creating combined file '$concatenatedFile'..."

    # Get the content from all the renamed files and pipe it into one new file
    Get-Content -Path $renamedFiles.FullName | Set-Content -Path $concatenatedFilePath
    
    Write-Host "All processed files have been concatenated into '$concatenatedFilePath'" -ForegroundColor Green
} elseif ($doConcatenate) {
    Write-Warning "`nConcatenation skipped: No files were successfully processed."
}

Write-Host "`n--- Process Complete! ---" -ForegroundColor Green
Read-Host "Press Enter to exit"