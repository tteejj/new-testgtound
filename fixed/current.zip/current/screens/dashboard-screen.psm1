# Dashboard Screen Module
# Main dashboard for PMC Terminal

function global:Get-DashboardScreen {
    $dashboardScreen = @{
        Name = "DashboardScreen"
        State = @{
            ActiveTimers = @()
            TodaysTasks = @()
            RecentEntries = @()
            QuickStats = @{}
            SelectedQuickAction = 0
        }
        
        Init = {
            param($self)
            # Subscribe to data events for real-time updates
            # Note: A robust implementation would store subscription IDs and unsubscribe in an OnExit method.
            Subscribe-Event -EventName "Data.Timer.Started" -Handler { $self.RefreshAllData(); Request-TuiRefresh }
            Subscribe-Event -EventName "Data.Timer.Stopped" -Handler { $self.RefreshAllData(); Request-TuiRefresh }
            Subscribe-Event -EventName "Data.TimeEntry.Created" -Handler { $self.RefreshAllData(); Request-TuiRefresh }
            
            # Initial data load
            $self.RefreshAllData()
        }
        
        Render = {
            param($self)
            
            # Header with current time
            $headerY = 1
            Write-BufferString -X 2 -Y $headerY -Text "PMC Terminal - $(Get-Date -Format 'dddd, MMMM dd, yyyy HH:mm')" -ForegroundColor (Get-ThemeColor "Header")
            
            if ($self.State.ActiveTimers.Count -gt 0) {
                $timerText = "🔴 TIMER ACTIVE"
                Write-BufferString -X ($script:TuiState.BufferWidth - $timerText.Length - 2) -Y $headerY -Text $timerText -ForegroundColor "Red"
            }
            
            # Layout constants
            $leftColX = 2
            $leftColWidth = 28
            $midColX = $leftColX + $leftColWidth
            $midColWidth = 28
            $rightColX = $midColX + $midColWidth
            $rightColWidth = $script:TuiState.BufferWidth - $rightColX - 1
            $contentY = 3
            $boxHeight = $script:TuiState.BufferHeight - $contentY - 3

            # Left Column: Quick Actions & Today's Tasks
            Write-BufferBox -X $leftColX -Y $contentY -Width $leftColWidth -Height 10 -Title " Quick Actions " -BorderColor (Get-ThemeColor "Accent")
            $self.RenderQuickActions($leftColX + 2, $contentY + 2)
            
            Write-BufferBox -X $leftColX -Y ($contentY + 10) -Width $leftColWidth -Height ($boxHeight - 9) -Title " Today's Tasks " -BorderColor (Get-ThemeColor "Warning")
            $self.RenderTodaysTasks($leftColX + 2, $contentY + 12)

            # Middle Column: Active Timers & Recent Entries
            Write-BufferBox -X $midColX -Y $contentY -Width $midColWidth -Height 8 -Title " Active Timers " -BorderColor (Get-ThemeColor "Info")
            $self.RenderActiveTimers($midColX + 2, $contentY + 2)
            
            Write-BufferBox -X $midColX -Y ($contentY + 8) -Width $midColWidth -Height ($boxHeight - 7) -Title " Recent Time Entries " -BorderColor (Get-ThemeColor "Success")
            $self.RenderRecentEntries($midColX + 2, $contentY + 10)

            # Right Column: Quick Stats
            Write-BufferBox -X $rightColX -Y $contentY -Width $rightColWidth -Height $boxHeight -Title " Quick Stats " -BorderColor (Get-ThemeColor "Accent")
            $self.RenderQuickStats($rightColX + 2, $contentY + 2)
            
            # Status bar
            $statusY = $script:TuiState.BufferHeight - 2
            Write-BufferString -X 2 -Y $statusY -Text "↑↓ Select • Enter: Execute • P: Projects • T: Tasks • Q: Quit" -ForegroundColor (Get-ThemeColor "Subtle")
        }
        
        HandleInput = {
            param($self, $Key)
            switch ($Key.Key) {
                ([ConsoleKey]::UpArrow) { 
                    $self.State.SelectedQuickAction = [Math]::Max(0, $self.State.SelectedQuickAction - 1)
                    Request-TuiRefresh
                    return $true 
                }
                ([ConsoleKey]::DownArrow) { 
                    $maxActions = $self.GetQuickActions().Count - 1
                    $self.State.SelectedQuickAction = [Math]::Min($maxActions, $self.State.SelectedQuickAction + 1)
                    Request-TuiRefresh
                    return $true 
                }
                ([ConsoleKey]::Enter) {
                    $selectedAction = $self.GetQuickActions()[$self.State.SelectedQuickAction]
                    & $selectedAction.Action
                    return $true
                }
                ([ConsoleKey]::P) {
                    Show-AlertDialog -Title "Info" -Message "Projects screen not yet implemented."
                    return $true
                }
                ([ConsoleKey]::T) {
                    Show-AlertDialog -Title "Info" -Message "Tasks screen not yet implemented."
                    return $true
                }
                ([ConsoleKey]::Q) { return "Quit" }
            }
            return $false
        }
        
        # Helper methods for data management
        RefreshActiveTimers = {
            $this.State.ActiveTimers = @($Data.ActiveTimers.GetEnumerator() | Sort-Object -Property {$_.Value.StartTime})
        }
        
        RefreshTodaysTasks = {
            $today = (Get-Date).ToString("yyyy-MM-dd")
            $this.State.TodaysTasks = @($Data.Tasks | Where-Object { 
                (-not $_.Completed) -and ($_.DueDate -eq $today)
            } | Sort-Object Priority, DueDate | Select-Object -First 5)
        }
        
        RefreshRecentEntries = {
            $this.State.RecentEntries = @($Data.TimeEntries | 
                Sort-Object { [datetime]$_.Date }, { [datetime]$_.EnteredAt } -Descending | 
                Select-Object -First 7)
        }
        
        RefreshQuickStats = {
            $today = (Get-Date).ToString("yyyy-MM-dd")
            $weekStart = (Get-WeekStart (Get-Date)).ToString("yyyy-MM-dd")
            
            $todayEntries = $Data.TimeEntries | Where-Object { $_.Date -eq $today }
            $weekEntries = $Data.TimeEntries | Where-Object { $_.Date -ge $weekStart }

            $this.State.QuickStats = @{
                TodayHours = ($todayEntries | Measure-Object -Property Hours -Sum).Sum
                WeekHours = ($weekEntries | Measure-Object -Property Hours -Sum).Sum
                ActiveTasks = ($Data.Tasks | Where-Object { -not $_.Completed }).Count
                RunningTimers = $Data.ActiveTimers.Count
            }
        }
        
        RefreshAllData = {
            $this.RefreshActiveTimers()
            $this.RefreshTodaysTasks() 
            $this.RefreshRecentEntries()
            $this.RefreshQuickStats()
        }
        
        GetQuickActions = {
            return @(
                @{ Name = "📝 Add Time Entry"; Action = { Show-AlertDialog -Title "Info" -Message "Add Time Entry screen not yet implemented." } }
                @{ Name = "⏱️ Start Timer"; Action = { Show-AlertDialog -Title "Info" -Message "Start Timer screen not yet implemented." } }
                @{ Name = "📋 Add Task"; Action = { Show-AlertDialog -Title "Info" -Message "Add Task screen not yet implemented." } }
                @{ Name = "📊 View Reports"; Action = { Show-AlertDialog -Title "Info" -Message "Reports screen not yet implemented." } }
                @{ Name = "⚙️ Settings"; Action = { Show-AlertDialog -Title "Info" -Message "Settings screen not yet implemented." } }
            )
        }
        
        RenderQuickActions = {
            param($x, $y)
            $actions = $this.GetQuickActions()
            for ($i = 0; $i -lt $actions.Count; $i++) {
                $isSelected = ($i -eq $this.State.SelectedQuickAction)
                $prefix = if ($isSelected) { "→ " } else { "  " }
                $bgColor = if ($isSelected) { Get-ThemeColor "Accent" } else { Get-ThemeColor "Background" }
                $fgColor = if ($isSelected) { Get-ThemeColor "Background" } else { Get-ThemeColor "Primary" }
                
                $actionText = "$prefix$($actions[$i].Name)".PadRight($leftColWidth - 4)
                Write-BufferString -X $x -Y ($y + $i) -Text $actionText -ForegroundColor $fgColor -BackgroundColor $bgColor
            }
        }
        
        RenderActiveTimers = {
            param($x, $y)
            if ($this.State.ActiveTimers.Count -eq 0) {
                Write-BufferString -X $x -Y $y -Text "No active timers" -ForegroundColor (Get-ThemeColor "Subtle")
            } else {
                $currentY = $y
                foreach ($timer in $this.State.ActiveTimers | Select-Object -First 3) {
                    $elapsed = (Get-Date) - [DateTime]$timer.Value.StartTime
                    $project = Get-ProjectOrTemplate $timer.Value.ProjectKey
                    $projectText = if ($project.Name.Length -gt 14) { $project.Name.Substring(0,11) + "..." } else { $project.Name }
                    $timerDisplay = "$([Math]::Floor($elapsed.TotalHours)):$($elapsed.ToString('mm\:ss'))"
                    
                    Write-BufferString -X $x -Y $currentY -Text $projectText -ForegroundColor (Get-ThemeColor "Info")
                    Write-BufferString -X ($x + 16) -Y $currentY -Text $timerDisplay -ForegroundColor (Get-ThemeColor "Accent")
                    $currentY++
                }
            }
        }
        
        RenderTodaysTasks = {
            param($x, $y)
            if ($this.State.TodaysTasks.Count -eq 0) {
                Write-BufferString -X $x -Y $y -Text "No tasks for today" -ForegroundColor (Get-ThemeColor "Subtle")
            } else {
                $currentY = $y
                foreach ($task in $this.State.TodaysTasks) {
                    $taskText = "• $($task.Description)"
                    if ($taskText.Length -gt 24) { $taskText = $taskText.Substring(0, 21) + "..." }
                    Write-BufferString -X $x -Y $currentY -Text $taskText -ForegroundColor (Get-ThemeColor "Primary")
                    $currentY++
                }
            }
        }
        
        RenderRecentEntries = {
            param($x, $y)
            if ($this.State.RecentEntries.Count -eq 0) {
                Write-BufferString -X $x -Y $y -Text "No recent entries" -ForegroundColor (Get-ThemeColor "Subtle")
            } else {
                $currentY = $y
                foreach ($entry in $this.State.RecentEntries) {
                    $project = Get-ProjectOrTemplate $entry.ProjectKey
                    $projectText = if ($project.Name.Length -gt 14) { $project.Name.Substring(0,11) + "..." } else { $project.Name }
                    $entryText = "$($entry.Hours.ToString('F2'))h".PadLeft(7)
                    Write-BufferString -X $x -Y $currentY -Text $projectText -ForegroundColor (Get-ThemeColor "Primary")
                    Write-BufferString -X ($x + 16) -Y $currentY -Text $entryText -ForegroundColor (Get-ThemeColor "Success")
                    $currentY++
                }
            }
        }
        
        RenderQuickStats = {
            param($x, $y)
            $stats = $this.State.QuickStats
            $col1X = $x
            $col2X = $x + 18
            
            Write-BufferString -X $col1X -Y $y -Text "Hours Today:" -ForegroundColor (Get-ThemeColor "Secondary")
            Write-BufferString -X $col2X -Y $y -Text "$($stats.TodayHours.ToString('F2'))" -ForegroundColor (Get-ThemeColor "Info")

            Write-BufferString -X $col1X -Y ($y + 1) -Text "Hours This Week:" -ForegroundColor (Get-ThemeColor "Secondary")
            Write-BufferString -X $col2X -Y ($y + 1) -Text "$($stats.WeekHours.ToString('F2'))" -ForegroundColor (Get-ThemeColor "Info")

            Write-BufferString -X $col1X -Y ($y + 3) -Text "Active Tasks:" -ForegroundColor (Get-ThemeColor "Secondary")
            Write-BufferString -X $col2X -Y ($y + 3) -Text "$($stats.ActiveTasks)" -ForegroundColor (Get-ThemeColor "Warning")
            
            Write-BufferString -X $col1X -Y ($y + 4) -Text "Running Timers:" -ForegroundColor (Get-ThemeColor "Secondary")
            Write-BufferString -X $col2X -Y ($y + 4) -Text "$($stats.RunningTimers)" -ForegroundColor (Get-ThemeColor "Warning")
        }
    }
    
    # CRITICAL FIX: Convert the hashtable to a PSCustomObject
    # This promotes the scriptblocks to methods, allowing $this and $self to work correctly.
    return [PSCustomObject]$dashboardScreen
}

# Export the function
Export-ModuleMember -Function 'Get-DashboardScreen'