#
# TUI Framework Module v3.0
# Provides high-level abstractions for creating screens, forms, and dialogs.
# This module simplifies UI development by managing state, focus, and layout.
#

function global:Initialize-TuiFramework {
    # This is a placeholder for now, but could be used to register
    # custom components or layout engines in the future.
    Write-Verbose "TUI Framework initialized."
}

function global:Create-TuiScreen {
    <#
    .SYNOPSIS
        The cornerstone of the framework. Creates a fully managed screen object.
        It handles component creation, state management, focus cycling, and lifecycle hooks.
    .PARAMETER Definition
        A hashtable defining the screen's name, state, components, and behavior.
    #>
    param(
        [Parameter(Mandatory=$true)]
        [hashtable]$Definition
    )

    # The screen object that will be returned and pushed to the TUI engine's stack.
    $screen = @{
        Name            = $Definition.Name ?? "Screen_$(Get-Random)"
        State           = $Definition.State ?? @{}
        Components      = [System.Collections.ArrayList]::new()
        FocusableChildren = [System.Collections.ArrayList]::new()
        FocusedChildIndex = -1
        
        # --- Core Lifecycle Methods ---

        Init = {
            param($self)
            # This runs once when the screen is pushed onto the stack.
            
            # Create all child components from the definition.
            foreach ($compDef in $Definition.Children) {
                # Dynamically call the correct New-Tui* function.
                $factory = Get-Command "New-Tui$($compDef.Type)"
                $component = & $factory -Props $compDef.Props
                $component.Name = $compDef.Name

                $null = $self.Components.Add($component)
                if ($component.IsFocusable) {
                    $null = $self.FocusableChildren.Add($component)
                }
            }

            # Set initial focus on the first focusable component.
            if ($self.FocusableChildren.Count -gt 0) {
                $self.FocusedChildIndex = 0
            }
            
            # Call the user-defined Init scriptblock, if it exists.
            if ($Definition.Init) {
                & $Definition.Init -self $self
            }
        }

        Render = {
            param($self)
            # The main render loop for the screen.
            
            # Allow a custom, top-level render for backgrounds or complex layouts.
            if ($Definition.Render) {
                & $Definition.Render -self $self
            }

            # Render each child component.
            foreach ($child in $self.Components) {
                if ($child.Visible) {
                    # Create a temporary clone to pass state and focus information for rendering.
                    $renderableChild = $child.Clone()
                    
                    # --- Data Binding (State -> Props) ---
                    # This is a simple but powerful data-binding implementation.
                    # It connects the screen's state to the component's properties.
                    if ($child.Props.TextProp)       { $renderableChild.Text = $self.State.($child.Props.TextProp) }
                    if ($child.Props.ValueProp)      { $renderableChild.Value = $self.State.($child.Props.ValueProp) }
                    if ($child.Props.CheckedProp)    { $renderableChild.Checked = $self.State.($child.Props.CheckedProp) }
                    if ($child.Props.ItemsProp)      { $renderableChild.Data = $self.State.($child.Props.ItemsProp) } # For Tables/Lists
                    if ($child.Props.CursorProp)     { $renderableChild.CursorPosition = $self.State.($child.Props.CursorProp) }
                    
                    # Set focus state for rendering (e.g., highlight border).
                    $focusedChild = $self.FocusableChildren[$self.FocusedChildIndex]
                    if ($focusedChild -and $child.Name -eq $focusedChild.Name) {
                        $renderableChild.IsFocused = $true
                    }
                    
                    # Call the component's own Render method.
                    & $renderableChild.Render -self $renderableChild
                }
            }
        }

        HandleInput = {
            param($self, $Key)
            
            # --- Global Input Handling (Framework-Managed) ---
            if ($Key.Key -eq [ConsoleKey]::Tab) {
                if ($self.FocusableChildren.Count -gt 1) {
                    $direction = if ($Key.Modifiers -band [ConsoleModifiers]::Shift) { -1 } else { 1 }
                    $self.FocusedChildIndex = ($self.FocusedChildIndex + $direction + $self.FocusableChildren.Count) % $self.FocusableChildren.Count
                    Request-TuiRefresh
                    return $true
                }
            }
            
            # Pass input to the currently focused child component.
            $focusedChild = $self.FocusableChildren[$self.FocusedChildIndex]
            if ($focusedChild) {
                # --- Event/Callback Handling (Props -> State) ---
                # Clone the child and its event handlers to operate on.
                $interactiveChild = $focusedChild.Clone()

                # Wire up the OnChange handler to update the screen's state.
                if ($interactiveChild.OnChange) {
                    $originalOnChange = $interactiveChild.OnChange
                    $interactiveChild.OnChange = {
                        # This scriptblock is the "magic" of two-way binding.
                        # It receives the change event from the component...
                        $changeEventArgs = $args[0]
                        # ...and updates the screen's state.
                        if ($changeEventArgs.PSObject.Properties.Name -contains 'NewText') { $self.State.($interactiveChild.Props.TextProp) = $changeEventArgs.NewText }
                        if ($changeEventArgs.PSObject.Properties.Name -contains 'NewValue') { $self.State.($interactiveChild.Props.ValueProp) = $changeEventArgs.NewValue }
                        if ($changeEventArgs.PSObject.Properties.Name -contains 'Checked') { $self.State.($interactiveChild.Props.CheckedProp) = $changeEventArgs.Checked }
                        if ($changeEventArgs.PSObject.Properties.Name -contains 'NewCursorPosition') { $self.State.($interactiveChild.Props.CursorProp) = $changeEventArgs.NewCursorPosition }
                        
                        # Also, call the original user-defined OnChange if it exists.
                        & $originalOnChange $changeEventArgs
                    }.GetNewClosure()
                }

                # If the child handles the input, we're done.
                if (& $interactiveChild.HandleInput -self $interactiveChild -Key $Key) {
                    return $true
                }
            }

            # If no child handled it, let the screen's custom handler try.
            if ($Definition.HandleInput) {
                return & $Definition.HandleInput -self $self -Key $Key
            }
            
            return $false
        }
    }

    return $screen
}

function global:Create-TuiForm {
    <#
    .SYNOPSIS
        A high-level factory for creating data entry forms.
        It automatically generates labels and input components from a field definition.
    #>
    param(
        [string]$Name,
        [string]$Title,
        [int]$Width = 60,
        [int]$Height = 20,
        [hashtable]$State,
        [array]$Fields,
        [scriptblock]$OnSubmit,
        [scriptblock]$OnCancel
    )

    $children = [System.Collections.ArrayList]::new()
    $currentY = 2

    # Auto-generate components from field definitions
    foreach ($field in $Fields) {
        # Add Label
        $labelProps = @{
            X = 2
            Y = $currentY
            Text = "$($field.Label):"
        }
        $null = $children.Add(@{ Type = "Label"; Name = "$($field.Name)Label"; Props = $labelProps })
        
        # Add Input Component
        $inputProps = @{
            X = 20
            Y = $currentY - 1 # Textbox has a border, so adjust Y
            Width = $Width - 24
            TextProp = $field.Name # Bind this component's text to the state property of the same name
            CursorProp = "$($field.Name)Cursor"
        }
        # Add any other custom properties from the definition
        $field.Keys | Where-Object { $_ -notin @('Name', 'Label', 'Type') } | ForEach-Object {
            $inputProps[$_] = $field[$_]
        }
        $null = $children.Add(@{ Type = ($field.Type ?? 'TextBox'); Name = $field.Name; Props = $inputProps })
        
        $currentY += 3
    }
    
    # Add Submit/Cancel Buttons
    $null = $children.Add(@{ Type='Button'; Name='SubmitButton'; Props=@{ X=($Width/2)-16; Y=$Height-5; Width=12; Text='OK'; OnClick=$OnSubmit }})
    $null = $children.Add(@{ Type='Button'; Name='CancelButton'; Props=@{ X=($Width/2)+4; Y=$Height-5; Width=12; Text='Cancel'; OnClick=$OnCancel }})
    
    # Create the screen using the framework's main factory
    return Create-TuiScreen -Definition @{
        Name   = $Name
        Title  = $Title
        State  = $State
        Children = $children
        Render = {
            param($self)
            # Forms get a standard container box
            Write-BufferBox -X ([Math]::Floor(($TuiState.BufferWidth - $Width)/2)) -Y ([Math]::Floor(($TuiState.BufferHeight - $Height)/2)) -Width $Width -Height $Height -Title " $Title "
        }
    }
}