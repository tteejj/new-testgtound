# =============================================================
# FILE: pmc19_corrected_v2.ps1
# BASED ON: pmc19_corrected.ps1 + User Request (Fix Function Scope, Implement Settings)
# VERSION: 19.2 (Function Scope Fix, Settings Implemented)
# =============================================================
# Project Management Console - V19.2
# Target: PowerShell 7.5+ (Explicitly stated) on Windows (Windows Terminal Recommended for RGB)
# Strategy: Fully non-blocking main loop. All UI elements rendered via double buffer.
# Input handled via state machine and callbacks, rendered into buffer views.
# Includes Drawing Primitives, Non-Blocking Settings Config, New Themes.
# Implements Focus Management, Widget Rendering/Activation.
# Re-integrates Pomodoro/Clock, Adds Settings Screen Stub & Action.
# Thorough syntax review. Implements Phase 1 Fixes (OnLoad, Pomodoro, Cursor Nav, Settings).
# Phase 1 Interaction/Input Fixes:
# - Implemented Cursor Navigation (Up/Down/Enter) for ListViews.
# - Fixed Pomodoro display width and added debug logging.
# - Fixed Settings screen input triggering (Enter on InputViews/ButtonViews).
# - Improved Date Parsing and Validation feedback.
# - Added Time Entry Management (Update/Delete).
# - Refactored HandleItemSelect to use selected object.
# Phase 1 & 2 Audit Integration (v14.0 -> v16.0):
# - Fixed Input Validation (Log Size) with proper error message propagation.
# - Redesigned Dashboard (Upcoming Todos + Active Projects).
# - Added Missing Actions to Screens (Projects, Detail, Time Mgmt, Notes, Commands) for better workflow.
# - Created dedicated Time Management Screen.
# - Implemented Clipping Consistency Audit fixes in renderers.
# - Implemented basic Notes feature.
# - Added helper Get-FocusedListViewSelectedItem.
# - Corrected screen navigation logic (Time Mgmt).
# - Corrected screen DataSource definitions (Notes, Commands).
# - Fixed incomplete logic in Set-Project, Set-ProjectComplete, Remove-Project.
# - Fixed syntax error (extra brace).
# Phase 3 Enhancements (v16.0 -> v17.0):
# - Implemented simplified Calendar View screen.
# - Implemented TUI File/Folder Browser (`Request-FilePath`).
# - Integrated File Browser into Settings (CAA Path) and Project Update (Folder).
# - Enhanced Status Bar on Project List to show Filter/Sort state.
# - Performed Direct I/O Audit.
# Phase 4 Fixes (v19.0 -> v19.1):
# - Corrected multiple instances of parser error "Missing ')' in method call"
#   by separating nested PowerShell function calls from .NET method calls
#   within ValidationCallback script blocks.
# - Improved readability of chained function calls (e.g., Add-ManualProject sequence).
# - Performed additional syntax and logic audit.
# Phase 5 Fixes (v19.1 -> v19.2):
# - Moved Input Request functions (Request-TextInput, etc.) outside Start-ProjectManagement
#   to fix "not recognized as a name of a cmdlet" errors.
# - Implemented functional Settings screen:
#   - Edit CAA Path (using Request-FilePath).
#   - Edit Log Size (using Request-TextInput).
#   - Select Default Theme (using Select-ItemFromList).
#   - Save/Cancel functionality.
#   - Added focus handling for Settings screen elements.
# =============================================================

# --- Determine Script Root ---
if ($PSScriptRoot) { $Global:scriptRoot = $PSScriptRoot }
else { try { $Global:scriptRoot = (Get-Location -ErrorAction Stop).Path; Write-Warning "Could not determine script root ($PSScriptRoot). Using current directory '$($Global:scriptRoot)'." } catch { Write-Error "FATAL: Could not determine script root or current location."; Read-Host "Press Enter to exit."; exit 1 } }
$Global:DefaultDataSubDir = "_ProjectData"

# --- ANSI Escape Code ---
$global:esc = [char]27
$global:ansiReset = "${esc}[0m" # Full Reset
$global:ansiFgReset = "${esc}[39m" # Default Foreground Reset
$global:ansiBgReset = "${esc}[49m" # Default Background Reset

# --- Default Configuration Function ---
Function Get-DefaultConfig {
    param([string]$BaseDir)
    $dataDir = Join-Path -Path $BaseDir -ChildPath $Global:DefaultDataSubDir
    return @{
        projectsFile          = Join-Path -Path $dataDir -ChildPath "projects_todos.json"
        timeTrackingFile      = Join-Path -Path $dataDir -ChildPath "timetracking.csv"
        commandsFolder        = Join-Path -Path $dataDir -ChildPath "Commands"
        notesFolder           = Join-Path -Path $dataDir -ChildPath "Notes"
        logFilePath           = Join-Path -Path $dataDir -ChildPath "pmc_log_v19_corrected_v2.txt" # Log name reflects update
        caaTemplatePath       = "C:\Path\To\Your\Master\CAA Template.xlsm" # <<< USER MUST EDIT
        defaultTheme          = "SynthwaveRgb"
        displayDateFormat     = "yyyy-MM-dd"
        logMaxSizeMB          = 10
        tempTimesheetCsvPath  = Join-Path -Path $BaseDir -ChildPath "_temp_timesheet.csv"
        pomodoroWorkDurationMin = 25
        pomodoroBreakDurationMin = 5
        dashboardUpcomingDays = 14
        dashboardMaxTodos     = 10
        dashboardMaxProjects  = 10
    }
}

# --- Global Border Styles Definition ---
$Global:borderStyles = @{
    "Single"    = @{ TL='┌'; T='─'; TR='┐'; L='│'; R='│'; BL='└'; B='─'; BR='┘'; LJ='├'; RJ='┤'; TJ='┬'; BJ='┴'; C='┼' }
    "Double"    = @{ TL='╔'; T='═'; TR='╗'; L='║'; R='║'; BL='╚'; B='═'; BR='╝'; LJ='╠'; RJ='╣'; TJ='╦'; BJ='╩'; C='╬' }
    "Rounded"   = @{ TL='╭'; T='─'; TR='╮'; L='│'; R='│'; BL='╰'; B='─'; BR='╯'; LJ='├'; RJ='┤'; TJ='┬'; BJ='┴'; C='┼' }
    "HeavyLine" = @{ TL='┏'; T='━'; TR='┓'; L='┃'; R='┃'; BL='┗'; B='━'; BR='┛'; LJ='┣'; RJ='┫'; TJ='┳'; BJ='┻'; C='╋' }
    "Block"     = @{ TL='█'; T='█'; TR='█'; L='█'; R='█'; BL='█'; B='█'; BR='█'; LJ='█'; RJ='█'; TJ='█'; BJ='█'; C='█' }
    "ASCII"     = @{ TL='+'; T='-'; TR='+'; L='|'; R='|'; BL='+'; B='-'; BR='+'; LJ='+'; RJ='+'; TJ='+'; BJ='+'; C='+' }
    "None"      = @{ TL=' '; T=' '; TR=' '; L='│'; R='│'; BL=' '; B=' '; BR=' '; LJ=' '; RJ=' '; TJ=' '; BJ=' '; C=' ' }
}

# --- Table Configuration ---
$global:tableConfig = @{
    BorderStyle = $Global:borderStyles["Single"]
    Columns = @{
        Projects            = @( @{Title="ID2"; Width=10; Property='ID2'}, @{Title="Full Name"; Width=30; Property='FullName'}, @{Title="Assigned"; Width=10; Property='AssignedDate'}, @{Title="Due"; Width=10; Property='DueDate'}, @{Title="BF"; Width=10; Property='BFDate'}, @{Title="Status"; Width=10; Property='Status'}, @{Title="Hrs"; Width=6; Property='Hours'}, @{Title="Latest Todo"; Width=25; Property='LatestTodo'} )
        ProjectSelection    = @( @{Title="#"; Width=3; Property='Index'}, @{Title="ID2"; Width=12; Property='ID2'}, @{Title="Full Name"; Width=40; Property='FullName'}, @{Title="Status"; Width=15; Property='Status'} )
        ProjectInfoDetail   = @( @{Title="Field"; Width=15; Property='Field'}, @{Title="Value"; Width=55; Property='Value'} )
        ProjectTodos        = @( @{Title="ID"; Width=4; Property='Index'}, @{Title="Task"; Width=45; Property='Task'}, @{Title="Due Date"; Width=10; Property='DueDate'}, @{Title="Priority"; Width=8; Property='Priority'}, @{Title="Status"; Width=10; Property='Status'} )
        TodoSelection       = @( @{Title="#"; Width=3; Property='Index'}, @{Title="Task"; Width=45; Property='Task'}, @{Title="Status"; Width=10; Property='Status'}, @{Title="Due"; Width=10; Property='DueDate'}, @{Title="Priority"; Width=8; Property='Priority'} )
        TimeSheet           = @( @{Title="Date"; Width=10; Property='DisplayDate'}, @{Title="ID2/Task"; Width=20; Property='ID2'}, @{Title="Hours"; Width=6; Property='HoursValue'}, @{Title="Description"; Width=40; Property='Description'} )
        Commands            = @( @{Title="Name"; Width=30; Property='BaseName'}, @{Title="Description"; Width=60; Property='Description'} )
        CommandSelection    = @( @{Title="#"; Width=3; Property='Index'}, @{Title="Name"; Width=30; Property='BaseName'}, @{Title="Description"; Width=60; Property='Description'} )
        NoteSelection       = @( @{Title="#"; Width=3; Property='Index'}, @{Title="Filename"; Width=50; Property='Name'}, @{Title="Modified"; Width=19; Property='LastWriteTime'} )
        DashboardTodos      = @( @{Title="#"; Width=3; Property='Index'}, @{Title="Due"; Width=10; Property='DueDate'}, @{Title="Task"; Width=40; Property='Task'}, @{Title="Project"; Width=10; Property='ProjectID2'}, @{Title="Priority"; Width=8; Property='Priority'} )
        DashboardProjects   = @( @{Title="#"; Width=3; Property='Index'}, @{Title="ID2"; Width=10; Property='ID2'}, @{Title="Name"; Width=40; Property='FullName'}, @{Title="BF Date"; Width=10; Property='BFDate'}, @{Title="Latest Todo"; Width=22; Property='LatestTodo'} )
        Todos               = @( @{Title="ID"; Width=4; Property='Index'}, @{Title="Task"; Width=35; Property='Task'}, @{Title="Project"; Width=10; Property='ProjectID2'}, @{Title="Due"; Width=10; Property='DueDate'}, @{Title="Priority"; Width=8; Property='Priority'}, @{Title="Status"; Width=10; Property='Status'} )
        FormattedTimesheet  = @( @{Title="ID1"; Width=10; Property='ID1'}, @{Title="ID2"; Width=20; Property='ID2'}, @{Title=""; Width=1; Property='_Empty1'}, @{Title=""; Width=1; Property='_Empty2'}, @{Title=""; Width=1; Property='_Empty3'}, @{Title=""; Width=1; Property='_Empty4'}, @{Title="Mon"; Width=5; Property='Mon'}, @{Title="Tue"; Width=5; Property='Tue'}, @{Title="Wed"; Width=5; Property='Wed'}, @{Title="Thu"; Width=5; Property='Thu'}, @{Title="Fri"; Width=5; Property='Fri'} )
        SelectionList       = @( @{Title="#"; Width=3; Property='Index'}, @{Title="Item"; Width=70; Property='DisplayValue'} )
        TimeManagementList  = @( @{Title="#"; Width=3; Property='Index'}, @{Title="Date"; Width=10; Property='DisplayDate'}, @{Title="ID2/Task"; Width=20; Property='ID2'}, @{Title="Hours"; Width=6; Property='HoursValue'}, @{Title="Description"; Width=40; Property='Description'} )
        FileBrowserList     = @( @{Title="#"; Width=3; Property='Index'}, @{Title="Type"; Width=4; Property='Type'}, @{Title="Name"; Width=65; Property='Name'} )
    }
}

# --- Global AppConfig Variable ---
$Global:AppConfig = $null

# --- Centralized Excel Mappings ---
$global:excelMappings = @{ Extraction = @(); Copying = @(); StaticEntries = @() }

# --- Constants ---
$global:DATE_FORMAT_INTERNAL = "yyyyMMdd"
$global:DATE_FORMAT_DISPLAY_FALLBACK = "yyyy-MM-dd"
$global:COMMON_DATE_FORMATS_PARSE = @( "yyyyMMdd", "yyyy-MM-dd", "dd/MM/yyyy", "MM/dd/yyyy", "dd-MMM-yyyy", "d-MMM-yyyy", "yyyy.MM.dd", "dd.MM.yyyy", "d/M/yyyy", "M/d/yyyy" )

# --- Script State ---
$script:keepRunning = $true
$script:lastWidth = 0
$script:lastHeight = 0
$script:ScriptErrored = $false
$script:StatusMessage = @{ Text = ""; Type = "Info"; Timeout = $null }
$script:RefreshDetailScreen = $false
$script:ProjectFilter = 'Active'
$script:ProjectSort = 'BF'

# --- Theme State Variables ---
$script:ActiveTheme = $null
$script:ActiveThemeName = "None"
$script:LoadedThemes = @{}

# --- Buffer State Variables ---
$script:FrontBuffer = $null
$script:BackBuffer = $null
$script:BufferWidth = 0
$script:BufferHeight = 0

# --- Screen Manager State Variables ---
$script:IsRendering = $false
$script:RenderRequested = $true
$script:ScreenStack = [System.Collections.Generic.List[object]]::new()

# --- Context Manager State Variables ---
$script:Projects = @()
$script:NextProjectId = 1

# --- Data Variables for Screens ---
$script:DashboardUpcomingTodos = @(); $script:DashboardUpcomingTodosCount = 0; $script:DashboardUpcomingTodosRowColors = @{}
$script:DashboardProjectItems = @(); $script:DashboardProjectItemsCount = 0; $script:DashboardProjectItemsRowColors = @{}
$script:CurrentProjectList = @(); $script:CurrentProjectListCount = 0; $script:CurrentProjectListRowColors = @{}; $script:CurrentProjectListTitle = " PROJECTS LIST (ACTIVE / BF) "
$script:CurrentDetailProject = $null; $script:CurrentDetailInfoData = @(); $script:CurrentDetailTodosData = @(); $script:CurrentDetailTodosRowColors = @{}
$script:CurrentTodoList = @(); $script:CurrentTodoListCount = 0; $script:CurrentTodoListRowColors = @{}
$script:SelectionScreenItems = @(); $script:SelectionScreenTitle = ""; $script:SelectionScreenPrompt = ""; $script:SelectionScreenViewType = ""; $script:SelectionScreenItemMap = @{}; $script:SelectionScreenPage = 0; $script:SelectionScreenPageSize = 15; $script:SelectionScreenTotalPages = 1; $script:SelectionScreenFullItems = @(); $script:SelectionScreenOnItemSelected = $null; $script:SelectionScreenOnCancel = $null; $script:TempDataForSelection = $null
$script:CurrentTimeManagementEntries = @(); $script:CurrentTimeManagementCount = 0; $script:CurrentTimeManagementRowColors = @{}
$script:CalendarData = @{}; $script:CalendarCurrentMonth = (Get-Date).Date

# --- Input State Machine ---
$script:InputState = @{ Mode = "Normal"; Buffer = [System.Text.StringBuilder]::new(); CursorPos = 0; PromptText = ""; DefaultValue = ""; DefaultValueInternal= ""; ForceDateFormat = $false; MaxLength = 0; ValidationCallback = $null; ValidationMessage = ""; SubmitCallback = $null; CancelCallback = $null; MinValue = 0; MaxValue = 0; Options = @{}; CancelOptionKey = "0"; CurrentSelectionIndex = 0; TempData = $null }

# --- Cursor State ---
$script:CursorState = @{ X = 0; Y = 0; Visible = $false }

# --- Focus Management State ---
$script:FocusedViewName = $null
$script:ListViewStates = @{}

# --- Pomodoro State ---
$script:PomodoroState = @{ Running = $false; Mode = 'Work'; StartTime = $null; DurationSec = 0; RemainingTS = [TimeSpan]::Zero; RequestRender = $false; LastUpdateTime= $null }

# --- Segment Display Patterns ---
$script:SegmentPatterns = @{ '0'=@("███","█ █","█ █","█ █","███"); '1'=@("  █"," ██","  █","  █"," ██"); '2'=@("███","  █","███","█  ","███"); '3'=@("███","  █","███","  █","███"); '4'=@("█ █","█ █","███","  █","  █"); '5'=@("███","█  ","███","  █","███"); '6'=@("███","█  ","███","█ █","███"); '7'=@("███","  █","  █","  █","  █"); '8'=@("███","█ █","███","█ █","███"); '9'=@("███","█ █","███","  █","███"); ':'=@("   "," █ ","   "," █ ","   ") }
$script:SegmentHeight = 5; $script:SegmentWidth = 3

# --- Help Overlay State ---
$script:HelpScreenText = ""

# --- Settings State ---
$script:TempSettings = $null

#endregion

#region Logging Functions
function Write-AppLog {
    param(
        [string]$Message,
        [ValidateSet("INFO", "WARN", "ERROR", "DEBUG", "TRACE")][string]$Level = "INFO"
    )
    if ($Level -eq "TRACE") { return } # Optionally disable TRACE logging easily
    if ($null -eq $Global:AppConfig) { Write-Warning "[PRE-LOG] [$Level] $Message"; return }
    $logPath = $Global:AppConfig.logFilePath
    if ([string]::IsNullOrWhiteSpace($logPath)) { Write-Warning "[Write-AppLog] Log path missing."; Write-Warning "[$Level] $Message"; return }
    $maxSizeBytes = ($Global:AppConfig.logMaxSizeMB * 1MB)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $logLine = "$timestamp [$Level] $Message"
    try {
        $logDir = Split-Path -Path $logPath -Parent
        if (-not (Test-Path $logDir -PathType Container)) {
            try { New-Item -Path $logDir -ItemType Directory -Force -ErrorAction Stop | Out-Null }
            catch { Write-Warning "!!! Error creating log directory '$logDir': $($_.Exception.Message) !!!"; return }
        }
        if ((Test-Path $logPath) -and (Get-Item $logPath).Length -gt $maxSizeBytes) {
            $backupLogPath = "$logPath.bak"
            if (Test-Path $backupLogPath) { Remove-Item $backupLogPath -Force -ErrorAction SilentlyContinue }
            try { Move-Item -Path $logPath -Destination $backupLogPath -Force -ErrorAction Stop }
            catch { Write-Warning "!!! Error rotating log file '$logPath': $($_.Exception.Message) !!!" }
        }
        Add-Content -Path $logPath -Value $logLine -Encoding UTF8 -ErrorAction Stop
    } catch {
        Write-Warning "!!! Error writing log '$logPath': $($_.Exception.Message) !!!"
        Write-Warning "Log Entry: $logLine"
    }
}
function Handle-Error {
    param(
        [Parameter(ValueFromPipeline=$true)]$ErrorRecord,
        [string]$Context = "General Operation"
    )
    $errMsg = "ERROR in [$Context]: $($ErrorRecord.Exception.Message)"
    $fullErrMsg = "[$Context] Error: $($ErrorRecord.ToString())`nScriptStackTrace: $($ErrorRecord.ScriptStackTrace)"
    Write-AppLog $fullErrMsg "ERROR"
    Show-Error $errMsg # Use the non-blocking Show-Error
}
#endregion

#region Theme Definitions
$script:FallbackRgbTheme = @{ Name = "Fallback RGB"; Description = "Basic theme using RGB ANSI codes."; Palette = @{ DefaultFG = '39'; DefaultBG = '49'; PrimaryFG = '38;2;220;220;220'; PrimaryBG = '49'; SecondaryFG = '38;2;128;128;128'; HighlightFG = '38;2;255;255;255'; HighlightBG = '48;2;0;0;139'; ErrorFG = '38;2;255;60;60'; ErrorBG = '49'; WarningFG = '38;2;255;255;80'; WarningBG = '49'; SuccessFG = '38;2;60;255;60'; SuccessBG = '49'; InfoFG = '38;2;60;255;255'; InfoBG = '49'; DataFG = '$Palette:PrimaryFG'; DisabledFG = '$Palette:SecondaryFG'; BorderFG = '$Palette:SecondaryFG'; InputPrompt = '$Palette:InfoFG'; InputText = '$Palette:PrimaryFG'; InputDefaultHint = '$Palette:SecondaryFG'; InputBackground = '$Palette:PrimaryBG'; FocusBorderFG = '$Palette:HighlightFG'; FocusBorderBG = '$Palette:PrimaryBG'; FocusTextFG = '$Palette:HighlightFG'; FocusTextBG = '$Palette:HighlightBG'; WidgetFG = '$Palette:PrimaryFG'; WidgetBG = '$Palette:PrimaryBG'; WidgetFocusFG = '$Palette:HighlightFG'; WidgetFocusBG = '$Palette:HighlightBG'; WidgetDisabledFG = '$Palette:DisabledFG'; }; ScreenBorder = @{ Enabled = $true; Style = "Single"; FG = '$Palette:BorderFG'; BG = '$Palette:PrimaryBG' }; WindowTitle = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:HighlightBG'; Pad = 1; LinesAbove = 0; LinesBelow = 0; Border = $null }; ActionListLine = @{ FG = '$Palette:InfoFG'; BG = '$Palette:PrimaryBG' }; StatusLine = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' }; StatusMessage = @{ Types = @{ Success = @{ FG = '$Palette:SuccessFG'; BG = '$Palette:SuccessBG'; Prefix = "[OK] " }; Error = @{ FG = '$Palette:ErrorFG'; BG = '$Palette:ErrorBG'; Prefix = "[ERROR] " }; Warning = @{ FG = '$Palette:WarningFG'; BG = '$Palette:WarningBG'; Prefix = "[WARN] " }; Info = @{ FG = '$Palette:InfoFG'; BG = '$Palette:InfoBG'; Prefix = "[INFO] " } } }; InputControl = @{ Prompt = @{ FG = '$Palette:InputPrompt' }; DefaultHint = @{ FG = '$Palette:InputDefaultHint'; Prefix = " ("; Suffix = ")" }; UserInput = @{ FG = '$Palette:InputText'; BG = '$Palette:InputBackground' } }; DataTable = @{ BorderStyle = "Single"; BorderFG = '$Palette:BorderFG'; Pad = 1; Header = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:HighlightBG'; Separator = $true }; DataRow = @{ FG = '$Palette:DataFG'; BG = '$Palette:PrimaryBG' }; AltRow = @{ FG = '$Palette:DataFG'; BG = '$Palette:PrimaryBG' }; Highlight = @{ Selected = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:HighlightBG' }; Overdue = @{ FG = '$Palette:ErrorFG'; BG = '$Palette:PrimaryBG' }; DueSoon = @{ FG = '$Palette:WarningFG'; BG = '$Palette:PrimaryBG' }; Completed = @{ FG = '$Palette:DisabledFG'; BG = '$Palette:PrimaryBG' }; SchedCurrent = @{ FG = '$Palette:SuccessFG'; BG = '$Palette:PrimaryBG' }; SchedNext = @{ FG = '$Palette:WarningFG'; BG = '$Palette:PrimaryBG' } } }; Menu = @{ Header = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:HighlightBG' }; Option = @{ FG = '$Palette:PrimaryFG'; BG = '$Palette:PrimaryBG' }; Info = @{ FG = '$Palette:InfoFG'; BG = '$Palette:PrimaryBG' } }; HelpOverlay = @{ FG = '38;2;0;0;0'; BG = '48;2;255;255;255' }; SegmentDisplay = @{ FG = '$Palette:SuccessFG'; BG = '$Palette:PrimaryBG' } }
$script:SynthwaveRgbTheme = @{ Name = "Synthwave RGB"; Description = "Raw ANSI codes for Synthwave colors using RGB"; Palette = @{ DefaultFG = '39'; DefaultBG = '49'; PrimaryFG = '38;2;240;240;240'; PrimaryBG = '48;2;46;26;71'; SecondaryFG = '38;2;160;160;160'; HighlightFG = '38;2;255;255;255'; HighlightBG = '48;2;255;0;127'; ErrorFG = '38;2;255;65;54'; ErrorBG = '$Palette:PrimaryBG'; WarningFG = '38;2;255;215;0'; WarningBG = '$Palette:PrimaryBG'; SuccessFG = '38;2;57;204;204'; SuccessBG = '$Palette:PrimaryBG'; InfoFG = '38;2;127;219;255'; InfoBG = '$Palette:PrimaryBG'; DataFG = '$Palette:PrimaryFG'; DisabledFG = '38;2;136;136;136'; BorderFG = '38;2;255;0;127'; InputPrompt = '$Palette:SuccessFG'; InputText = '$Palette:PrimaryFG'; InputDefaultHint = '$Palette:SecondaryFG'; InputBackground = '48;2;61;42;87'; FocusBorderFG = '$Palette:WarningFG'; FocusBorderBG = '$Palette:PrimaryBG'; FocusTextFG = '38;2;0;0;0'; FocusTextBG = '$Palette:WarningFG'; WidgetFG = '$Palette:InfoFG'; WidgetBG = '$Palette:InputBackground'; WidgetFocusFG = '$Palette:HighlightFG'; WidgetFocusBG = '$Palette:HighlightBG'; WidgetDisabledFG = '$Palette:DisabledFG'; }; ScreenBorder = @{ Enabled = $true; Style = "Double"; FG = '$Palette:BorderFG'; BG = '$Palette:PrimaryBG' }; WindowTitle = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:HighlightBG'; Pad = 1; LinesAbove = 0; LinesBelow = 0; Border = $null }; ActionListLine = @{ FG = '$Palette:InfoFG'; BG = '$Palette:PrimaryBG' }; StatusLine = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' }; StatusMessage = @{ Types = @{ Success = @{ FG = '$Palette:SuccessFG'; BG = '$Palette:SuccessBG'; Prefix = "[OK] " }; Error = @{ FG = '$Palette:ErrorFG'; BG = '$Palette:ErrorBG'; Prefix = "[ERROR] " }; Warning = @{ FG = '$Palette:WarningFG'; BG = '$Palette:WarningBG'; Prefix = "[WARN] " }; Info = @{ FG = '$Palette:InfoFG'; BG = '$Palette:InfoBG'; Prefix = "[INFO] " } } }; InputControl = @{ Prompt = @{ FG = '$Palette:InputPrompt' }; DefaultHint = @{ FG = '$Palette:InputDefaultHint'; Prefix = " ("; Suffix = ")" }; UserInput = @{ FG = '$Palette:InputText'; BG = '$Palette:InputBackground' } }; DataTable = @{ BorderStyle = "Double"; BorderFG = '$Palette:BorderFG'; Pad = 1; Header = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:HighlightBG'; Separator = $true }; DataRow = @{ FG = '$Palette:DataFG'; BG = '$Palette:PrimaryBG' }; AltRow = @{ FG = '$Palette:DataFG'; BG = '48;2;61;42;87' }; Highlight = @{ Selected = @{ FG = '38;2;0;0;0'; BG = '48;2;255;215;0' }; Overdue = @{ FG = '$Palette:ErrorFG'; BG = '$Palette:PrimaryBG' }; DueSoon = @{ FG = '$Palette:WarningFG'; BG = '$Palette:PrimaryBG' }; Completed = @{ FG = '$Palette:DisabledFG'; BG = '$Palette:PrimaryBG' }; SchedCurrent = @{ FG = '$Palette:SuccessFG'; BG = '$Palette:PrimaryBG' }; SchedNext = @{ FG = '$Palette:WarningFG'; BG = '$Palette:PrimaryBG' } } }; Menu = @{ Header = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:HighlightBG' }; Option = @{ FG = '$Palette:PrimaryFG'; BG = '$Palette:PrimaryBG' }; Info = @{ FG = '$Palette:InfoFG'; BG = '$Palette:PrimaryBG' } }; HelpOverlay = @{ FG = '38;2;0;0;0'; BG = '48;2;255;255;255' }; SegmentDisplay = @{ FG = '$Palette:SuccessFG'; BG = '$Palette:PrimaryBG' } }
$script:RetroCrtGreenTheme = @{ Name = "Retro CRT Green"; Description = "Monochrome green on black CRT style."; Palette = @{ DefaultFG = '39'; DefaultBG = '49'; PrimaryFG = '38;2;60;255;60'; PrimaryBG = '48;2;10;20;10'; SecondaryFG = '38;2;40;180;40'; HighlightFG = '38;2;180;255;180'; HighlightBG = '48;2;40;180;40'; ErrorFG = '$Palette:HighlightFG'; ErrorBG = '$Palette:PrimaryBG'; WarningFG = '$Palette:HighlightFG'; WarningBG = '$Palette:PrimaryBG'; SuccessFG = '$Palette:PrimaryFG'; SuccessBG = '$Palette:PrimaryBG'; InfoFG = '$Palette:PrimaryFG'; InfoBG = '$Palette:PrimaryBG'; DataFG = '$Palette:PrimaryFG'; DisabledFG = '38;2;30;100;30'; BorderFG = '$Palette:SecondaryFG'; InputPrompt = '$Palette:HighlightFG'; InputText = '$Palette:HighlightFG'; InputDefaultHint = '$Palette:SecondaryFG'; InputBackground = '48;2;20;40;20'; FocusBorderFG = '$Palette:HighlightFG'; FocusBorderBG = '$Palette:PrimaryBG'; FocusTextFG = '$Palette:PrimaryBG'; FocusTextBG = '$Palette:HighlightFG'; WidgetFG = '$Palette:PrimaryFG'; WidgetBG = '$Palette:InputBackground'; WidgetFocusFG = '$Palette:PrimaryBG'; WidgetFocusBG = '$Palette:HighlightFG'; WidgetDisabledFG = '$Palette:DisabledFG'; }; ScreenBorder = @{ Enabled = $true; Style = "ASCII"; FG = '$Palette:BorderFG'; BG = '$Palette:PrimaryBG' }; WindowTitle = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:SecondaryFG'; Pad = 1; LinesAbove = 0; LinesBelow = 0; Border = $null }; ActionListLine = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' }; StatusLine = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' }; StatusMessage = @{ Types = @{ Success = @{ FG = '$Palette:SuccessFG'; BG = '$Palette:SuccessBG'; Prefix = "[OK] " }; Error = @{ FG = '$Palette:ErrorFG'; BG = '$Palette:ErrorBG'; Prefix = "[ERROR] " }; Warning = @{ FG = '$Palette:WarningFG'; BG = '$Palette:WarningBG'; Prefix = "[WARN] " }; Info = @{ FG = '$Palette:InfoFG'; BG = '$Palette:InfoBG'; Prefix = "[INFO] " } } }; InputControl = @{ Prompt = @{ FG = '$Palette:InputPrompt' }; DefaultHint = @{ FG = '$Palette:InputDefaultHint'; Prefix = " ("; Suffix = ")" }; UserInput = @{ FG = '$Palette:InputText'; BG = '$Palette:InputBackground' } }; DataTable = @{ BorderStyle = "ASCII"; BorderFG = '$Palette:BorderFG'; Pad = 1; Header = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:SecondaryFG'; Separator = $true }; DataRow = @{ FG = '$Palette:DataFG'; BG = '$Palette:PrimaryBG' }; AltRow = @{ FG = '$Palette:DataFG'; BG = '$Palette:PrimaryBG' }; Highlight = @{ Selected = @{ FG = '$Palette:PrimaryBG'; BG = '$Palette:HighlightFG' }; Overdue = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:PrimaryBG' }; DueSoon = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:PrimaryBG' }; Completed = @{ FG = '$Palette:DisabledFG'; BG = '$Palette:PrimaryBG' }; SchedCurrent = @{ FG = '$Palette:PrimaryFG'; BG = '$Palette:PrimaryBG' }; SchedNext = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' } } }; Menu = @{ Header = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:SecondaryFG' }; Option = @{ FG = '$Palette:PrimaryFG'; BG = '$Palette:PrimaryBG' }; Info = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' } }; HelpOverlay = @{ FG = '$Palette:PrimaryBG'; BG = '$Palette:HighlightFG' }; SegmentDisplay = @{ FG = '$Palette:PrimaryFG'; BG = '$Palette:PrimaryBG' } }
$script:RetroCrtAmberTheme = @{ Name = "Retro CRT Amber"; Description = "Monochrome amber on black CRT style."; Palette = @{ DefaultFG = '39'; DefaultBG = '49'; PrimaryFG = '38;2;255;180;60'; PrimaryBG = '48;2;20;10;0'; SecondaryFG = '38;2;200;140;40'; HighlightFG = '38;2;255;220;150'; HighlightBG = '48;2;180;120;40'; ErrorFG = '$Palette:HighlightFG'; ErrorBG = '$Palette:PrimaryBG'; WarningFG = '$Palette:HighlightFG'; WarningBG = '$Palette:PrimaryBG'; SuccessFG = '$Palette:PrimaryFG'; SuccessBG = '$Palette:PrimaryBG'; InfoFG = '$Palette:PrimaryFG'; InfoBG = '$Palette:PrimaryBG'; DataFG = '$Palette:PrimaryFG'; DisabledFG = '38;2;100;70;30'; BorderFG = '$Palette:SecondaryFG'; InputPrompt = '$Palette:HighlightFG'; InputText = '$Palette:HighlightFG'; InputDefaultHint = '$Palette:SecondaryFG'; InputBackground = '48;2;40;20;10'; FocusBorderFG = '$Palette:HighlightFG'; FocusBorderBG = '$Palette:PrimaryBG'; FocusTextFG = '$Palette:PrimaryBG'; FocusTextBG = '$Palette:HighlightFG'; WidgetFG = '$Palette:PrimaryFG'; WidgetBG = '$Palette:InputBackground'; WidgetFocusFG = '$Palette:PrimaryBG'; WidgetFocusBG = '$Palette:HighlightFG'; WidgetDisabledFG = '$Palette:DisabledFG'; }; ScreenBorder = @{ Enabled = $true; Style = "ASCII"; FG = '$Palette:BorderFG'; BG = '$Palette:PrimaryBG' }; WindowTitle = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:SecondaryFG'; Pad = 1; LinesAbove = 0; LinesBelow = 0; Border = $null }; ActionListLine = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' }; StatusLine = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' }; StatusMessage = @{ Types = @{ Success = @{ FG = '$Palette:SuccessFG'; BG = '$Palette:SuccessBG'; Prefix = "[OK] " }; Error = @{ FG = '$Palette:ErrorFG'; BG = '$Palette:ErrorBG'; Prefix = "[ERROR] " }; Warning = @{ FG = '$Palette:WarningFG'; BG = '$Palette:WarningBG'; Prefix = "[WARN] " }; Info = @{ FG = '$Palette:InfoFG'; BG = '$Palette:InfoBG'; Prefix = "[INFO] " } } }; InputControl = @{ Prompt = @{ FG = '$Palette:InputPrompt' }; DefaultHint = @{ FG = '$Palette:InputDefaultHint'; Prefix = " ("; Suffix = ")" }; UserInput = @{ FG = '$Palette:InputText'; BG = '$Palette:InputBackground' } }; DataTable = @{ BorderStyle = "ASCII"; BorderFG = '$Palette:BorderFG'; Pad = 1; Header = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:SecondaryFG'; Separator = $true }; DataRow = @{ FG = '$Palette:DataFG'; BG = '$Palette:PrimaryBG' }; AltRow = @{ FG = '$Palette:DataFG'; BG = '$Palette:PrimaryBG' }; Highlight = @{ Selected = @{ FG = '$Palette:PrimaryBG'; BG = '$Palette:HighlightFG' }; Overdue = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:PrimaryBG' }; DueSoon = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:PrimaryBG' }; Completed = @{ FG = '$Palette:DisabledFG'; BG = '$Palette:PrimaryBG' }; SchedCurrent = @{ FG = '$Palette:PrimaryFG'; BG = '$Palette:PrimaryBG' }; SchedNext = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' } } }; Menu = @{ Header = @{ FG = '$Palette:HighlightFG'; BG = '$Palette:SecondaryFG' }; Option = @{ FG = '$Palette:PrimaryFG'; BG = '$Palette:PrimaryBG' }; Info = @{ FG = '$Palette:SecondaryFG'; BG = '$Palette:PrimaryBG' } }; HelpOverlay = @{ FG = '$Palette:PrimaryBG'; BG = '$Palette:HighlightFG' }; SegmentDisplay = @{ FG = '$Palette:PrimaryFG'; BG = '$Palette:PrimaryBG' } }
$script:LoadedThemes = @{ "FallbackRgb" = $script:FallbackRgbTheme; "SynthwaveRgb" = $script:SynthwaveRgbTheme; "RetroCrtGreen" = $script:RetroCrtGreenTheme; "RetroCrtAmber" = $script:RetroCrtAmberTheme }
#endregion

#region Configuration Management Functions
function Ensure-DirectoryExists {
    param([string]$DirectoryPath)
    if (-not (Test-Path $DirectoryPath -PathType Container)) {
        try {
            New-Item -Path $DirectoryPath -ItemType Directory -Force -EA Stop | Out-Null
            Write-AppLog "Created directory: $DirectoryPath" "INFO"
            return $true
        } catch {
            Handle-Error $_ "Creating directory '$DirectoryPath'"
            return $false
        }
    }
    return $true
}
function Load-AppConfig {
    $configDir = Join-Path $Global:scriptRoot $Global:DefaultDataSubDir
    $configPath = Join-Path $configDir 'config.json'
    $defaultConfig = Get-DefaultConfig -BaseDir $Global:scriptRoot
    $finalFallbackThemeKey = "FallbackRgb" # Ultimate fallback
    $availableThemes = $script:LoadedThemes.Keys
    if ($availableThemes.Contains($defaultConfig.defaultTheme)) { $finalFallbackThemeKey = $defaultConfig.defaultTheme } elseif ($availableThemes.Count -gt 0) { $finalFallbackThemeKey = $availableThemes[0]; Write-AppLog "Default theme '$($defaultConfig.defaultTheme)' not found, falling back to '$finalFallbackThemeKey'." "WARN" } else { Write-AppLog "CRITICAL: No themes loaded, using minimal fallback '$finalFallbackThemeKey'." "ERROR" }
    if (-not (Ensure-DirectoryExists -DirectoryPath $configDir)) { Write-Warning "Using temporary defaults as config directory failed."; $Global:AppConfig = $defaultConfig; Set-ActiveTheme -ThemeName $finalFallbackThemeKey; Write-AppLog "Using fallback theme '$finalFallbackThemeKey' due to config directory failure." "WARN"; return }
    if (Test-Path $configPath) {
        Write-AppLog "Loading config from $configPath" "INFO"
        try { $loadedConfig = Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable -EA Stop; $mergedConfig = $defaultConfig.Clone(); foreach ($key in $loadedConfig.Keys) { $mergedConfig[$key] = $loadedConfig[$key] }; $Global:AppConfig = $mergedConfig; Write-AppLog "Config loaded successfully." "INFO" }
        catch { Handle-Error $_ "Loading/Parsing config.json"; Write-AppLog "Using default config due to load error." "WARN"; $Global:AppConfig = $defaultConfig }
    } else {
        Write-AppLog "Config file not found. Creating default: $configPath" "INFO"; $defaultConfig.defaultTheme = $finalFallbackThemeKey; $Global:AppConfig = $defaultConfig
        try { $Global:AppConfig | ConvertTo-Json -Depth 5 | Out-File $configPath -Encoding UTF8 -Force -EA Stop; Show-Warning "Default config file created: '$configPath'"; Show-Warning ">>> REVIEW/EDIT '$configPath', especially 'caaTemplatePath', AND RESTART <<<"; Pause-Screen "Press Enter after reviewing config.json..." }
        catch { Handle-Error $_ "Saving default config.json"; Show-Error "Could not save default config file. Using temporary defaults." }
    }
    if (-not $Global:AppConfig.ContainsKey('pomodoroWorkDurationMin')) { $Global:AppConfig.pomodoroWorkDurationMin = $defaultConfig.pomodoroWorkDurationMin }
    if (-not $Global:AppConfig.ContainsKey('pomodoroBreakDurationMin')) { $Global:AppConfig.pomodoroBreakDurationMin = $defaultConfig.pomodoroBreakDurationMin }
    if (-not $Global:AppConfig.ContainsKey('dashboardUpcomingDays')) { $Global:AppConfig.dashboardUpcomingDays = $defaultConfig.dashboardUpcomingDays }
    if (-not $Global:AppConfig.ContainsKey('dashboardMaxTodos')) { $Global:AppConfig.dashboardMaxTodos = $defaultConfig.dashboardMaxTodos }
    if (-not $Global:AppConfig.ContainsKey('dashboardMaxProjects')) { $Global:AppConfig.dashboardMaxProjects = $defaultConfig.dashboardMaxProjects }
    if (-not $Global:AppConfig.ContainsKey('notesFolder')) { $Global:AppConfig.notesFolder = $defaultConfig.notesFolder }
    Write-AppLog "Validating critical configuration paths..." "DEBUG"; $pathsToValidate = @('projectsFile', 'timeTrackingFile', 'commandsFolder', 'logFilePath', 'notesFolder'); $configValid = $true
    foreach ($key in $pathsToValidate) { if (-not $Global:AppConfig.ContainsKey($key) -or [string]::IsNullOrWhiteSpace($Global:AppConfig.$key)) { $errorMessage = "Configuration key '$key' is missing or empty."; Write-AppLog $errorMessage "WARN"; Show-Warning "$errorMessage Attempting to use default."; $defaultValue = $defaultConfig.$key; if ([string]::IsNullOrWhiteSpace($defaultValue)) { $fatalError = "FATAL: Default value for critical config key '$key' is also empty. Cannot proceed."; Write-AppLog $fatalError "ERROR"; Show-Error $fatalError; $configValid = $false } else { $Global:AppConfig.$key = $defaultValue; Write-AppLog "Using default value for '$key': '$defaultValue'" "INFO"; Show-Info "Using default for '$key': $defaultValue" } } else { Write-AppLog "Path validated for '$key': '$($Global:AppConfig.$key)'" "DEBUG" } }
    if (-not $configValid) { Pause-Screen "Critical configuration errors found. Press Enter to exit."; exit 1 }
    $configuredThemeName = $Global:AppConfig.defaultTheme; if (-not (Set-ActiveTheme -ThemeName $configuredThemeName)) { Write-AppLog "Failed to set configured theme '$configuredThemeName', fallback applied by Set-ActiveTheme." "WARN"; $Global:AppConfig.defaultTheme = $script:ActiveThemeName }
    Write-AppLog "Current theme object set to '$($script:ActiveTheme.Name)'." "INFO"
    $script:PomodoroState.DurationSec = ($Global:AppConfig.pomodoroWorkDurationMin ?? 25) * 60; $script:PomodoroState.RemainingTS = [TimeSpan]::FromSeconds($script:PomodoroState.DurationSec); Write-AppLog "Pomodoro state initialized: Work=$($Global:AppConfig.pomodoroWorkDurationMin)m, Break=$($Global:AppConfig.pomodoroBreakDurationMin)m" "DEBUG"
}
function Save-AppConfig {
    Write-AppLog "Saving application configuration..." "INFO"; if ($null -eq $Global:AppConfig) { Write-AppLog "Save-AppConfig: Global:AppConfig is null. Cannot save." "ERROR"; return $false }
    $configDir = Join-Path $Global:scriptRoot $Global:DefaultDataSubDir; $configPath = Join-Path $configDir 'config.json'
    try { $Global:AppConfig | ConvertTo-Json -Depth 5 | Out-File $configPath -Encoding UTF8 -Force -EA Stop; Write-AppLog "Saved configuration to '$configPath'." "INFO"; return $true }
    catch { Handle-Error $_ "Saving config.json"; Show-Error "Failed to save configuration file."; return $false }
}
function Set-ActiveTheme { param([string]$ThemeName); $logFunc = { param($Msg, $Lvl="INFO") Write-AppLog $Msg $Lvl }; if ($script:LoadedThemes.ContainsKey($ThemeName)) { $script:ActiveTheme = $script:LoadedThemes[$ThemeName]; $script:ActiveThemeName = $ThemeName; $logFunc.Invoke("Active theme set to: $ThemeName ($($script:ActiveTheme.Name))", "INFO"); return $true } else { $logFunc.Invoke("Attempted to set active theme to '$ThemeName', but it was not found.", "ERROR"); if ($script:LoadedThemes.ContainsKey("FallbackRgb")) { $logFunc.Invoke("Falling back to 'FallbackRgb' theme.", "WARN"); return (Set-ActiveTheme -ThemeName "FallbackRgb") } else { $logFunc.Invoke("CRITICAL: Theme '$ThemeName' and 'FallbackRgb' not found. Using hardcoded minimal.", "ERROR"); $script:ActiveTheme = $script:FallbackRgbTheme; $script:ActiveThemeName = "FallbackRgb (Hardcoded)"; if (-not $script:LoadedThemes.ContainsKey("FallbackRgb")) { $script:LoadedThemes["FallbackRgb"] = $script:FallbackRgbTheme }; return $true } } }
function Get-ActiveTheme { $logFunc = { param($Msg, $Lvl="INFO") Write-AppLog $Msg $Lvl }; if ($null -eq $script:ActiveTheme) { $logFunc.Invoke("Get-ActiveTheme called but no theme is active. Attempting fallback.", "WARN"); if (-not (Set-ActiveTheme -ThemeName "FallbackRgb")) { $logFunc.Invoke("CRITICAL: Failed to set FallbackRgb theme. Using hardcoded minimal.", "ERROR"); $script:ActiveTheme = $script:FallbackRgbTheme; $script:ActiveThemeName = "FallbackRgb (Hardcoded)"; if (-not $script:LoadedThemes.ContainsKey("FallbackRgb")) { $script:LoadedThemes["FallbackRgb"] = $script:FallbackRgbTheme } } }; return $script:ActiveTheme }
function Get-LoadedThemeNames { return $script:LoadedThemes.Keys | Sort-Object }
function Get-PmcThemeProperty { param([Parameter(Mandatory=$true)][hashtable]$ThemeObject, [Parameter(Mandatory=$true)][string]$PropertyPath, [object]$DefaultValue=$null, [ValidateSet("String","Boolean","Hashtable","Array","Integer","Any")][string]$ExpectedType="Any"); $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; if ($null -eq $ThemeObject -or -not ($ThemeObject -is [hashtable])) { $logFunc.Invoke("Get-PmcThemeProperty: Invalid ThemeObject for path '$PropertyPath'.", "WARN"); return $DefaultValue }; $currentValue = $ThemeObject; $pathSegments = $PropertyPath.Split('.'); foreach($segment in $pathSegments) { if ($currentValue -is [hashtable] -and $currentValue.ContainsKey($segment)) { $currentValue = $currentValue[$segment] } else { $logFunc.Invoke("Theme property path not found: '$PropertyPath' (missing segment: '$segment'). Using default.", "DEBUG"); return $DefaultValue } }; if ($ExpectedType -ne "Any") { $typeMatch = $false; $actualType = if ($null -eq $currentValue) { "null" } else { $currentValue.GetType().Name }; switch ($ExpectedType) { "String" { $typeMatch = ($currentValue -is [string]) } "Boolean" { $typeMatch = ($currentValue -is [bool]) } "Hashtable" { $typeMatch = ($currentValue -is [hashtable]) } "Array" { $typeMatch = ($currentValue -is [array]) } "Integer" { $typeMatch = ($currentValue -is [int] -or $currentValue -is [long]) } }; if (-not $typeMatch) { $logFunc.Invoke("Theme property '$PropertyPath' type mismatch. Expected '$ExpectedType', got '$actualType'. Using default.", "WARN"); return $DefaultValue } }; return $currentValue }
function Get-PmcThemeAnsiCode { param([string]$PropertyPath, [string]$DefaultAnsiCode = '39'); $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; $theme = Get-ActiveTheme; if($null -eq $theme){ return $DefaultAnsiCode }; $currentValue = $theme; $pathSegments = $PropertyPath.Split('.'); try { foreach($segment in $pathSegments) { if ($currentValue -is [hashtable] -and $currentValue.ContainsKey($segment)) { $currentValue = $currentValue[$segment] } else { $logFunc.Invoke("Theme ANSI path not found: '$PropertyPath' (segment: '$segment'). Using default.", "DEBUG"); return $DefaultAnsiCode } } } catch { $logFunc.Invoke("Error traversing theme for '$PropertyPath'. Using default. Error: $($_.Exception.Message)", "WARN"); return $DefaultAnsiCode }; $recursionGuard = 0; while ($currentValue -is [string] -and $currentValue.StartsWith('$Palette:') -and $recursionGuard -lt 5) { $recursionGuard++; $paletteKey = $currentValue.Substring(9); if ($theme.Palette.ContainsKey($paletteKey)) { $currentValue = $theme.Palette[$paletteKey] } else { $logFunc.Invoke("Palette key '$paletteKey' not found for '$PropertyPath'. Using default.", "WARN"); return $DefaultAnsiCode } }; if($recursionGuard -ge 5){ $logFunc.Invoke("Palette resolution exceeded max depth for '$PropertyPath'. Using default.", "WARN"); return $DefaultAnsiCode }; if ($currentValue -is [string] -and $currentValue -match '^(3[0-79]|9[0-7]|10[0-7]|38;2;\d{1,3};\d{1,3};\d{1,3}|4[0-79]|10[0-7]|48;2;\d{1,3};\d{1,3};\d{1,3})$') { return $currentValue } else { $logFunc.Invoke("Invalid ANSI code format '$currentValue' found for '$PropertyPath'. Using default.", "WARN"); return $DefaultAnsiCode } }
function Format-WithAnsi { param([string]$Text, [string]$FG_Ansi = '39', [string]$BG_Ansi = '49'); $esc = $Global:esc; return "${esc}[${FG_Ansi}m${esc}[${BG_Ansi}m${Text}${esc}[39m${esc}[49m" }
#endregion

#region Settings Configuration Functions (v19.2 - Functional)
function Load-SettingsScreenData {
    Write-AppLog "Loading data for Settings screen." "INFO"
    if ($null -eq $Global:AppConfig) { Load-AppConfig }
    if ($null -eq $Global:AppConfig) {
        Show-Error "Cannot load settings - AppConfig failed to load."
        Navigate-Back | Out-Null
        return
    }
    # Create a temporary copy to edit
    $script:TempSettings = $Global:AppConfig.Clone()
    Write-AppLog "Cloned Global:AppConfig to script:TempSettings." "DEBUG"
}

function Select-SettingsTheme {
    Write-AppLog "Starting theme selection." "DEBUG"
    $availableThemes = Get-LoadedThemeNames
    if ($availableThemes.Count -eq 0) {
        Show-Warning "No themes available to select."
        return
    }
    $currentTheme = $script:TempSettings.defaultTheme ?? "None"
    $selectionItems = @($availableThemes | ForEach-Object -Begin {$idx = 0} -Process { [PSCustomObject]@{ Index = ++$idx; DisplayValue = $_ } })
    $currentThemeIndex = -1
    for ($i = 0; $i -lt $selectionItems.Count; $i++) {
        if ($selectionItems[$i].DisplayValue -eq $currentTheme) {
            $currentThemeIndex = $i
            break
        }
    }
    $initialIndexValue = if ($currentThemeIndex -ge 0) { $currentThemeIndex } else { 0 }

    # Use Select-ItemFromList for theme selection
    $selectParams = @{
        Title = "SELECT DEFAULT THEME"
        Items = $selectionItems
        ViewType = "SelectionList" # Use the generic list view
        Prompt = "Select new default theme (Current: $currentTheme)"
        InitialIndex = $initialIndexValue # Pre-select current theme if possible
        OnItemSelected = {
            param($selectedItem, $tempDataSelect) # $tempDataSelect is not used here
            if ($null -ne $selectedItem) {
                $script:TempSettings.defaultTheme = $selectedItem.DisplayValue
                Write-AppLog "Theme selection updated in TempSettings: $($script:TempSettings.defaultTheme)" "INFO"
                Show-Info "Theme selection updated (pending save)." 3
                # No need to navigate back here, Select-ItemFromList handles it
            } else {
                Write-AppLog "Theme selection OnItemSelected called with null item." "WARN"
            }
        }
        OnCancel = {
            param($tempDataCancel) # $tempDataCancel is not used here
            Write-AppLog "Theme selection cancelled." "INFO"
            Show-Warning "Theme selection cancelled."
            # No need to navigate back here, Select-ItemFromList handles it
        }
        # No InitialTempData needed specifically for this selection list itself
    }
    Select-ItemFromList @selectParams
}

function Save-SettingsChanges {
    Write-AppLog "Attempting to save settings changes." "INFO"
    if ($null -eq $script:TempSettings) {
        Write-AppLog "Save-SettingsChanges: script:TempSettings is null. Cannot save." "ERROR"
        Show-Error "Internal Error: No settings data to save."
        return
    }

    # --- Validation ---
    $isValid = $true
    # Validate Log Size
    $logSize = 0
    if (-not ([int]::TryParse($script:TempSettings.logMaxSizeMB, [ref]$logSize)) -or $logSize -le 0) {
        Show-Error "Invalid Log Size. Must be a positive integer."
        $isValid = $false
    }
    # Validate CAA Path (basic check for invalid chars)
    if (-not ([string]::IsNullOrWhiteSpace($script:TempSettings.caaTemplatePath)) -and $script:TempSettings.caaTemplatePath -match '[<>:"/\\|?*]') {
        Show-Error "CAA Template Path contains invalid characters."
        $isValid = $false
    }
    # Validate Theme Name
    if (-not ($script:LoadedThemes.ContainsKey($script:TempSettings.defaultTheme))) {
        Show-Error "Invalid theme name selected: '$($script:TempSettings.defaultTheme)'"
        $isValid = $false
    }
    # Add more validation as needed...

    if (-not $isValid) {
        Write-AppLog "Settings validation failed." "WARN"
        return # Stay on settings screen
    }

    # --- Apply Changes ---
    $themeChanged = ($Global:AppConfig.defaultTheme -ne $script:TempSettings.defaultTheme)
    $Global:AppConfig = $script:TempSettings.Clone() # Apply changes to global config
    $script:TempSettings = $null # Discard temp copy

    # --- Save and Navigate ---
    if (Save-AppConfig) {
        Show-Success "Configuration saved successfully."
        if ($themeChanged) {
            Write-AppLog "Applying new theme '$($Global:AppConfig.defaultTheme)' after save." "INFO"
            if (Set-ActiveTheme -ThemeName $Global:AppConfig.defaultTheme) {
                Invoke-PmcRenderRequest -ForceRedraw $true
            } else {
                Show-Warning "Failed to apply the new theme '$($Global:AppConfig.defaultTheme)'. Check theme name."
            }
        }
        Navigate-Back | Out-Null # Go back to previous screen
    } else {
        Show-Error "Failed to save configuration file. Changes applied in memory only."
        Navigate-Back | Out-Null # Still go back, but warn user
    }
}

function Edit-Setting_CAAPath {
    Write-AppLog "Triggering edit for CAA Path from Settings screen." "DEBUG"
    if ($null -eq $script:TempSettings) {
        Write-AppLog "Edit-Setting_CAAPath: TempSettings is null!" "ERROR"
        return
    }
    # Pass a reference to TempSettings via InitialTempData if needed by callbacks
    $tempDataForEdit = @{ TempSettingsRef = $script:TempSettings }
    $initialPath = $script:TempSettings.caaTemplatePath ?? $Global:scriptRoot # Start in script root if not set

    $requestParams = @{
        Prompt = "Select Master CAA Template Path"
        InitialPath = $initialPath
        SelectFolder = $false # We need a file
        OnPathSelected = {
            param($pathInput, $tempDataSubmit)
            # Use the reference passed in TempData
            $tempDataSubmit.TempSettingsRef.caaTemplatePath = $pathInput.Trim()
            Write-AppLog "Settings Edit: Updated CAAPath in TempSettings: $($tempDataSubmit.TempSettingsRef.caaTemplatePath)" "DEBUG"
            Show-Info "CAA Path updated (pending save)." 3
            # Request-FilePath handles navigation back implicitly
        }
        OnCancel = {
            param($tempDataCancel)
            Write-AppLog "Settings Edit: CAAPath edit cancelled." "INFO"
            Show-Warning "Edit cancelled."
            # Request-FilePath handles navigation back implicitly
        }
        InitialTempData = $tempDataForEdit
    }
    Request-FilePath @requestParams
}

function Edit-Setting_LogSize {
    Write-AppLog "Triggering edit for Log Size from Settings screen." "DEBUG"
    if ($null -eq $script:TempSettings) {
        Write-AppLog "Edit-Setting_LogSize: TempSettings is null!" "ERROR"
        return
    }
    $tempDataForEdit = @{ TempSettingsRef = $script:TempSettings }
    $requestParams = @{
        Prompt = "Max Log Size (MB, e.g., 10)"
        DefaultValue = ($script:TempSettings.logMaxSizeMB ?? 10).ToString()
        ValidationCallback = {
            param($input)
            $size = 0
            if (-not ([int]::TryParse($input, [ref]$size)) -or $size -le 0) { return $false }
            return $true
        }
        ValidationErrorMessage = "Invalid size. Must be a positive integer."
        SubmitCallback = {
            param($sizeInput, $tempDataSubmit)
            [int]::TryParse($sizeInput, [ref]$tempDataSubmit.TempSettingsRef.logMaxSizeMB) | Out-Null
            Write-AppLog "Settings Edit: Updated LogSize in TempSettings: $($tempDataSubmit.TempSettingsRef.logMaxSizeMB)" "DEBUG"
            # Request-TextInput handles navigation back implicitly
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Settings Edit: LogSize edit cancelled." "INFO"
            Show-Warning "Edit cancelled."
            # Request-TextInput handles navigation back implicitly
        }
        InitialTempData = $tempDataForEdit
    }
    Request-TextInput @requestParams
}
#endregion

#region Drawing Primitives
function Get-PmcBorderStyleChars { param([string]$StyleName); $logFunc = { param($Msg, $Lvl="WARN") Write-AppLog $Msg $Lvl }; if ($null -eq $Global:borderStyles) { $logFunc.Invoke("Get-PmcBorderStyleChars: Global:borderStyles is null. Falling back to Single.", "ERROR"); return @{ TL='┌'; T='─'; TR='┐'; L='│'; R='│'; BL='└'; B='─'; BR='┘'; LJ='├'; RJ='┤'; TJ='┬'; BJ='┴'; C='┼' } }; if ($Global:borderStyles.ContainsKey($StyleName)) { return $Global:borderStyles[$StyleName] } else { $logFunc.Invoke("Border style '$StyleName' not found. Falling back to 'Single'.", "WARN"); if ($Global:borderStyles.ContainsKey("Single")) { return $Global:borderStyles["Single"] } else { $logFunc.Invoke("Fallback border style 'Single' also not found!", "ERROR"); return @{ TL='┌'; T='─'; TR='┐'; L='│'; R='│'; BL='└'; B='─'; BR='┘'; LJ='├'; RJ='┤'; TJ='┬'; BJ='┴'; C='┼' } } } }
function Draw-BoxToBuffer { param ([Parameter(Mandatory=$true)][int]$X, [Parameter(Mandatory=$true)][int]$Y, [Parameter(Mandatory=$true)][int]$Width, [Parameter(Mandatory=$true)][int]$Height, [string]$BorderStyle = "Single", [string]$FG_Ansi = $null, [string]$BG_Ansi = $null, [switch]$Fill = $false, [string]$FillChar = " ", [hashtable]$ClippingView = $null); $effectiveFG = if ($null -ne $FG_Ansi) { $FG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderFG" }; $effectiveBG = if ($null -ne $BG_Ansi) { $BG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderBG" }; $fillFG = $effectiveFG; $fillBG = $effectiveBG; $borderChars = Get-PmcBorderStyleChars -StyleName $BorderStyle; $TL = $borderChars.TL; $T = $borderChars.T; $TR = $borderChars.TR; $L = $borderChars.L; $R = $borderChars.R; $BL = $borderChars.BL; $B = $borderChars.B; $BR = $borderChars.BR; $endX = $X + $Width - 1; $endY = $Y + $Height - 1; Write-CellToBuffer -X $X -Y $Y -Cell @{ Char=$TL; FG_Ansi=$effectiveFG; BG_Ansi=$effectiveBG } -ClippingView $ClippingView; Write-CellToBuffer -X $endX -Y $Y -Cell @{ Char=$TR; FG_Ansi=$effectiveFG; BG_Ansi=$effectiveBG } -ClippingView $ClippingView; Write-CellToBuffer -X $endX -Y $endY -Cell @{ Char=$BR; FG_Ansi=$effectiveFG; BG_Ansi=$effectiveBG } -ClippingView $ClippingView; Write-CellToBuffer -X $X -Y $endY -Cell @{ Char=$BL; FG_Ansi=$effectiveFG; BG_Ansi=$effectiveBG } -ClippingView $ClippingView; $hLineStartX = $X + 1; $hLineEndX = $endX - 1; $hLineLen = $hLineEndX - $hLineStartX + 1; if ($hLineLen -gt 0) { $topLine = $T * $hLineLen; $bottomLine = $B * $hLineLen; Write-StringToBuffer -TargetX $hLineStartX -TargetY $Y -String $topLine -FG_Ansi $effectiveFG -BG_Ansi $effectiveBG -ClippingView $ClippingView; Write-StringToBuffer -TargetX $hLineStartX -TargetY $endY -String $bottomLine -FG_Ansi $effectiveFG -BG_Ansi $effectiveBG -ClippingView $ClippingView }; $vLineStartY = $Y + 1; $vLineEndY = $endY - 1; if ($vLineEndY -ge $vLineStartY) { for ($i = $vLineStartY; $i -le $vLineEndY; $i++) { Write-CellToBuffer -X $X -Y $i -Cell @{ Char=$L; FG_Ansi=$effectiveFG; BG_Ansi=$effectiveBG } -ClippingView $ClippingView; Write-CellToBuffer -X $endX -Y $i -Cell @{ Char=$R; FG_Ansi=$effectiveFG; BG_Ansi=$effectiveBG } -ClippingView $ClippingView; if ($Fill) { $fillStartX = $X + 1; $fillEndX = $endX - 1; $fillLen = $fillEndX - $fillStartX + 1; if ($fillLen -gt 0) { $fillLine = $FillChar * $fillLen; Write-StringToBuffer -TargetX $fillStartX -TargetY $i -String $fillLine -FG_Ansi $fillFG -BG_Ansi $fillBG -ClippingView $ClippingView } } } } }
function Draw-HorizontalLineToBuffer { param ([Parameter(Mandatory=$true)][int]$X, [Parameter(Mandatory=$true)][int]$Y, [Parameter(Mandatory=$true)][int]$Length, [string]$Char = "─", [string]$FG_Ansi = $null, [string]$BG_Ansi = $null, [hashtable]$ClippingView = $null); $effectiveFG = if ($null -ne $FG_Ansi) { $FG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderFG" }; $effectiveBG = if ($null -ne $BG_Ansi) { $BG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderBG" }; if ($Length -gt 0) { $line = $Char * $Length; Write-StringToBuffer -TargetX $X -TargetY $Y -String $line -FG_Ansi $effectiveFG -BG_Ansi $effectiveBG -ClippingView $ClippingView } }
function Draw-VerticalLineToBuffer { param ([Parameter(Mandatory=$true)][int]$X, [Parameter(Mandatory=$true)][int]$Y, [Parameter(Mandatory=$true)][int]$Height, [string]$Char = "│", [string]$FG_Ansi = $null, [string]$BG_Ansi = $null, [hashtable]$ClippingView = $null); $effectiveFG = if ($null -ne $FG_Ansi) { $FG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderFG" }; $effectiveBG = if ($null -ne $BG_Ansi) { $BG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderBG" }; $endY = $Y + $Height - 1; for ($i = $Y; $i -le $endY; $i++) { Write-CellToBuffer -X $X -Y $i -Cell @{ Char=$Char; FG_Ansi=$effectiveFG; BG_Ansi=$effectiveBG } -ClippingView $ClippingView } }
function Draw-TextInBoxToBuffer { param ([Parameter(Mandatory=$true)][int]$X, [Parameter(Mandatory=$true)][int]$Y, [Parameter(Mandatory=$true)][int]$Width, [Parameter(Mandatory=$true)][int]$Height, [string]$Text = "", [string]$BorderStyle = "Single", [string]$BorderFG_Ansi = $null, [string]$BorderBG_Ansi = $null, [string]$TextFG_Ansi = $null, [string]$TextBG_Ansi = $null, [ValidateSet("Left", "Center", "Right")][string]$HAlign = "Center", [ValidateSet("Top", "Middle", "Bottom")][string]$VAlign = "Middle", [switch]$Fill = $false, [hashtable]$ClippingView = $null); $effectiveBorderFG = if ($null -ne $BorderFG_Ansi) { $BorderFG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderFG" }; $effectiveBorderBG = if ($null -ne $BorderBG_Ansi) { $BorderBG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderBG" }; $effectiveTextFG = if ($null -ne $TextFG_Ansi) { $TextFG_Ansi } else { Get-PmcThemeAnsiCode "Palette.DataFG" }; $effectiveTextBG = if ($null -ne $TextBG_Ansi) { $TextBG_Ansi } else { Get-PmcThemeAnsiCode "Palette.PrimaryBG" }; Draw-BoxToBuffer -X $X -Y $Y -Width $Width -Height $Height -BorderStyle $BorderStyle -FG_Ansi $effectiveBorderFG -BG_Ansi $effectiveBorderBG -Fill:$Fill -ClippingView $ClippingView; $innerWidth = $Width - 2; $innerHeight = $Height - 2; if ([string]::IsNullOrEmpty($Text) -or $innerWidth -le 0 -or $innerHeight -le 0) { return }; $displayText = $Text; if (Measure-StringWidth $Text -gt $innerWidth) { $displayText = $Text.Substring(0, [Math]::Max(0, $innerWidth - 1)) + "…" }; $textX = $X + 1; if ($HAlign -eq "Center") { $textX = $X + 1 + [Math]::Floor(($innerWidth - (Measure-StringWidth $displayText)) / 2) } elseif ($HAlign -eq "Right") { $textX = $X + 1 + $innerWidth - (Measure-StringWidth $displayText) }; $textY = $Y + 1; if ($VAlign -eq "Middle") { $textY = $Y + 1 + [Math]::Floor(($innerHeight - 1) / 2) } elseif ($VAlign -eq "Bottom") { $textY = $Y + $innerHeight }; $textClipView = @{ X = $X + 1; Y = $Y + 1; Width = $innerWidth; Height = $innerHeight }; if ($ClippingView) { $textClipView.X = [Math]::Max($textClipView.X, $ClippingView.X); $textClipView.Y = [Math]::Max($textClipView.Y, $ClippingView.Y); $textClipView.Width = [Math]::Min($X + 1 + $innerWidth, $ClippingView.X + $ClippingView.Width) - $textClipView.X; $textClipView.Height = [Math]::Min($Y + 1 + $innerHeight, $ClippingView.Y + $ClippingView.Height) - $textClipView.Y }; Write-StringToBuffer -TargetX $textX -TargetY $textY -String $displayText -FG_Ansi $effectiveTextFG -BG_Ansi $effectiveTextBG -ClippingView $textClipView }
function Draw-ProgressBarToBuffer { param ([Parameter(Mandatory=$true)][int]$X, [Parameter(Mandatory=$true)][int]$Y, [Parameter(Mandatory=$true)][int]$Width, [ValidateRange(0, 100)][int]$Percentage = 0, [switch]$ShowPercentage = $false, [string]$FillChar = "█", [string]$EmptyChar = "░", [string]$FillFG_Ansi = $null, [string]$FillBG_Ansi = $null, [string]$EmptyFG_Ansi = $null, [string]$EmptyBG_Ansi = $null, [string]$BorderStyle = "None", [string]$BorderFG_Ansi = $null, [string]$BorderBG_Ansi = $null, [hashtable]$ClippingView = $null); $effectiveFillFG = if ($null -ne $FillFG_Ansi) { $FillFG_Ansi } else { Get-PmcThemeAnsiCode "Palette.HighlightFG" }; $effectiveFillBG = if ($null -ne $FillBG_Ansi) { $FillBG_Ansi } else { Get-PmcThemeAnsiCode "Palette.HighlightBG" }; $effectiveEmptyFG = if ($null -ne $EmptyFG_Ansi) { $EmptyFG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderFG" }; $effectiveEmptyBG = if ($null -ne $EmptyBG_Ansi) { $EmptyBG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderBG" }; $effectiveBorderFG = if ($null -ne $BorderFG_Ansi) { $BorderFG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderFG" }; $effectiveBorderBG = if ($null -ne $BorderBG_Ansi) { $BorderBG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderBG" }; $percentTextFG = Get-PmcThemeAnsiCode "Palette.DataFG"; $percentTextBG = ""; $hasBorder = $BorderStyle -ne "None"; $borderAdjustment = if ($hasBorder) { 2 } else { 0 }; $barHeight = if ($hasBorder) { 3 } else { 1 }; $innerX = $X + (if ($hasBorder) { 1 } else { 0 }); $innerY = $Y + (if ($hasBorder) { 1 } else { 0 }); $innerWidth = $Width - $borderAdjustment; if ($innerWidth -le 0) { return }; if ($hasBorder) { Draw-BoxToBuffer -X $X -Y $Y -Width $Width -Height $barHeight -BorderStyle $BorderStyle -FG_Ansi $effectiveBorderFG -BG_Ansi $effectiveBorderBG -ClippingView $ClippingView }; $fillWidth = [Math]::Floor($innerWidth * ($Percentage / 100)); $emptyWidth = $innerWidth - $fillWidth; $innerClipView = @{ X = $innerX; Y = $innerY; Width = $innerWidth; Height = 1 }; if ($ClippingView) { $innerClipView.X = [Math]::Max($innerClipView.X, $ClippingView.X); $innerClipView.Y = [Math]::Max($innerClipView.Y, $ClippingView.Y); $innerClipView.Width = [Math]::Min($innerX + $innerWidth, $ClippingView.X + $ClippingView.Width) - $innerClipView.X; $innerClipView.Height = [Math]::Min($innerY + 1, $ClippingView.Y + $ClippingView.Height) - $innerClipView.Y }; if ($innerClipView.Width -le 0 -or $innerClipView.Height -le 0) { return }; if ($fillWidth -gt 0) { $fillString = $FillChar * $fillWidth; Write-StringToBuffer -TargetX $innerX -TargetY $innerY -String $fillString -FG_Ansi $effectiveFillFG -BG_Ansi $effectiveFillBG -ClippingView $innerClipView }; if ($emptyWidth -gt 0) { $emptyString = $EmptyChar * $emptyWidth; Write-StringToBuffer -TargetX ($innerX + $fillWidth) -TargetY $innerY -String $emptyString -FG_Ansi $effectiveEmptyFG -BG_Ansi $effectiveEmptyBG -ClippingView $innerClipView }; if ($ShowPercentage) { $percentText = "$Percentage%"; $percentX = $innerX + [Math]::Floor(($innerWidth - (Measure-StringWidth $percentText)) / 2); Write-StringToBuffer -TargetX $percentX -TargetY $innerY -String $percentText -FG_Ansi $percentTextFG -BG_Ansi $percentTextBG -ClippingView $innerClipView } }
function Draw-ScrollbarToBuffer { param ([Parameter(Mandatory=$true)][int]$X, [Parameter(Mandatory=$true)][int]$Y, [Parameter(Mandatory=$true)][int]$Height, [Parameter(Mandatory=$true)][int]$TotalItems, [Parameter(Mandatory=$true)][int]$VisibleItems, [Parameter(Mandatory=$true)][int]$CurrentPosition, [string]$ScrollBarChar = "█", [string]$TrackChar = "░", [string]$ScrollBarFG_Ansi = $null, [string]$ScrollBarBG_Ansi = $null, [string]$TrackFG_Ansi = $null, [string]$TrackBG_Ansi = $null, [hashtable]$ClippingView = $null); $effectiveScrollFG = if ($null -ne $ScrollBarFG_Ansi) { $ScrollBarFG_Ansi } else { Get-PmcThemeAnsiCode "Palette.HighlightFG" }; $effectiveScrollBG = if ($null -ne $ScrollBarBG_Ansi) { $ScrollBarBG_Ansi } else { Get-PmcThemeAnsiCode "Palette.HighlightBG" }; $effectiveTrackFG = if ($null -ne $TrackFG_Ansi) { $TrackFG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderFG" }; $effectiveTrackBG = if ($null -ne $TrackBG_Ansi) { $TrackBG_Ansi } else { Get-PmcThemeAnsiCode "Palette.BorderBG" }; if ($TotalItems -le $VisibleItems -or $Height -le 0) { return }; $thumbSize = [Math]::Max(1, [Math]::Floor($Height * ($VisibleItems / $TotalItems))); $maxPos = $TotalItems - $VisibleItems; $pos = [Math]::Max(0, [Math]::Min($CurrentPosition, $maxPos)); $thumbYOffset = if ($maxPos -eq 0) { 0 } else { [Math]::Floor(($Height - $thumbSize) * ($pos / $maxPos)) }; $scrollClipView = @{ X = $X; Y = $Y; Width = 1; Height = $Height }; if ($ClippingView) { $scrollClipView.X = [Math]::Max($scrollClipView.X, $ClippingView.X); $scrollClipView.Y = [Math]::Max($scrollClipView.Y, $ClippingView.Y); $scrollClipView.Width = [Math]::Min($X + 1, $ClippingView.X + $ClippingView.Width) - $scrollClipView.X; $scrollClipView.Height = [Math]::Min($Y + $Height, $ClippingView.Y + $ClippingView.Height) - $scrollClipView.Y }; if ($scrollClipView.Width -le 0 -or $scrollClipView.Height -le 0) { return }; for ($i = 0; $i -lt $scrollClipView.Height; $i++) { $currentBufferY = $scrollClipView.Y + $i; $relativeY = $currentBufferY - $Y; $isThumb = ($relativeY -ge $thumbYOffset) -and ($relativeY -lt ($thumbYOffset + $thumbSize)); $char = if ($isThumb) { $ScrollBarChar } else { $TrackChar }; $fg = if ($isThumb) { $effectiveScrollFG } else { $effectiveTrackFG }; $bg = if ($isThumb) { $effectiveScrollBG } else { $effectiveTrackBG }; Write-CellToBuffer -X $scrollClipView.X -Y $currentBufferY -Cell @{ Char=$char; FG_Ansi=$fg; BG_Ansi=$bg } -ClippingView $scrollClipView } }
function Measure-StringWidth { param ([string]$String); if ([string]::IsNullOrEmpty($String)) { return 0 }; $cleanString = $String -replace '\x1B\[[0-9;]*[mK]', ''; $width = 0; foreach ($char in $cleanString.ToCharArray()) { $code = [int][char]$char; if (($code -ge 0x1100 -and $code -le 0x115F) -or ($code -ge 0x2329 -and $code -le 0x232A) -or ($code -ge 0x2E80 -and $code -le 0x3247 -and $code -ne 0x303F) -or ($code -ge 0x3250 -and $code -le 0x4DBF) -or ($code -ge 0x4E00 -and $code -le 0xA4C6) -or ($code -ge 0xA960 -and $code -le 0xA97C) -or ($code -ge 0xAC00 -and $code -le 0xD7A3) -or ($code -ge 0xF900 -and $code -le 0xFAFF) -or ($code -ge 0xFE10 -and $code -le 0xFE19) -or ($code -ge 0xFE30 -and $code -le 0xFE6F) -or ($code -ge 0xFF01 -and $code -le 0xFF60) -or ($code -ge 0xFFE0 -and $code -le 0xFFE6) -or ($code -ge 0x1B000 -and $code -le 0x1B001) -or ($code -ge 0x1F200 -and $code -le 0x1F251) -or ($code -ge 0x1F300 -and $code -le 0x1F64F) -or ($code -ge 0x1F680 -and $code -le 0x1F6FF) -or ($code -ge 0x20000 -and $code -le 0x3FFFD)) { $width += 2 } elseif ($code -ge 0x0000 -and $code -le 0x001F) { $width += 0 } else { $width += 1 } }; return $width }
function Get-TextWrapped { param ([string]$Text, [int]$Width, [switch]$BreakOnWords = $true); if ([string]::IsNullOrEmpty($Text) -or $Width -le 0) { return @() }; $lines = [System.Collections.Generic.List[string]]::new(); $paragraphs = $Text -split "`n"; foreach ($paragraph in $paragraphs) { if ([string]::IsNullOrEmpty($paragraph)) { $lines.Add(""); continue }; if ($BreakOnWords) { $words = $paragraph -split ' '; $currentLine = ""; $firstWord = $true; foreach ($word in $words) { $wordWidth = Measure-StringWidth $word; $testLine = if ($firstWord) { $word } else { "$currentLine $word" }; $testLineWidth = Measure-StringWidth $testLine; if ($testLineWidth -le $Width) { $currentLine = $testLine; $firstWord = $false } else { if (-not $firstWord) { $lines.Add($currentLine) }; if ($wordWidth -gt $Width) { $remainingWord = $word; while (Measure-StringWidth $remainingWord -gt $Width) { $breakPos = 0; $currentWidth = 0; foreach ($char in $remainingWord.ToCharArray()) { $charWidth = Measure-StringWidth $char.ToString(); if (($currentWidth + $charWidth) -le $Width) { $currentWidth += $charWidth; $breakPos++ } else { break } }; $lines.Add($remainingWord.Substring(0, $breakPos)); $remainingWord = $remainingWord.Substring($breakPos) }; $currentLine = $remainingWord } else { $currentLine = $word }; $firstWord = ($currentLine -eq "") } }; if (-not [string]::IsNullOrEmpty($currentLine)) { $lines.Add($currentLine) } } else { $remaining = $paragraph; while (Measure-StringWidth $remaining -gt 0) { $breakPos = 0; $currentWidth = 0; foreach ($char in $remaining.ToCharArray()) { $charWidth = Measure-StringWidth $char.ToString(); if (($currentWidth + $charWidth) -le $Width) { $currentWidth += $charWidth; $breakPos++ } else { break } }; $lines.Add($remaining.Substring(0, $breakPos)); $remaining = $remaining.Substring($breakPos) } } }; return $lines.ToArray() }
#endregion

#region UI Helper Functions
function Draw-Title { param ([string]$Title); $theme = Get-ActiveTheme; $titleFG = Get-PmcThemeAnsiCode "WindowTitle.FG" '97'; $titleBG = Get-PmcThemeAnsiCode "WindowTitle.BG" '44'; $borderFG = Get-PmcThemeAnsiCode "WindowTitle.Border.FG" '90'; $borderBG = Get-PmcThemeAnsiCode "WindowTitle.Border.BG" $titleBG; $linesAbove = Get-PmcThemeProperty $theme "WindowTitle.LinesAbove" 0 "Integer"; $linesBelow = Get-PmcThemeProperty $theme "WindowTitle.LinesBelow" 0 "Integer"; $borderStyleName = Get-PmcThemeProperty $theme "WindowTitle.Border.Style" "Single" "String"; $borderChars = $Global:borderStyles[$borderStyleName]; $width = 80; try { $width = $Host.UI.RawUI.WindowSize.Width - 1 } catch {}; if ($width -lt 10) { $width = 80 }; $padding = Get-PmcThemeProperty $theme "WindowTitle.Pad" 1 "Integer"; $displayTitle = $Title.ToUpper(); $paddedTitle = (" " * $padding) + $displayTitle + (" " * $padding); $plainPaddedTitleLength = ($paddedTitle | Measure-Object -Character).Count; if ($plainPaddedTitleLength -gt $width) { $paddedTitle = $paddedTitle.Substring(0, $width - 4) + "... "; $plainPaddedTitleLength = ($paddedTitle | Measure-Object -Character).Count }; $paddingLength = $width - $plainPaddedTitleLength; $leftPadChars = $borderChars.T * [Math]::Max(0, [Math]::Floor($paddingLength / 2)); $rightPadChars = $borderChars.T * [Math]::Max(0, [Math]::Ceiling($paddingLength / 2)); $titleLineContent = $leftPadChars + $paddedTitle + $rightPadChars; if ($titleLineContent.Length -lt $width) { $titleLineContent += $borderChars.T * ($width - $titleLineContent.Length) } elseif ($titleLineContent.Length -gt $width) { $titleLineContent = $titleLineContent.Substring(0, $width) }; $borderLineText = $borderChars.T * $width; $borderLine = Format-WithAnsi -Text $borderLineText -FG_Ansi $borderFG -BG_Ansi $borderBG; $titleLine = Format-WithAnsi -Text $titleLineContent -FG_Ansi $titleFG -BG_Ansi $titleBG; if ($linesAbove -gt 0) { Write-Host ("`n" * $linesAbove) } else { Write-Host "" }; Write-Host $borderLine; Write-Host $titleLine; Write-Host $borderLine; if ($linesBelow -gt 0) { Write-Host ("`n" * $linesBelow) } else { Write-Host "" } }
function Show-Message { param([string]$Message, [ValidateSet("Success", "Error", "Warning", "Info")][string]$Type = "Info", [int]$TimeoutSeconds = 0); $script:StatusMessage.Text = $Message; $script:StatusMessage.Type = $Type; if ($TimeoutSeconds -gt 0) { $script:StatusMessage.Timeout = (Get-Date).AddSeconds($TimeoutSeconds) } else { $script:StatusMessage.Timeout = $null }; $null = Invoke-PmcRenderRequest }
function Show-Success { param([string]$Message, [int]$TimeoutSeconds = 3) Show-Message -Message $Message -Type Success -TimeoutSeconds $TimeoutSeconds }
function Show-Error   { param([string]$Message, [int]$TimeoutSeconds = 0) Show-Message -Message $Message -Type Error -TimeoutSeconds $TimeoutSeconds }
function Show-Warning { param([string]$Message, [int]$TimeoutSeconds = 5) Show-Message -Message $Message -Type Warning -TimeoutSeconds $TimeoutSeconds }
function Show-Info    { param([string]$Message, [int]$TimeoutSeconds = 3) Show-Message -Message $Message -Type Info -TimeoutSeconds $TimeoutSeconds }
function Pause-Screen { param([string]$Message = "Press Enter to continue..."); $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; Show-Message -Message $Message -Type Info -TimeoutSeconds 0; $logFunc.Invoke("Pause-Screen: Blocking for key press..."); Write-Host ""; $originalCursorVisible = $true; try { try { $originalCursorVisible = [Console]::CursorVisible; [Console]::CursorVisible = $false } catch {}; $null = [Console]::ReadKey($true); try { [Console]::CursorVisible = $originalCursorVisible } catch {} } catch { $logFunc.Invoke("Pause-Screen: Failed during ReadKey. Error: $($_.Exception.Message)", "WARN"); Read-Host | Out-Null } finally { $logFunc.Invoke("Pause-Screen: Key pressed."); Show-Message ""; if ($script:keepRunning) { $null = Invoke-PmcRenderRequest -ForceRedraw $true; $logFunc.Invoke("Pause-Screen: Full redraw requested.") } } }
function Show-ExcelProgress { param([string]$Activity = "Processing Excel Operation", [int]$PercentComplete = -1, [string]$Status = "", [int]$Current = 0, [int]$Total = 100, [switch]$Complete = $false, [int]$ID = 1); if ($Complete) { Write-Progress -Activity $Activity -Status "Complete" -PercentComplete 100 -Completed -Id $ID; return }; if ($PercentComplete -eq -1 -and $Total -gt 0) { $PercentComplete = [Math]::Min([Math]::Floor(($Current / $Total) * 100), 100) }; if ([string]::IsNullOrEmpty($Status) -and $Total -gt 0) { $Status = "Processing $Current of $Total items" }; $PercentComplete = [Math]::Max(0, [Math]::Min(100, $PercentComplete)); Write-Progress -Activity $Activity -Status $Status -PercentComplete $PercentComplete -Id $ID }
#endregion

#region View Rendering Functions
function Render-LabelView { param( [Parameter(Mandatory = $true)][hashtable]$ViewDefinition ); $logFunc = { param($Msg, $Lvl="TRACE") Write-AppLog $Msg $Lvl }; $x = $ViewDefinition.X; $y = $ViewDefinition.Y; $width = $ViewDefinition.Width; $height = $ViewDefinition.Height; if ($width -le 0 -or $height -le 0) { return }; $clipView = @{ X = $x; Y = $y; Width = $width; Height = $height }; $text = ""; try { if ($ViewDefinition.Text -is [scriptblock]) { $text = & $ViewDefinition.Text } else { $text = $ViewDefinition.Text ?? "" } } catch { $logFunc.Invoke("Error executing Text scriptblock for '$($ViewDefinition.Name)': $($_.Exception.Message)", "WARN"); $text = "[ERR]" }; $hAlign = $ViewDefinition.HAlign ?? 'Left'; $elementName = $ViewDefinition.Name ?? 'LabelView'; $fgAnsi = ""; try { if ($ViewDefinition.FG_Ansi -is [scriptblock]) { $fgAnsi = & $ViewDefinition.FG_Ansi } elseif ($ViewDefinition.FG_Ansi) { $fgAnsi = $ViewDefinition.FG_Ansi } else { $fgAnsi = Get-PmcThemeAnsiCode "$elementName.FG" '39' } } catch { $logFunc.Invoke("Error executing FG_Ansi scriptblock for '$($ViewDefinition.Name)': $($_.Exception.Message)", "WARN"); $fgAnsi = '39' }; $bgAnsi = ""; try { if ($ViewDefinition.BG_Ansi -is [scriptblock]) { $bgAnsi = & $ViewDefinition.BG_Ansi } elseif ($ViewDefinition.BG_Ansi) { $bgAnsi = $ViewDefinition.BG_Ansi } else { $bgAnsi = Get-PmcThemeAnsiCode "$elementName.BG" '49' } } catch { $logFunc.Invoke("Error executing BG_Ansi scriptblock for '$($ViewDefinition.Name)': $($_.Exception.Message)", "WARN"); $bgAnsi = '49' }; $isFocused = $ViewDefinition.IsFocusable -and $ViewDefinition.Name -eq $script:FocusedViewName; if ($isFocused) { $focusFG = Get-PmcThemeAnsiCode "Palette.FocusTextFG" $fgAnsi; $focusBG = Get-PmcThemeAnsiCode "Palette.FocusTextBG" $bgAnsi; $fgAnsi = $focusFG; $bgAnsi = $focusBG }; $displayText = $text; $textLength = Measure-StringWidth $displayText; if ($textLength -gt $width) { $displayText = $displayText.Substring(0, [Math]::Min($displayText.Length, $width - 1)) + "…"; $textLength = Measure-StringWidth $displayText }; switch ($hAlign.ToLowerInvariant()) { 'center' { $padTotal = $width - $textLength; $padLeft = [Math]::Floor($padTotal / 2); $padRight = $padTotal - $padLeft; $displayText = (' ' * $padLeft) + $displayText + (' ' * $padRight) } 'right' { $displayText = $displayText.PadLeft($width) } default { $displayText = $displayText.PadRight($width) } }; Write-StringToBuffer -TargetX $x -TargetY $y -Text $displayText -FG_Ansi $fgAnsi -BG_Ansi $bgAnsi -ClippingView $clipView; if ($height -gt 1) { $clearLine = ' ' * $width; for ($clearY = $y + 1; $clearY -lt ($y + $height); $clearY++) { Write-StringToBuffer -TargetX $x -TargetY $clearY -Text $clearLine -FG_Ansi $fgAnsi -BG_Ansi $bgAnsi -ClippingView $clipView } } }
function Render-ListView { param( [Parameter(Mandatory = $true)][hashtable]$ViewDefinition ); $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; $x = $ViewDefinition.X; $y = $ViewDefinition.Y; $width = $ViewDefinition.Width; $height = $ViewDefinition.Height; $viewName = $ViewDefinition.Name; if ($width -le 0 -or $height -le 0) { $logFunc.Invoke("ListView '$viewName' has zero/negative size.", "DEBUG"); return }; $clipView = @{ X = $x; Y = $y; Width = $width; Height = $height }; $viewType = ""; try { if ($ViewDefinition.ViewType -is [scriptblock]) { $viewType = & $ViewDefinition.ViewType } else { $viewType = $ViewDefinition.ViewType } } catch { $logFunc.Invoke("Error executing ViewType scriptblock for '$viewName': $($_.Exception.Message)", "WARN"); $viewType = "Error" }; if (-not $viewType -or -not $global:tableConfig.Columns.ContainsKey($viewType)) { $logFunc.Invoke("Invalid ViewType or global:tableConfig not found for ListView columns: $viewType", "ERROR"); return }; $columns = $global:tableConfig.Columns.$viewType; $theme = Get-ActiveTheme; $colPad = Get-PmcThemeProperty $theme "DataTable.Pad" 1 "Integer"; $headerFG = Get-PmcThemeAnsiCode "DataTable.Header.FG" '97'; $headerBG = Get-PmcThemeAnsiCode "DataTable.Header.BG" '44'; $dataFG = Get-PmcThemeAnsiCode "DataTable.DataRow.FG" '37'; $dataBG = Get-PmcThemeAnsiCode "DataTable.DataRow.BG" '49'; $altFG = Get-PmcThemeAnsiCode "DataTable.AltRow.FG" $dataFG; $altBG = Get-PmcThemeAnsiCode "DataTable.AltRow.BG" $dataBG; $useAltRows = ($altBG -ne $dataBG) -or ($altFG -ne $dataFG); $disabledFG = Get-PmcThemeAnsiCode "Palette.DisabledFG" '90'; $highlightFG = Get-PmcThemeAnsiCode "Palette.HighlightFG" '97'; $highlightBG = Get-PmcThemeAnsiCode "Palette.HighlightBG" '44'; $isFocused = $ViewDefinition.IsFocusable -and $viewName -eq $script:FocusedViewName; if ($isFocused) { $focusBorderFG = Get-PmcThemeAnsiCode "Palette.FocusBorderFG" $headerFG; $focusBorderBG = Get-PmcThemeAnsiCode "Palette.FocusBorderBG" $headerBG; Draw-BoxToBuffer -X $x -Y $y -Width $width -Height $height -BorderStyle "Single" -FG_Ansi $focusBorderFG -BG_Ansi $focusBorderBG -ClippingView $clipView; if ($width -ge 2 -and $height -ge 2) { $clipView = @{ X = $x+1; Y = $y+1; Width = $width-2; Height = $height-2 }; $x++; $y++; $width-=2; $height-=2 } else { $width = 0; $height = 0 }; if ($width -le 0 -or $height -le 0) { return } }; $items = @(); $rowColors = @{}; try { if ($ViewDefinition.DataSource -is [scriptblock]) { $items = Invoke-Command -ScriptBlock $ViewDefinition.DataSource } elseif ($ViewDefinition.DataSource -is [array]) { $items = $ViewDefinition.DataSource } else { $logFunc.Invoke("ListView '$viewName': Invalid DataSource type.", "ERROR") }; if ($ViewDefinition.RowColors -is [scriptblock]) { $rowColors = Invoke-Command -ScriptBlock $ViewDefinition.RowColors } elseif ($ViewDefinition.RowColors -is [hashtable]) { $rowColors = $ViewDefinition.RowColors } } catch { $logFunc.Invoke("ListView '$viewName': Failed DataSource/RowColors scriptblock: $($_.Exception.Message)", "ERROR") }; $items = @($items); if ($script:ListViewStates.ContainsKey($viewName)) { $script:ListViewStates[$viewName].Items = $items; $script:ListViewStates[$viewName].ItemCount = $items.Count } else { $script:ListViewStates[$viewName] = @{SelectedIndex=0; TopIndex=0; ItemCount=$items.Count; Items=$items} }; $viewState = $script:ListViewStates[$viewName]; $selectedIndex = $viewState.SelectedIndex; $topIndex = $viewState.TopIndex; $itemCount = $viewState.ItemCount; $cellInnerWidths = @($columns | ForEach-Object { $_.Width }); $totalInnerWidth = ($cellInnerWidths | Measure-Object -Sum).Sum; $totalPadWidth = $columns.Count * 2 * $colPad; $totalWidthNeeded = $totalInnerWidth + $totalPadWidth; if ($totalWidthNeeded -gt $width) { $logFunc.Invoke("ListView '$viewName' content width ($totalWidthNeeded) may exceed view width ($width).", "DEBUG") }; $currentY = $y; $linesDrawn = 0; if ($linesDrawn -lt $height) { $currentX = $x; for ($i = 0; $i -lt $columns.Count; $i++) { $col = $columns[$i]; $title = $col.Title.ToUpper(); $innerWidth = $cellInnerWidths[$i]; if ($innerWidth -ge 1 -and (Measure-StringWidth $title) -gt $innerWidth) { $title = $title.Substring(0, [Math]::Max(0, $innerWidth - 1)) + "…" } elseif ($innerWidth -le 0) { $title = "" } else { $title = $title.PadRight($innerWidth) }; $cellText = (" " * $colPad) + $title + (" " * $colPad); $cellWidth = Measure-StringWidth $cellText; if (($currentX + $cellWidth - $x) -le $width) { Write-StringToBuffer -TargetX $currentX -TargetY $currentY -Text $cellText -FG_Ansi $headerFG -BG_Ansi $headerBG -ClippingView $clipView; $currentX += $cellWidth } else { break } }; $clearWidth = $width - ($currentX - $x); if ($clearWidth -gt 0) { Write-StringToBuffer -TargetX $currentX -TargetY $currentY -Text (' ' * $clearWidth) -FG_Ansi $headerFG -BG_Ansi $headerBG -ClippingView $clipView }; $currentY++; $linesDrawn++ }; if ($itemCount -eq 0 -and $linesDrawn -lt $height) { $emptyText = " No data available ".PadRight($width); Write-StringToBuffer -TargetX $x -TargetY $currentY -Text $emptyText -FG_Ansi $disabledFG -BG_Ansi $dataBG -ClippingView $clipView; $currentY++; $linesDrawn++ } else { $startIndex = $topIndex; $endIndex = [Math]::Min($itemCount - 1, $startIndex + $height - $linesDrawn - 1); for ($rowIndex = $startIndex; $rowIndex -le $endIndex; $rowIndex++) { if ($linesDrawn -ge $height) { break }; $rowObject = $items[$rowIndex]; $currentX = $x; $baseFG = $dataFG; $baseBG = $dataBG; if ($useAltRows -and ($rowIndex % 2 -ne 0)) { $baseFG = $altFG; $baseBG = $altBG }; $rowHighlightStyle = $null; $cellSpecificStyles = @{}; if ($rowColors.ContainsKey($rowIndex)) { $colorInfo = $rowColors[$rowIndex]; if ($colorInfo -is [string]) { $rowHighlightStyle = Get-PmcThemeProperty $theme "DataTable.Highlight.$colorInfo" $null "Hashtable"; if ($rowHighlightStyle) { $baseFG = Get-PmcThemeAnsiCode "DataTable.Highlight.$colorInfo.FG" $baseFG; $baseBG = Get-PmcThemeAnsiCode "DataTable.Highlight.$colorInfo.BG" $baseBG } } elseif ($colorInfo -is [hashtable]) { if ($colorInfo.ContainsKey("_ROW_FG")) { $baseFG = Get-PmcThemeAnsiCode $colorInfo["_ROW_FG"] $baseFG }; if ($colorInfo.ContainsKey("_ROW_BG")) { $baseBG = Get-PmcThemeAnsiCode $colorInfo["_ROW_BG"] $baseBG }; foreach ($key in $colorInfo.Keys) { if ($key -match '^(_?CELL_)?(\d+)$') { $cellIdx = [int]$matches[2]; $cellValue = $colorInfo[$key]; if ($cellValue -is [string]) { $cellHighlight = Get-PmcThemeProperty $theme "DataTable.Highlight.$cellValue" $null "Hashtable"; if ($cellHighlight) { $cellSpecificStyles[$cellIdx] = @{ FG = Get-PmcThemeAnsiCode "DataTable.Highlight.$cellValue.FG" $null; BG = Get-PmcThemeAnsiCode "DataTable.Highlight.$cellValue.BG" $null } } } elseif ($cellValue -is [hashtable]) { $cellSpecificStyles[$cellIdx] = @{ FG = Get-PmcThemeAnsiCode $cellValue["FG"] $null; BG = Get-PmcThemeAnsiCode $cellValue["BG"] $null } } } } } }; $isRowSelected = $isFocused -and $rowIndex -eq $selectedIndex; if ($isRowSelected) { $baseFG = $highlightFG; $baseBG = $highlightBG; $cellSpecificStyles = @{} }; for ($i = 0; $i -lt $columns.Count; $i++) { $colDef = $columns[$i]; $propName = $colDef.Property; $colInnerWidth = $cellInnerWidths[$i]; $value = ""; if ($null -ne $rowObject) { if ($rowObject -is [hashtable]) { if ($rowObject.ContainsKey($propName)) { $value = $rowObject[$propName] } } elseif ($rowObject.PSObject.Properties[$propName] -ne $null) { $value = $rowObject.$propName } }; $value = if ($null -eq $value) { "" } else { $value.ToString() }; $displayValue = $value; if ($colInnerWidth -ge 1 -and (Measure-StringWidth $displayValue) -gt $colInnerWidth) { $displayValue = $displayValue.Substring(0, [Math]::Max(0, $colInnerWidth - 1)) + "…" } elseif ($colInnerWidth -le 0) { $displayValue = "" } else { $displayValue = $displayValue.PadRight($colInnerWidth) }; $cellFG = $baseFG; $cellBG = $baseBG; if (-not $isRowSelected -and $cellSpecificStyles.ContainsKey($i)) { if (-not [string]::IsNullOrEmpty($cellSpecificStyles[$i].FG)) { $cellFG = $cellSpecificStyles[$i].FG }; if (-not [string]::IsNullOrEmpty($cellSpecificStyles[$i].BG)) { $cellBG = $cellSpecificStyles[$i].BG } }; $cellText = (" " * $colPad) + $displayValue + (" " * $colPad); $cellWidth = Measure-StringWidth $cellText; if (($currentX + $cellWidth - $x) -le $width) { Write-StringToBuffer -TargetX $currentX -TargetY $currentY -Text $cellText -FG_Ansi $cellFG -BG_Ansi $cellBG -ClippingView $clipView; $currentX += $cellWidth } else { break } }; $clearWidth = $width - ($currentX - $x); if ($clearWidth -gt 0) { Write-StringToBuffer -TargetX $currentX -TargetY $currentY -Text (' ' * $clearWidth) -FG_Ansi $baseFG -BG_Ansi $baseBG -ClippingView $clipView }; $currentY++; $linesDrawn++ } }; $clearLine = ' ' * $width; $clearBG = Get-PmcThemeAnsiCode "Palette.PrimaryBG" '49'; while($linesDrawn -lt $height) { Write-StringToBuffer -TargetX $x -TargetY $currentY -Text $clearLine -BG_Ansi $clearBG -ClippingView $clipView; $currentY++; $linesDrawn++ } }
function Render-InputView { param( [Parameter(Mandatory = $true)][hashtable]$ViewDefinition ); $logFunc = { param($Msg, $Lvl="TRACE") Write-AppLog $Msg $Lvl }; $theme = Get-ActiveTheme; $x = $ViewDefinition.X; $y = $ViewDefinition.Y; $width = $ViewDefinition.Width; if ($width -le 0) { return }; $clipView = @{ X = $x; Y = $y; Width = $width; Height = 1 }; $inputFG = Get-PmcThemeAnsiCode "InputControl.UserInput.FG"; $inputBG = Get-PmcThemeAnsiCode "InputControl.UserInput.BG"; $defaultHintFG = Get-PmcThemeAnsiCode "InputControl.DefaultHint.FG"; $defaultHintPrefix = Get-PmcThemeProperty $theme "InputControl.DefaultHint.Prefix" " (" "String"; $defaultHintSuffix = Get-PmcThemeProperty $theme "InputControl.DefaultHint.Suffix" ")" "String"; $isFocused = $ViewDefinition.IsFocusable -and $ViewDefinition.Name -eq $script:FocusedViewName; if ($isFocused) { $inputFG = Get-PmcThemeAnsiCode "Palette.FocusTextFG" $inputFG; $inputBG = Get-PmcThemeAnsiCode "Palette.FocusTextBG" $inputBG; $defaultHintFG = $inputFG }; $inputText = ""; $cursorPos = 0; $isInputMode = ($script:InputState.Mode -ne "Normal"); $isCurrentInputTarget = $isInputMode -and $ViewDefinition.Name -eq "InputArea"; if ($isCurrentInputTarget) { $inputText = $script:InputState.Buffer.ToString(); $cursorPos = $script:InputState.CursorPos } elseif ($ViewDefinition.ContainsKey('DataSource') -and $ViewDefinition.DataSource -is [scriptblock]) { try { $inputText = (& $ViewDefinition.DataSource) ?? "" } catch { $inputText = "[ERR]" } }; $displayInputText = $inputText; $textOffset = 0; $cursorScreenOffset = 0; $inputTextWidth = Measure-StringWidth $inputText; if ($inputTextWidth -gt $width) { $visibleWidth = $width; $cursorVisualPos = Measure-StringWidth $inputText.Substring(0, $cursorPos); $idealStartVisualPos = [Math]::Max(0, $cursorVisualPos - [Math]::Floor($visibleWidth / 2)); $maxStartVisualPos = $inputTextWidth - $visibleWidth; $startVisualPos = [Math]::Min($idealStartVisualPos, $maxStartVisualPos); $currentVisualPos = 0; for($i = 0; $i -lt $inputText.Length; $i++) { if ($currentVisualPos -ge $startVisualPos) { $textOffset = $i; break }; $currentVisualPos += Measure-StringWidth $inputText[$i] }; $displayInputText = ""; $currentDisplayWidth = 0; for($i = $textOffset; $i -lt $inputText.Length; $i++) { $charWidth = Measure-StringWidth $inputText[$i]; if ($currentDisplayWidth + $charWidth -le $visibleWidth) { $displayInputText += $inputText[$i]; $currentDisplayWidth += $charWidth } else { break } }; $cursorScreenOffset = Measure-StringWidth $inputText.Substring($textOffset, $cursorPos - $textOffset) } else { $cursorScreenOffset = Measure-StringWidth $inputText.Substring(0, $cursorPos) }; $finalDisplayText = ""; $finalFG = $inputFG; $finalBG = $inputBG; if ($isCurrentInputTarget -and $inputText.Length -eq 0 -and -not [string]::IsNullOrEmpty($script:InputState.DefaultValue)) { $displayDefault = $script:InputState.DefaultValue; if ($script:InputState.ForceDateFormat) { if ($displayDefault -match '^\d{8}$') { try { $parsedDate = [datetime]::ParseExact($displayDefault, $global:DATE_FORMAT_INTERNAL, $null); $displayDefault = $parsedDate.ToString($global:AppConfig.displayDateFormat ?? $global:DATE_FORMAT_DISPLAY_FALLBACK) } catch { $displayDefault = "$displayDefault(err)" } } }; $hintText = "$defaultHintPrefix$displayDefault$defaultHintSuffix"; if (Measure-StringWidth $hintText -gt $width) { $hintText = $hintText.Substring(0, [Math]::Min($hintText.Length, $width - 1)) + "…" }; $finalDisplayText = $hintText.PadRight($width); $finalFG = $defaultHintFG; $finalBG = $inputBG } else { $finalDisplayText = $displayInputText.PadRight($width); $finalFG = $inputFG; $finalBG = $inputBG }; Write-StringToBuffer -TargetX $x -TargetY $y -Text $finalDisplayText -FG_Ansi $finalFG -BG_Ansi $finalBG -ClippingView $clipView; if ($isCurrentInputTarget) { $script:CursorState.X = $x + $cursorScreenOffset; $script:CursorState.Y = $y; $script:CursorState.Visible = $true; $logFunc.Invoke("Render-InputView: Text='$finalDisplayText', Cursor BufferPos=$cursorPos, TextOffset=$textOffset, Cursor ScreenPos=($($script:CursorState.X), $($script:CursorState.Y)), Visible=$($script:CursorState.Visible)") } elseif ($script:CursorState.Visible -and $ViewDefinition.Name -eq "InputArea") { $script:CursorState.Visible = $false } }
function Render-InputPromptView { param( [Parameter(Mandatory = $true)][hashtable]$ViewDefinition ); $theme = Get-ActiveTheme; $x = $ViewDefinition.X; $y = $ViewDefinition.Y; $width = $ViewDefinition.Width; if ($width -le 0) { return }; $clipView = @{ X = $x; Y = $y; Width = $width; Height = 1 }; $promptFG = Get-PmcThemeAnsiCode "InputControl.Prompt.FG"; $promptBG = Get-PmcThemeAnsiCode "Palette.PrimaryBG"; $promptText = ""; if ($script:InputState.Mode -ne "Normal") { $promptText = $script:InputState.PromptText ?? "" }; if (Measure-StringWidth $promptText -gt $width) { $promptText = $promptText.Substring(0, [Math]::Min($promptText.Length, $width - 1)) + "…" }; $displayText = $promptText.PadRight($width); Write-StringToBuffer -TargetX $x -TargetY $y -Text $displayText -FG_Ansi $promptFG -BG_Ansi $promptBG -ClippingView $clipView }
function Render-SegmentDisplayView { param( [Parameter(Mandatory = $true)][hashtable]$ViewDefinition ); $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; $x = $ViewDefinition.X; $y = $ViewDefinition.Y; $width = $ViewDefinition.Width; $height = $ViewDefinition.Height; if ($width -le 0 -or $height -le 0) { return }; $clipView = @{ X = $x; Y = $y; Width = $width; Height = $height }; $fg = Get-PmcThemeAnsiCode "SegmentDisplay.FG"; $bg = Get-PmcThemeAnsiCode "SegmentDisplay.BG"; $timeToDisplay = if ($script:PomodoroState.Running) { $script:PomodoroState.RemainingTS } else { (Get-Date).TimeOfDay }; $formattedLines = Format-SegmentTime -TimeSpan $timeToDisplay; if ($null -eq $formattedLines) { $logFunc.Invoke("SegmentDisplay: Formatted time is null.", "WARN"); return }; $totalFormattedWidth = if($formattedLines.Count -gt 0){ Measure-StringWidth $formattedLines[0] } else { 0 }; $totalFormattedHeight = $formattedLines.Count; $startX = $x + [Math]::Max(0, [Math]::Floor(($width - $totalFormattedWidth) / 2)); $startY = $y + [Math]::Max(0, [Math]::Floor(($height - $totalFormattedHeight) / 2)); $logFunc.Invoke("Render-SegmentDisplay: View='($x,$y)' W=$width H=$height | Time='$timeToDisplay' | Lines=$($formattedLines.Count) | FG='$fg' BG='$bg' | Start='($startX,$startY)'"); if($formattedLines -ne $null -and $formattedLines.Count -gt 0){ $logFunc.Invoke("Render-SegmentDisplay: Line 0: '$($formattedLines[0])' (Width: $(Measure-StringWidth $formattedLines[0]))") }; $clearLine = ' ' * $width; for ($clearY = $y; $clearY -lt ($y + $height); $clearY++) { Write-StringToBuffer -TargetX $x -TargetY $clearY -Text $clearLine -FG_Ansi $fg -BG_Ansi $bg -ClippingView $clipView }; for ($lineIdx = 0; $lineIdx -lt $formattedLines.Count; $lineIdx++) { $currentY = $startY + $lineIdx; if ($currentY -ge ($y + $height)) { break }; $lineText = $formattedLines[$lineIdx]; Write-StringToBuffer -TargetX $startX -TargetY $currentY -Text $lineText -FG_Ansi $fg -BG_Ansi $bg -ClippingView $clipView } }
function Render-ButtonView { param( [Parameter(Mandatory = $true)][hashtable]$ViewDefinition ); $logFunc = { param($Msg, $Lvl="TRACE") Write-AppLog $Msg $Lvl }; $x = $ViewDefinition.X; $y = $ViewDefinition.Y; $width = $ViewDefinition.Width; $height = $ViewDefinition.Height; if ($width -le 0 -or $height -le 0) { return }; $clipView = @{ X = $x; Y = $y; Width = $width; Height = $height }; $text = $ViewDefinition.Text ?? "Button"; try { if ($text -is [scriptblock]) { $text = & $text } } catch { $text = "[ERR]" }; $isFocused = $ViewDefinition.IsFocusable -and $ViewDefinition.Name -eq $script:FocusedViewName; $isDisabled = $ViewDefinition.IsDisabled ?? $false; $fg = if($isDisabled){ Get-PmcThemeAnsiCode "Palette.WidgetDisabledFG" } elseif($isFocused){ Get-PmcThemeAnsiCode "Palette.WidgetFocusFG" } else { Get-PmcThemeAnsiCode "Palette.WidgetFG" }; $bg = if($isFocused){ Get-PmcThemeAnsiCode "Palette.WidgetFocusBG" } else { Get-PmcThemeAnsiCode "Palette.WidgetBG" }; $buttonText = "< $text >"; $hAlign = "Center"; $vAlign = "Middle"; $displayText = $buttonText; $textLength = Measure-StringWidth $displayText; if ($textLength -gt $width) { $displayText = $displayText.Substring(0, [Math]::Min($displayText.Length, $width - 1)) + "…" ; $textLength = Measure-StringWidth $displayText }; switch ($hAlign.ToLowerInvariant()) { 'center' { $padTotal = $width - $textLength; $padLeft = [Math]::Floor($padTotal / 2); $padRight = $padTotal - $padLeft; $displayText = (' ' * $padLeft) + $displayText + (' ' * $padRight) }; 'right' { $displayText = $displayText.PadLeft($width) }; default { $displayText = $displayText.PadRight($width) } }; $targetY = $y; if ($height -gt 1) { $targetY = $y + [Math]::Floor(($height - 1) / 2) }; Write-StringToBuffer -TargetX $x -TargetY $targetY -Text $displayText -FG_Ansi $fg -BG_Ansi $bg -ClippingView $clipView; $clearLine = ' ' * $width; for ($clearY = $y; $clearY -lt ($y + $height); $clearY++) { if ($clearY -ne $targetY) { Write-StringToBuffer -TargetX $x -TargetY $clearY -Text $clearLine -FG_Ansi $fg -BG_Ansi $bg -ClippingView $clipView } } }
function Render-CheckboxView { param( [Parameter(Mandatory = $true)][hashtable]$ViewDefinition ); $logFunc = { param($Msg, $Lvl="TRACE") Write-AppLog $Msg $Lvl }; $x = $ViewDefinition.X; $y = $ViewDefinition.Y; $width = $ViewDefinition.Width; $height = 1; if ($width -le 0) { return }; $clipView = @{ X = $x; Y = $y; Width = $width; Height = $height }; $text = $ViewDefinition.Text ?? "Checkbox"; $isChecked = $false; try { if ($ViewDefinition.IsChecked -is [scriptblock]) { $isChecked = [bool](& $ViewDefinition.IsChecked) } elseif ($ViewDefinition.ContainsKey('IsChecked')) { $isChecked = [bool]$ViewDefinition.IsChecked } } catch { $logFunc.Invoke("Error evaluating IsChecked scriptblock for '$($ViewDefinition.Name)'", "WARN") }; $isFocused = $ViewDefinition.IsFocusable -and $ViewDefinition.Name -eq $script:FocusedViewName; $isDisabled = $ViewDefinition.IsDisabled ?? $false; $fg = if($isDisabled){ Get-PmcThemeAnsiCode "Palette.WidgetDisabledFG" } elseif($isFocused){ Get-PmcThemeAnsiCode "Palette.WidgetFocusFG" } else { Get-PmcThemeAnsiCode "Palette.WidgetFG" }; $bg = if($isFocused){ Get-PmcThemeAnsiCode "Palette.WidgetFocusBG" } else { Get-PmcThemeAnsiCode "Palette.WidgetBG" }; $checkChar = if ($isChecked) { "X" } else { " " }; $displayText = "[{0}] {1}" -f $checkChar, $text; if (Measure-StringWidth $displayText -gt $width) { $displayText = $displayText.Substring(0, [Math]::Min($displayText.Length, $width - 1)) + "…" }; $displayText = $displayText.PadRight($width); Write-StringToBuffer -TargetX $x -TargetY $y -Text $displayText -FG_Ansi $fg -BG_Ansi $bg -ClippingView $clipView }
function Render-CalendarView { param( [Parameter(Mandatory = $true)][hashtable]$ViewDefinition ); $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; $x = $ViewDefinition.X; $y = $ViewDefinition.Y; $width = $ViewDefinition.Width; $height = $ViewDefinition.Height; if ($width -le 0 -or $height -le 0) { return }; $clipView = @{ X = $x; Y = $y; Width = $width; Height = $height }; $theme = Get-ActiveTheme; $borderFG = Get-PmcThemeAnsiCode "Palette.BorderFG"; $borderBG = Get-PmcThemeAnsiCode "Palette.PrimaryBG"; $dayHeaderFG = Get-PmcThemeAnsiCode "DataTable.Header.FG"; $dayHeaderBG = Get-PmcThemeAnsiCode "DataTable.Header.BG"; $dayNumFG = Get-PmcThemeAnsiCode "Palette.DataFG"; $dayNumBG = Get-PmcThemeAnsiCode "Palette.PrimaryBG"; $otherMonthFG = Get-PmcThemeAnsiCode "Palette.DisabledFG"; $todayFG = Get-PmcThemeAnsiCode "Palette.HighlightFG"; $todayBG = Get-PmcThemeAnsiCode "Palette.HighlightBG"; $calendarData = Get-CalendarData -Month $script:CalendarCurrentMonth; if ($null -eq $calendarData) { Show-Error "Failed to generate calendar data."; return }; $cellWidth = [Math]::Floor($width / 7); $cellHeight = [Math]::Floor(($height - 1) / $calendarData.Weeks.Count); if ($cellWidth -lt 3 -or $cellHeight -lt 1) { Write-StringToBuffer -TargetX $x -TargetY $y -Text "Too small" -ClippingView $clipView; return }; $dayHeaders = @("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"); $headerY = $y; for ($d = 0; $d -lt 7; $d++) { $headerX = $x + ($d * $cellWidth); $headerText = $dayHeaders[$d].PadRight($cellWidth).Substring(0, $cellWidth); Write-StringToBuffer -TargetX $headerX -TargetY $headerY -Text $headerText -FG_Ansi $dayHeaderFG -BG_Ansi $dayHeaderBG -ClippingView $clipView }; $currentDayY = $y + 1; $todayDate = (Get-Date).Date; foreach ($week in $calendarData.Weeks) { if ($currentDayY + $cellHeight - 1 -gt $y + $height -1) { break }; $currentDayX = $x; foreach ($day in $week.Days) { if ($currentDayX + $cellWidth -1 -gt $x + $width -1) { break }; $dayFG = if ($day.IsCurrentMonth) { $dayNumFG } else { $otherMonthFG }; $dayBG = $dayNumBG; if ($day.Date.Date -eq $todayDate) { $dayFG = $todayFG; $dayBG = $todayBG }; $dayNumText = $day.Date.Day.ToString().PadLeft(2); if (Measure-StringWidth $dayNumText -lt $cellWidth) { Write-StringToBuffer -TargetX ($currentDayX + 1) -TargetY $currentDayY -Text $dayNumText -FG_Ansi $dayFG -BG_Ansi $dayBG -ClippingView $clipView }; $currentDayX += $cellWidth }; $currentDayY += $cellHeight } }
#endregion

#region Data Helper Functions
function Load-ProjectTodoJson { $filePath = $Global:AppConfig.projectsFile; if (-not (Test-Path $FilePath)) { Write-AppLog "Project file not found: $filePath" "INFO"; return @() }; try { $content = Get-Content -Path $FilePath -Raw -Encoding UTF8 -EA Stop; if ([string]::IsNullOrWhiteSpace($content)) { Write-AppLog "Project file empty: $filePath" "WARN"; return @() }; $jsonData = $content | ConvertFrom-Json -ErrorAction Stop; $dataArray = @($jsonData); $processedData = foreach ($proj in $dataArray) { $currentProject = $proj; if (-not $currentProject.PSObject.Properties.Name.Contains('Todos')) { $currentProject | Add-Member -MemberType NoteProperty -Name 'Todos' -Value @() -Force; Write-AppLog "Project '$($currentProject.ID2)' missing Todos property. Added empty array." "DEBUG" } elseif ($null -eq $currentProject.Todos) { $currentProject.Todos = @(); Write-AppLog "Project '$($currentProject.ID2)' Todos property was null. Reset to empty array." "DEBUG" } elseif ($currentProject.Todos -isnot [array]) { Write-AppLog "Project '$($currentProject.ID2)' Todos property not array ($($currentProject.Todos.GetType().Name)). Converting." "DEBUG"; $currentProject.Todos = @($currentProject.Todos) }; if ($currentProject.Todos -is [array]) { $currentProject.Todos = @($currentProject.Todos | ForEach-Object { $todoItem = if ($_ -is [hashtable]) { [PSCustomObject]$_ } else { $_ }; if (-not $todoItem.PSObject.Properties.Name.Contains('TodoID') -or [string]::IsNullOrWhiteSpace($todoItem.TodoID)) { Write-AppLog "Load-ProjectTodoJson: Todo '$($todoItem.Task)' missing ID. Assigning new one." "WARN"; $todoItem | Add-Member -MemberType NoteProperty -Name 'TodoID' -Value ([guid]::NewGuid().ToString()) -Force }; $todoItem }) }; $currentProject }; return $processedData } catch { Handle-Error $_ "Loading/Parsing Projects JSON '$filePath'"; return @() } }
function Save-ProjectTodoJson { param([Parameter(Mandatory=$true)][array]$ProjectData); $filePath = $Global:AppConfig.projectsFile; try { $ProjectData | ConvertTo-Json -Depth 10 | Out-File -FilePath $filePath -Encoding UTF8 -Force -ErrorAction Stop; Write-AppLog "Saved project data to '$filePath'." "INFO"; return $true } catch { Handle-Error $_ "Saving Projects JSON '$filePath'"; return $false } }
function Get-CsvDataSafely { param([string]$FilePath); if (-not (Test-Path $FilePath)) { Write-AppLog "CSV file not found: $FilePath" "WARN"; return @() }; try { $data = Import-Csv -Path $FilePath -Encoding UTF8 -ErrorAction Stop; Write-AppLog "Read $($data.Count) records from CSV: $FilePath" "DEBUG"; return @($data) } catch { Handle-Error $_ "Reading CSV '$FilePath'"; return $null } }
function Set-CsvData { param([string]$FilePath, [array]$Data); try { $Data | Export-Csv -Path $FilePath -NoTypeInformation -Encoding UTF8 -Force -ErrorAction Stop; Write-AppLog "Wrote $($Data.Count) records to CSV: $FilePath" "INFO"; return $true } catch { Handle-Error $_ "Writing CSV '$FilePath'"; return $false } }
function Format-DateSafeDisplay { param ([string]$DateStringInternal); if ([string]::IsNullOrWhiteSpace($DateStringInternal)) { return "" }; $formatToUse = $global:DATE_FORMAT_DISPLAY_FALLBACK; if ($null -ne $Global:AppConfig -and $Global:AppConfig.PSObject.Properties.Name.Contains('displayDateFormat') -and -not [string]::IsNullOrWhiteSpace($Global:AppConfig.displayDateFormat)) { $formatToUse = $Global:AppConfig.displayDateFormat } else { Write-AppLog "Format-DateSafeDisplay: Using fallback format '$formatToUse'." "DEBUG" }; if ($DateStringInternal -match "^\d{8}$") { try { $parsedDate = [datetime]::ParseExact($DateStringInternal, $global:DATE_FORMAT_INTERNAL, [System.Globalization.CultureInfo]::InvariantCulture); try { return $parsedDate.ToString($formatToUse) } catch { Write-AppLog "ERROR formatting date '$DateStringInternal' using format '$formatToUse': $($_.Exception.Message). Falling back." "ERROR"; try { return $parsedDate.ToString($global:DATE_FORMAT_DISPLAY_FALLBACK) } catch { Write-AppLog "CRITICAL ERROR: Failed format date '$DateStringInternal' even with fallback: $($_.Exception.Message)." "ERROR"; return "FormatErr" } } } catch { Write-AppLog "Error parsing date '$DateStringInternal' using internal format: $($_.Exception.Message)" "WARN"; return "InvalidDate" } }; Write-AppLog "Format-DateSafeDisplay received non-internal format: '$DateStringInternal'" "DEBUG"; return $DateStringInternal }
function Parse-DateSafeInternal { param ([string]$DateStringInput); if ([string]::IsNullOrWhiteSpace($DateStringInput)) { return "" }; $internalFormat = $global:DATE_FORMAT_INTERNAL; $displayFormat = $Global:AppConfig.displayDateFormat ?? $global:DATE_FORMAT_DISPLAY_FALLBACK; $formatsToTry = @($displayFormat, $internalFormat) + $global:COMMON_DATE_FORMATS_PARSE | Select-Object -Unique; Write-AppLog "Parse-DateSafeInternal: Attempting to parse '$DateStringInput'. Formats: $($formatsToTry -join ', ')" "TRACE"; foreach ($format in $formatsToTry) { try { $parsedDate = [datetime]::ParseExact($DateStringInput, $format, [System.Globalization.CultureInfo]::InvariantCulture); $internalResult = $parsedDate.ToString($internalFormat); Write-AppLog "Parse-DateSafeInternal: Parsed '$DateStringInput' using format '$format' -> '$internalResult'." "DEBUG"; return $internalResult } catch [System.FormatException] { Write-AppLog "Parse-DateSafeInternal: Failed parse '$DateStringInput' with format '$format'." "TRACE" } catch { Write-AppLog "Parse-DateSafeInternal: Error parsing '$DateStringInput' with format '$format': $($_.Exception.Message)" "WARN" } }; Write-AppLog "Parse-DateSafeInternal: Could not parse date input '$DateStringInput' into internal format using any known format." "WARN"; return "" }
#endregion

#region Excel Interaction Helpers
function Test-FileLocked { param([string]$FilePath); if (-not (Test-Path $FilePath)) { return $false }; $locked = $false; $fileStream = $null; try { $fileInfo = New-Object System.IO.FileInfo $FilePath; $fileStream = $fileInfo.Open([System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None) } catch [System.IO.IOException] { $locked = $true } catch { Write-AppLog "Test-FileLocked non-IO exception for '$FilePath': $($_.Exception.Message)" "DEBUG"; $locked = $true } finally { if ($null -ne $fileStream) { try { $fileStream.Close() } catch {}; try { $fileStream.Dispose() } catch {} } }; return $locked }
function Validate-ExcelOperation { param( [string]$FilePath, [switch]$RequireWriteAccess = $false ); $errors = @(); if (-not (Test-Path $FilePath -PathType Leaf)) { $errors += "File not found/is dir: $FilePath"; return $errors }; $extension = [System.IO.Path]::GetExtension($FilePath).ToLower(); if ($extension -notin @('.xlsx', '.xlsm', '.xls', '.xlsb')) { $errors += "Not Excel extension: $extension" }; try { if ((Get-Item $FilePath -ErrorAction Stop).Length -eq 0) { $errors += "File empty: $FilePath" } } catch { $errors += "Could not get size: $($_.Exception.Message)" }; if (Test-FileLocked -FilePath $FilePath) { $errors += "File locked: $FilePath"; $RequireWriteAccess = $false }; if ($RequireWriteAccess) { try { if ((Get-Item $FilePath -ErrorAction Stop).IsReadOnly) { $errors += "File read-only." } } catch { $errors += "Could not check read-only: $($_.Exception.Message)" }; $folder = Split-Path -Path $FilePath -Parent; try { $testFilePath = Join-Path -Path $folder -ChildPath "pmc_writetest_$([Guid]::NewGuid().ToString()).tmp"; [System.IO.File]::Create($testFilePath).Close(); Remove-Item -Path $testFilePath -Force -EA SilentlyContinue } catch { $errors += "Write permission denied: $folder" } }; return $errors }
function Release-ComObjects { param([array]$ComObjects); if ($null -eq $ComObjects -or $ComObjects.Count -eq 0) { return }; foreach ($obj in $ComObjects) { if ($null -ne $obj -and [System.Runtime.InteropServices.Marshal]::IsComObject($obj)) { try { if ($obj.PSObject.Methods.Name -contains "Close") { try { $obj.Close($false) } catch { Write-AppLog "Non-critical: Error closing workbook COM object." "DEBUG" } } elseif ($obj.PSObject.Methods.Name -contains "Quit") { try { $obj.Quit() } catch { Write-AppLog "Non-critical: Error quitting Excel COM object." "DEBUG"} }; $refCount = 0; do { $refCount = [System.Runtime.InteropServices.Marshal]::ReleaseComObject($obj) } while ($refCount -gt 0) } catch { Write-AppLog "Failed during COM object release attempt: $($_.Exception.Message)" "WARN" } } }; [System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers() }
function Process-ExcelWithTempCopy { param([string]$OriginalFilePath, [scriptblock]$ProcessingLogic, [switch]$UpdateOriginal = $false); $tempFilePath = $null; try { Show-ExcelProgress -Activity "Excel Op" -Status "Validating..." -PercentComplete 5 -ID 2; $validationErrors = Validate-ExcelOperation -FilePath $OriginalFilePath -RequireWriteAccess $UpdateOriginal; if ($validationErrors.Count -gt 0) { foreach ($errorMsg in $validationErrors) { Show-Error $errorMsg }; Show-ExcelProgress -Complete -ID 2; return $false }; $tempDir = [System.IO.Path]::GetTempPath(); $tempFileName = "$(New-Guid)$([System.IO.Path]::GetExtension($OriginalFilePath))"; $tempFilePath = Join-Path -Path $tempDir -ChildPath $tempFileName; Show-ExcelProgress -Status "Copying..." -PercentComplete 15 -ID 2; Copy-Item -Path $OriginalFilePath -Destination $tempFilePath -Force -EA Stop; Show-ExcelProgress -Status "Processing..." -PercentComplete 30 -ID 2; $result = & $ProcessingLogic -FilePath $tempFilePath; if ($UpdateOriginal -and $result) { Show-ExcelProgress -Status "Updating original..." -PercentComplete 80 -ID 2; if (Test-FileLocked -FilePath $OriginalFilePath) { Write-AppLog "Cannot update original Excel - became locked: $OriginalFilePath" "ERROR"; Show-Error "Cannot update original file - became locked: $OriginalFilePath"; Show-ExcelProgress -Complete -ID 2; return $false }; Copy-Item -Path $tempFilePath -Destination $OriginalFilePath -Force -EA Stop; Write-AppLog "Updated original Excel file: $OriginalFilePath" "INFO" } elseif ($UpdateOriginal -and (-not $result)) { Write-AppLog "Processing logic failed. Original Excel NOT updated: $OriginalFilePath" "WARN" }; Show-ExcelProgress -Status "Complete" -PercentComplete 100 -ID 2; Show-ExcelProgress -Complete -ID 2; return $result } catch { Handle-Error $_ "Processing Excel with temp copy for '$OriginalFilePath'"; Show-ExcelProgress -Complete -ID 2; return $false } finally { if ($null -ne $tempFilePath -and (Test-Path $tempFilePath)) { try { Remove-Item -Path $tempFilePath -Force -EA SilentlyContinue; Write-AppLog "Removed temporary Excel file: $tempFilePath" "DEBUG" } catch { Write-AppLog "Could not remove temp Excel file: $tempFilePath. Error: $($_.Exception.Message)" "WARN" } } } }
function Find-CellByLabel { param( $Worksheet, [string]$LabelText, [int]$OffsetColumn = 0, [int]$OffsetRow = 0 ); if ($null -eq $Worksheet -or [string]::IsNullOrWhiteSpace($LabelText)) { return $null }; $foundRange = $null; try { $foundRange = $Worksheet.UsedRange.Find( $LabelText, $null, [System.Reflection.Missing]::Value, 1, 1, 1, $false ); if ($null -ne $foundRange) { if ($OffsetColumn -ne 0 -or $OffsetRow -ne 0) { $targetRow = $foundRange.Row + $OffsetRow; $targetCol = $foundRange.Column + $OffsetColumn; if($targetRow -gt 0 -and $targetCol -gt 0 -and $targetRow -le $Worksheet.Rows.Count -and $targetCol -le $Worksheet.Columns.Count) { return $Worksheet.Cells.Item($targetRow, $targetCol) } else { Write-AppLog "Offset ($OffsetRow, $OffsetColumn) for label '$LabelText' results in invalid cell address." "DEBUG"; return $null } } else { return $foundRange } } else { Write-AppLog "Label '$LabelText' not found in worksheet '$($Worksheet.Name)'." "DEBUG"; return $null } } catch { Write-AppLog "Error finding cell with label '$LabelText' in '$($Worksheet.Name)': $($_.Exception.Message)" "WARN"; return $null } }
function Get-CellValueTyped { param( $Worksheet, $Address, [ValidateSet("String", "Number", "Date", "Boolean")] [string]$Type = "String" ); $cell = $null; try { if ($Address -is [string]) { $cell = $Worksheet.Range($Address) } elseif ($Address -is [Object] -and $Address -is [System.__ComObject]) { $cell = $Address } else { Write-AppLog "GetVal: Invalid address type provided." "DEBUG"; return $null }; if ($null -eq $cell) { Write-AppLog "GetVal: Could not resolve '$Address' to cell." "DEBUG"; return $null }; $rawValue = $cell.Value2; if ($null -eq $rawValue -or ($rawValue -is [string] -and [string]::IsNullOrWhiteSpace($rawValue)) -or $rawValue -is [System.DBNull]) { return $null }; if($rawValue -is [int] -and $rawValue -le -2146826281 -and $rawValue -ge -2146826246) { Write-AppLog "GetVal: Cell '$($cell.Address())' contains Excel error." "DEBUG"; return $null }; switch ($Type.ToLower()) { "string" { return [string]$rawValue.ToString().Trim() } "number" { $number = 0.0; if ([double]::TryParse($rawValue.ToString(), [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$number)) { return $number }; Write-AppLog "GetVal: Failed parse '$rawValue' as Number." "DEBUG"; return $null } "date" { try { if ($rawValue -is [double]) { return [DateTime]::FromOADate($rawValue) } elseif ($rawValue -is [datetime]) { return $rawValue } else { return [DateTime]::Parse($rawValue.ToString()) } } catch { Write-AppLog "GetVal: Failed parse '$rawValue' as Date." "DEBUG"; return $null } } "boolean" { if ($rawValue -is [bool]) { return $rawValue }; $strValue = $rawValue.ToString().ToLower().Trim(); if ($strValue -in @("yes", "true", "1", "y", "-1")) { return $true }; if ($strValue -in @("no", "false", "0", "n")) { return $false }; Write-AppLog "GetVal: Failed parse '$rawValue' as Boolean." "DEBUG"; return $null } } } catch { $cellAddress = "(unknown)"; try { $cellAddress = $cell.Address() } catch {}; Handle-Error -ErrorRecord $_ -Context "Getting cell value from '$cellAddress'"; return $null }; return $null }
function Invoke-ExcelOperation { param([string]$FilePath, [scriptblock]$ScriptBlock, [switch]$Visible = $false, [switch]$ReadOnly = $false); $excel = $null; $workbook = $null; $comObjects = @(); try { Show-ExcelProgress -Activity "Excel Op" -Status "Starting..." -PercentComplete 5 -ID 3; try { $excel = New-Object -ComObject Excel.Application -EA Stop } catch { Handle-Error -ErrorRecord $_ -Context "Starting Excel Application"; Show-ExcelProgress -Complete -ID 3; return $null }; $comObjects += $excel; $excel.Visible = $Visible; $excel.DisplayAlerts = $false; $excel.UserControl = $Visible; $excel.ScreenUpdating = $Visible; Show-ExcelProgress -Status "Opening: $(Split-Path $FilePath -Leaf)" -PercentComplete 20 -ID 3; $workbook = $excel.Workbooks.Open($FilePath, 0, $ReadOnly); if ($null -eq $workbook) { throw "Failed open workbook: $FilePath" }; $comObjects += $workbook; Show-ExcelProgress -Status "Processing..." -PercentComplete 50 -ID 3; $result = & $ScriptBlock -Excel $excel -Workbook $workbook; if (-not $Visible -and $workbook.Saved -eq $false -and (-not $ReadOnly)) { Write-AppLog "Auto-saving workbook: $FilePath" "DEBUG"; try { $workbook.Save() } catch { Handle-Error -ErrorRecord $_ -Context "Auto-saving workbook '$FilePath'" } }; Show-ExcelProgress -Status "Finishing..." -PercentComplete 90 -ID 3; return $result } catch { Handle-Error -ErrorRecord $_ -Context "Invoking Excel Operation on '$FilePath'"; Show-ExcelProgress -Complete -ID 3; return $null } finally { Show-ExcelProgress -Status "Cleaning up..." -PercentComplete 95 -ID 3; if ($workbook -ne $null -and $workbook.PSObject.Methods.Name -contains 'Close') { try { $workbook.Close($false) } catch { Write-AppLog "Non-critical: Error closing workbook during cleanup." "DEBUG" } }; if ($excel -ne $null -and $excel.PSObject.Methods.Name -contains 'Quit') { try { $excel.Quit() } catch { Write-AppLog "Non-critical: Error quitting Excel during cleanup." "DEBUG" } }; $objectsToRelease = @(); if ($workbook -ne $null) { $objectsToRelease += $workbook }; if ($excel -ne $null) { $objectsToRelease += $excel }; $allObjects = $comObjects + $objectsToRelease | Select-Object -Unique; [array]::Reverse($allObjects); Release-ComObjects -ComObjects $allObjects; Show-ExcelProgress -Complete -ID 3 } }
#endregion

#region Initialization Helpers
function Initialize-DataDirectory { Write-AppLog "Initializing data directories..." "INFO"; if ($null -eq $Global:AppConfig) { Show-Error "FATAL: Cannot initialize data directory - AppConfig is null."; Pause-Screen; return $false }; $baseDataDir = Split-Path -Path $Global:AppConfig.projectsFile -Parent -ErrorAction SilentlyContinue; if (-not $baseDataDir -or -not (Ensure-DirectoryExists -DirectoryPath $baseDataDir)) { Show-Error "FATAL: Cannot ensure base data directory exists: '$baseDataDir'. Check config.json and permissions."; Pause-Screen; return $false }; Write-AppLog "Base data directory verified: $baseDataDir" "DEBUG"; $commandsDir = $Global:AppConfig.commandsFolder; if (-not $commandsDir -or -not (Ensure-DirectoryExists -DirectoryPath $commandsDir)) { $warnMsg = "Could not ensure Commands directory exists: '$commandsDir'. Snippet functionality might fail."; Show-Warning $warnMsg } else { Write-AppLog "Commands directory verified: $commandsDir" "DEBUG" }; $notesDir = $Global:AppConfig.notesFolder; if (-not $notesDir -or -not (Ensure-DirectoryExists -DirectoryPath $notesDir)) { $warnMsg = "Could not ensure Notes directory exists: '$notesDir'. Notes functionality might fail."; Show-Warning $warnMsg } else { Write-AppLog "Notes directory verified: $notesDir" "DEBUG" }; if (-not (Ensure-CsvStructure -FilePath $Global:AppConfig.timeTrackingFile -Headers "Date,ID2,Hours,Description,TimeEntryID")) { Show-Error "FATAL: Failed to ensure structure for time tracking file: $($Global:AppConfig.timeTrackingFile)"; Pause-Screen; return $false }; if (-not $Global:AppConfig.caaTemplatePath -or -not (Test-Path $Global:AppConfig.caaTemplatePath -PathType Leaf)) { $errMsg = "Master CAA Template file not found or path invalid: '$($Global:AppConfig.caaTemplatePath)'"; Write-AppLog $errMsg "ERROR"; Show-Error $errMsg; Show-Error "Please update using 'Configure Settings' (Option O) or edit config.json."; Pause-Screen } else { Write-AppLog "CAA Template found: $($Global:AppConfig.caaTemplatePath)" "INFO" }; Write-AppLog "Data directory initialization checks complete." "INFO"; return $true }
function Ensure-CsvStructure { param([string]$FilePath, [string[]]$Headers); $headerString = $Headers -join ','; $dirPath = Split-Path -Path $FilePath -Parent -ErrorAction SilentlyContinue; if (-not $dirPath -or -not (Ensure-DirectoryExists -DirectoryPath $dirPath)) { Write-AppLog "Cannot ensure CSV structure for '$FilePath', directory failed." "ERROR"; return $false }; if (-not (Test-Path $FilePath)) { try { Set-Content -Path $FilePath -Value $headerString -Encoding UTF8 -Force -ErrorAction Stop; Write-AppLog "Created new CSV with headers: $FilePath" "INFO"; return $true } catch { Handle-Error $_ "Creating CSV file '$FilePath'"; return $false } }; try { $currentHeaderLine = Get-Content $FilePath -TotalCount 1 -Encoding UTF8 -ErrorAction Stop; if ($currentHeaderLine -eq $null -or [string]::IsNullOrWhiteSpace($currentHeaderLine)) { Write-AppLog "CSV file '$FilePath' is empty or has blank header. Writing headers." "WARN"; Set-Content -Path $FilePath -Value $headerString -Encoding UTF8 -Force -EA Stop; return $true }; $existingHeaders = $currentHeaderLine.Trim() -split ',' | ForEach-Object { $_.Trim() }; $requiredHeaders = $Headers | ForEach-Object { $_.Trim() }; if ($existingHeaders -join ',' -eq $requiredHeaders -join ',') { Write-AppLog "CSV structure verified: $FilePath" "DEBUG"; return $true } else { Write-AppLog "CSV header mismatch for '$FilePath'. Expected: '$($requiredHeaders -join ',')', Found: '$($existingHeaders -join ',')'" "WARN"; if($FilePath -eq $Global:AppConfig.timeTrackingFile -and $requiredHeaders -contains 'TimeEntryID' -and -not ($existingHeaders -contains 'TimeEntryID')) { Write-AppLog "Attempting to add TimeEntryID column to existing Time Tracking CSV." "INFO"; $backupPath = "$FilePath.backup_add_id_$(Get-Date -Format 'yyyyMMddHHmmss')"; try { Copy-Item -Path $FilePath -Destination $backupPath -Force -EA Stop; $data = Import-Csv -Path $FilePath -Encoding UTF8 -EA Stop; $updatedData = @($data | ForEach-Object { $_ | Add-Member -MemberType NoteProperty -Name 'TimeEntryID' -Value ([guid]::NewGuid().ToString()) -Force; $_ }); $updatedData | Export-Csv -Path $FilePath -NoTypeInformation -Encoding UTF8 -Force -EA Stop; Show-Warning "Added 'TimeEntryID' column to time tracking file. Backup created: $backupPath"; return $true } catch { Handle-Error $_ "Adding TimeEntryID column to '$FilePath'"; Show-Error "CRITICAL: Failed to update time tracking file header. Manual check required! Backup: $backupPath"; Pause-Screen; return $false } } elseif ($FilePath -eq $Global:AppConfig.timeTrackingFile) { Show-Error "CRITICAL: Time tracking file '$FilePath' header is incorrect and cannot be automatically fixed. Manual check required!"; Pause-Screen; return $false } else { Show-Warning "CSV file '$FilePath' header does not match expected structure. Functionality may be affected."; return $true } } } catch { Handle-Error $_ "Validating CSV structure for '$FilePath'"; return $false } }
function Load-ExcelMappings { Write-AppLog "Loading Excel mappings..." "INFO"; $mappingFilePath = Join-Path $Global:scriptRoot "excel_mappings.json"; if (Test-Path $mappingFilePath) { try { $Global:excelMappings = Get-Content $mappingFilePath -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable -ErrorAction Stop; Write-AppLog "Loaded Excel mappings from $mappingFilePath" "INFO"; if ($null -eq $Global:excelMappings -or -not $Global:excelMappings.ContainsKey('Extraction') -or -not $Global:excelMappings.ContainsKey('Copying') -or -not $Global:excelMappings.ContainsKey('StaticEntries')) { throw "Invalid structure in excel_mappings.json" }; if($Global:excelMappings.Extraction -isnot [array]){ $Global:excelMappings.Extraction = @($Global:excelMappings.Extraction) }; if($Global:excelMappings.Copying -isnot [array]){ $Global:excelMappings.Copying = @($Global:excelMappings.Copying) }; if($Global:excelMappings.StaticEntries -isnot [array]){ $Global:excelMappings.StaticEntries = @($Global:excelMappings.StaticEntries) }; Write-AppLog "Excel mappings validated successfully." "DEBUG"; return $true } catch { Handle-Error $_ "Loading or parsing excel_mappings.json"; Show-Error "FATAL: Could not load/parse Excel mappings file '$mappingFilePath'. Using default/empty."; $Global:excelMappings = @{ Extraction = @(); Copying = @(); StaticEntries = @() }; Pause-Screen; return $false } } else { Show-Error "FATAL: Excel mapping file not found: $mappingFilePath"; $Global:excelMappings = @{ Extraction = @(); Copying = @(); StaticEntries = @() }; Pause-Screen; return $false } }
#endregion

#region Input Request Functions (Moved outside Start-ProjectManagement)
function Request-TextInput {
    param(
        [string]$Prompt,
        [string]$DefaultValue = "",
        [switch]$ForceDateFormat = $false,
        [int]$MaxLength = 0, # 0 means no limit
        [scriptblock]$ValidationCallback = $null,
        [string]$ValidationMessage = "Invalid input.",
        [scriptblock]$SubmitCallback,
        [scriptblock]$CancelCallback = { param($tempData) Write-AppLog "TextInput cancelled by user." "INFO"; Show-Warning "Cancelled." },
        [hashtable]$InitialTempData = $null
    )
    Write-AppLog "Requesting TextInput: Prompt='$Prompt', Default='$DefaultValue'" "DEBUG"
    $script:InputState.Mode = "TextInput"
    $script:InputState.Buffer.Clear() | Out-Null
    $script:InputState.CursorPos = 0
    $script:InputState.PromptText = $Prompt
    $script:InputState.DefaultValue = $DefaultValue # Display value
    $script:InputState.DefaultValueInternal = $DefaultValue # Value used if user presses Enter on empty
    $script:InputState.ForceDateFormat = $ForceDateFormat
    $script:InputState.MaxLength = $MaxLength
    $script:InputState.ValidationCallback = $ValidationCallback
    $script:InputState.ValidationMessage = $ValidationMessage
    $script:InputState.SubmitCallback = $SubmitCallback
    $script:InputState.CancelCallback = $CancelCallback
    $script:InputState.TempData = if ($InitialTempData -ne $null) { $InitialTempData } else { @{} }
    $null = Invoke-PmcRenderRequest -ForceRedraw $true
}

function Request-NumericChoice {
    param(
        [string]$Prompt,
        [int]$MinValue,
        [int]$MaxValue,
        [string]$CancelOptionKey = "0",
        [string]$CancelText = "Cancel",
        [string]$ExtraPromptInfo = "", # Optional extra text for the prompt
        [scriptblock]$SubmitCallback,
        [scriptblock]$CancelCallback = { param($tempData) Write-AppLog "NumericChoice cancelled by user." "INFO"; Show-Warning "Cancelled." },
        [hashtable]$InitialTempData = $null
    )
    $fullPrompt = $Prompt
    if (-not [string]::IsNullOrEmpty($ExtraPromptInfo)) { $fullPrompt += " $ExtraPromptInfo" }
    else { $fullPrompt += " ($MinValue-$MaxValue"; if (-not [string]::IsNullOrEmpty($CancelOptionKey)) { $fullPrompt += ", $CancelOptionKey=$CancelText" }; $fullPrompt += ")" }

    Write-AppLog "Requesting NumericChoice: Prompt='$fullPrompt', Range=$MinValue-$MaxValue, Cancel=$CancelOptionKey" "DEBUG"
    $script:InputState.Mode = "NumericChoice"
    $script:InputState.Buffer.Clear() | Out-Null
    $script:InputState.CursorPos = 0
    $script:InputState.PromptText = $fullPrompt
    $script:InputState.DefaultValue = ""; $script:InputState.DefaultValueInternal = ""
    $script:InputState.ForceDateFormat = $false; $script:InputState.MaxLength = 0
    $script:InputState.ValidationCallback = $null; $script:InputState.ValidationMessage = ""
    $script:InputState.SubmitCallback = $SubmitCallback
    $script:InputState.CancelCallback = $CancelCallback
    $script:InputState.MinValue = $MinValue; $script:InputState.MaxValue = $MaxValue
    $script:InputState.CancelOptionKey = $CancelOptionKey
    $script:InputState.TempData = if ($InitialTempData -ne $null) { $InitialTempData } else { @{} }
    $null = Invoke-PmcRenderRequest -ForceRedraw $true
}

function Request-ConfirmAction {
    param(
        [string]$Prompt,
        [string]$YesOption = "1",
        [string]$YesText = "Yes",
        [string]$NoOption = "2",
        [string]$NoText = "No",
        [string]$CancelOption = "0",
        [string]$CancelText = "Cancel",
        [scriptblock]$OnConfirm,
        [scriptblock]$OnDeny = $null, # Optional deny action
        [scriptblock]$OnCancel = { param($tempData) Write-AppLog "ConfirmAction cancelled by user." "INFO"; Show-Warning "Cancelled." },
        [hashtable]$InitialTempData = $null
    )
    $options = @{}
    if (-not [string]::IsNullOrEmpty($YesOption)) { $options[$YesOption] = $YesText }
    if (-not [string]::IsNullOrEmpty($NoOption)) { $options[$NoOption] = $NoText }
    if (-not [string]::IsNullOrEmpty($CancelOption)) { $options[$CancelOption] = $CancelText }
    $promptWithOptions = "$Prompt ("
    $promptWithOptions += ($options.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join ' / '
    $promptWithOptions += ")"

    Write-AppLog "Requesting ConfirmAction: Prompt='$promptWithOptions'" "DEBUG"
    $script:InputState.Mode = "ConfirmAction"
    $script:InputState.Buffer.Clear() | Out-Null; $script:InputState.CursorPos = 0
    $script:InputState.PromptText = $promptWithOptions
    $script:InputState.DefaultValue = ""; $script:InputState.DefaultValueInternal = ""
    $script:InputState.ForceDateFormat = $false; $script:InputState.MaxLength = 0
    $script:InputState.ValidationCallback = $null; $script:InputState.ValidationMessage = ""
    $script:InputState.SubmitCallback = $null # Not used directly
    $script:InputState.CancelCallback = $OnCancel # Used for Escape key
    $script:InputState.Options = @{
        Yes = @{ Key = $YesOption; Callback = $OnConfirm }
        No = @{ Key = $NoOption; Callback = $OnDeny }
        Cancel = @{ Key = $CancelOption; Callback = $OnCancel }
    }
    $script:InputState.TempData = if ($InitialTempData -ne $null) { $InitialTempData } else { @{} }
    $null = Invoke-PmcRenderRequest -ForceRedraw $true
}

function Update-SelectionScreenPagedData {
    $startIndex = $script:SelectionScreenPage * $script:SelectionScreenPageSize
    $endIndex = [Math]::Min(($startIndex + $script:SelectionScreenPageSize - 1), ($script:SelectionScreenFullItems.Count - 1))
    $script:SelectionScreenItems = @($script:SelectionScreenFullItems[$startIndex..$endIndex])
    # Rebuild ItemMap for the current page
    $script:SelectionScreenItemMap = @{}
    $script:SelectionScreenItems | ForEach-Object -Begin {$idx=1} -Process { $script:SelectionScreenItemMap[$idx++] = $_ }
}

function Update-SelectionScreenRowColors {
    # Highlight the currently selected row
    $script:SelectionScreenRowColors = @{ $script:InputState.CurrentSelectionIndex = "Selected" }

    # Add page info to title if needed
    if ($script:SelectionScreenTotalPages -gt 1) {
        # --- CORRECTED LINE ---
        # Get the base title part (before any existing page info)
        $baseTitle = $script:SelectionScreenTitle.Split(' (Page')[0]
        # Reconstruct the title using the format operator for clarity and safety
        $script:SelectionScreenTitle = "{0} (Page {1}/{2})" -f $baseTitle, ($script:SelectionScreenPage + 1), $script:SelectionScreenTotalPages
    }
    # Note: This function doesn't need to call Invoke-PmcRenderRequest itself,
    # as the caller (usually Process-SelectionModeKey) will handle it.
}

function Select-ItemFromList {
    param(
        [string]$Title,
        [array]$Items,
        [string]$ViewType,
        [string]$Prompt = "Select item",
        [int]$PageSize = 15,
        [int]$InitialIndex = 0, # 0-based index for initial selection
        [scriptblock]$OnItemSelected,
        [scriptblock]$OnCancel = { param($tempData) Write-AppLog "Selection cancelled." "INFO"; Show-Warning "Cancelled." },
        [hashtable]$InitialTempData = $null
    )
    Write-AppLog "Requesting Selection: Title='$Title', Items=$($Items.Count), ViewType=$ViewType" "DEBUG"
    $script:SelectionScreenFullItems = $Items
    $script:SelectionScreenPageSize = [Math]::Max(1, $PageSize)
    $script:SelectionScreenTotalPages = [Math]::Ceiling($Items.Count / $script:SelectionScreenPageSize)
    $script:SelectionScreenPage = 0 # Start on first page
    $script:SelectionScreenTitle = $Title
    $script:SelectionScreenPrompt = $Prompt
    $script:SelectionScreenViewType = $ViewType
    $script:SelectionScreenOnItemSelected = $OnItemSelected
    $script:SelectionScreenOnCancel = $OnCancel
    $script:TempDataForSelection = if ($InitialTempData -ne $null) { $InitialTempData } else { @{} }

    Update-SelectionScreenPagedData # Load first page

    $script:InputState.Mode = "Selection"
    $script:InputState.Buffer.Clear() | Out-Null; $script:InputState.CursorPos = 0
    $script:InputState.CurrentSelectionIndex = [Math]::Max(0, [Math]::Min($InitialIndex, $script:SelectionScreenItems.Count - 1))
    Update-SelectionScreenRowColors # Highlight initial item

    Set-CurrentScreen -ScreenDefinition $SelectionScreen # Navigate to the selection screen
}
#endregion

#region Buffer, Views, Prompts, Context, ScreenManager
function New-ConsoleCell { param( [char]$Character = ' ', [string]$FG_Ansi = '39', [string]$BG_Ansi = '49', [bool]$Bold = $false, [bool]$ULine = $false ); return @{ Char = $Character; FG_Ansi = $FG_Ansi; BG_Ansi = $BG_Ansi; Bold = $Bold; ULine = $ULine } }
function New-ConsoleBufferInternal { param([int]$Width, [int]$Height); Write-AppLog "Creating new buffer array: ${Width}x${Height}" "TRACE"; $grid = @(); for ($y = 0; $y -lt $Height; $y++) { $row = @(); for ($x = 0; $x -lt $Width; $x++) { $row += New-ConsoleCell }; $grid += ,$row }; return $grid }
function Initialize-ConsoleBuffers { param([int]$Width, [int]$Height); Write-AppLog "Initializing console buffers: ${Width}x${Height}" "DEBUG"; $script:FrontBuffer = New-ConsoleBufferInternal -Width $Width -Height $Height; $script:BackBuffer = New-ConsoleBufferInternal -Width $Width -Height $Height; $script:BufferWidth = $Width; $script:BufferHeight = $Height }
function Resize-ConsoleBuffers { param([int]$NewWidth, [int]$NewHeight); Write-AppLog "Resizing console buffers to ${NewWidth}x${NewHeight}" "INFO"; Initialize-ConsoleBuffers -Width $NewWidth -Height $NewHeight }
function Clear-BackBuffer { if ($null -eq $script:BackBuffer) { Write-Warning "Back buffer is not initialized."; return }; $defaultCell = New-ConsoleCell; $defaultFG = Get-PmcThemeAnsiCode "Palette.PrimaryFG" '39'; $defaultBG = Get-PmcThemeAnsiCode "Palette.PrimaryBG" '49'; $defaultCell.FG_Ansi = $defaultFG; $defaultCell.BG_Ansi = $defaultBG; for ($y = 0; $y -lt $script:BufferHeight; $y++) { if ($y -ge $script:BackBuffer.Count) { continue }; $row = $script:BackBuffer[$y]; $rowWidth = $row.Count; for ($x = 0; $x -lt $script:BufferWidth; $x++) { if ($x -ge $rowWidth) { continue }; $script:BackBuffer[$y][$x] = $defaultCell.Clone() } } }
function Clear-BufferArea { param([int]$X, [int]$Y, [int]$Width, [int]$Height); if ($null -eq $script:BackBuffer) { Write-Warning "Back buffer is not initialized."; return }; $defaultCell = New-ConsoleCell; $defaultFG = Get-PmcThemeAnsiCode "Palette.PrimaryFG" '39'; $defaultBG = Get-PmcThemeAnsiCode "Palette.PrimaryBG" '49'; $defaultCell.FG_Ansi = $defaultFG; $defaultCell.BG_Ansi = $defaultBG; $endX = $X + $Width; $endY = $Y + $Height; $startX = [Math]::Max(0, $X); $startY = [Math]::Max(0, $Y); $finalX = [Math]::Min($script:BufferWidth, $endX); $finalY = [Math]::Min($script:BufferHeight, $endY); for ($cy = $startY; $cy -lt $finalY; $cy++) { if ($cy -ge $script:BackBuffer.Count) { continue }; $row = $script:BackBuffer[$cy]; $rowWidth = $row.Count; for ($cx = $startX; $cx -lt $finalX; $cx++) { if ($cx -ge $rowWidth) { continue }; $script:BackBuffer[$cy][$cx] = $defaultCell.Clone() } } }
function Write-CellToBuffer { param( [int]$X, [int]$Y, [hashtable]$Cell, [hashtable]$ClippingView = $null ); if ($Y -lt 0 -or $Y -ge $script:BufferHeight -or $X -lt 0 -or $X -ge $script:BufferWidth) { return }; if ($ClippingView) { if (($ClippingView.ContainsKey('X')) -and ($ClippingView.ContainsKey('Y')) -and ($ClippingView.ContainsKey('Width')) -and ($ClippingView.ContainsKey('Height'))) { if ($X -lt $ClippingView.X -or $X -ge ($ClippingView.X + $ClippingView.Width) -or $Y -lt $ClippingView.Y -or $Y -ge ($ClippingView.Y + $ClippingView.Height)) { return } } else { Write-Warning "Write-CellToBuffer: ClippingView missing keys." } }; if ($null -eq $script:BackBuffer -or $Y -ge $script:BackBuffer.Count -or $null -eq $script:BackBuffer[$Y]) { Write-Warning "Write-CellToBuffer target row $Y does not exist."; return }; if ($X -ge $script:BackBuffer[$Y].Count) { Write-Warning "Write-CellToBuffer target column $X out of bounds for row $Y."; return }; $targetCell = @{ Char = $Cell.Char ?? ' '; FG_Ansi = $Cell.FG_Ansi ?? "39"; BG_Ansi = $Cell.BG_Ansi ?? "49"; Bold = $Cell.Bold ?? $false; ULine = $Cell.ULine ?? $false }; $script:BackBuffer[$Y][$X] = $targetCell }
function Write-StringToBuffer { param( [int]$TargetX, [int]$TargetY, [string]$Text, [string]$FG_Ansi = "39", [string]$BG_Ansi = "49", [bool]$Bold=$false, [bool]$ULine=$false, [hashtable]$ClippingView = $null ); if ($TargetY -lt 0 -or $TargetY -ge $script:BufferHeight) { return }; $currentX = $TargetX; foreach ($char in $Text.ToCharArray()) { if ($currentX -ge $script:BufferWidth) { break }; if ($currentX -ge 0) { $cell = @{ Char = $char; FG_Ansi = $FG_Ansi; BG_Ansi = $BG_Ansi; Bold = $Bold; ULine = $ULine }; Write-CellToBuffer -X $currentX -Y $TargetY -Cell $cell -ClippingView $ClippingView }; $currentX++ } }
function Show-PmcConsoleBuffer { Write-AppLog "Show-PmcConsoleBuffer: Starting presentation." "TRACE"; $output = [System.Text.StringBuilder]::new(16384); $currentTerminalState = @{ FG_Ansi = "39"; BG_Ansi = "49"; Bold = $false; ULine = $false }; $localBack = $script:BackBuffer; $localFront = $script:FrontBuffer; $height = $script:BufferHeight; $width = $script:BufferWidth; $esc = $Global:esc; if ($null -eq $localBack -or $null -eq $localFront) { Write-Warning "Buffers not initialized."; return }; for ($y = 0; $y -lt $height; $y++) { $needsMove = $true; if ($y -ge $localBack.Count -or $y -ge $localFront.Count) { continue }; $backRow = $localBack[$y]; $frontRow = $localFront[$y]; $rowWidth = $backRow.Count; $frontRowWidth = $frontRow.Count; for ($x = 0; $x -lt $width; $x++) { if ($x -ge $rowWidth -or $x -ge $frontRowWidth) { continue }; $backCell = $backRow[$x]; $frontCell = $frontRow[$x]; $isDifferent = ($backCell.Char -ne $frontCell.Char) -or ($backCell.FG_Ansi -ne $frontCell.FG_Ansi) -or ($backCell.BG_Ansi -ne $frontCell.BG_Ansi); if ($isDifferent) { if ($needsMove) { $output.Append("${esc}[$($y + 1);$($x + 1)H") | Out-Null; $needsMove = $false }; if (($backCell.FG_Ansi -eq '39' -and $currentTerminalState.FG_Ansi -ne '39') -or ($backCell.BG_Ansi -eq '49' -and $currentTerminalState.BG_Ansi -ne '49')) { if ($currentTerminalState.FG_Ansi -ne '39') { $output.Append("${esc}[39m") | Out-Null; $currentTerminalState.FG_Ansi = '39' }; if ($currentTerminalState.BG_Ansi -ne '49') { $output.Append("${esc}[49m") | Out-Null; $currentTerminalState.BG_Ansi = '49' } }; if ($backCell.FG_Ansi -ne '39' -and $backCell.FG_Ansi -ne $currentTerminalState.FG_Ansi) { $output.Append("${esc}[$($backCell.FG_Ansi)m") | Out-Null; $currentTerminalState.FG_Ansi = $backCell.FG_Ansi }; if ($backCell.BG_Ansi -ne '49' -and $backCell.BG_Ansi -ne $currentTerminalState.BG_Ansi) { $output.Append("${esc}[$($backCell.BG_Ansi)m") | Out-Null; $currentTerminalState.BG_Ansi = $backCell.BG_Ansi }; $output.Append($backCell.Char) | Out-Null; $frontRow[$x] = $backCell.Clone() } else { $needsMove = $true } } }; if ($currentTerminalState.FG_Ansi -ne '39') { $output.Append("${esc}[39m") | Out-Null }; if ($currentTerminalState.BG_Ansi -ne '49') { $output.Append("${esc}[49m") | Out-Null }; if ($output.Length -gt 0) { $resetLength = 0; if ($currentTerminalState.FG_Ansi -ne '39') { $resetLength += "${esc}[39m".Length }; if ($currentTerminalState.BG_Ansi -ne '49') { $resetLength += "${esc}[49m".Length }; if ($output.Length -gt $resetLength) { Write-AppLog "Show-PmcConsoleBuffer: Writing $($output.Length) chars to console." "TRACE"; Write-Host $output.ToString() -NoNewline } else { Write-AppLog "Show-PmcConsoleBuffer: Only reset codes generated." "TRACE" } } else { Write-AppLog "Show-PmcConsoleBuffer: No buffer changes to present." "TRACE" } }
function Get-BufferDimensions { return [PSCustomObject]@{ Width = $script:BufferWidth; Height = $script:BufferHeight } }
function Get-BackBufferCell { param([int]$X, [int]$Y); if ($Y -ge 0 -and $Y -lt $script:BufferHeight -and $X -ge 0 -and $X -lt $script:BufferWidth -and $script:BackBuffer -ne $null -and $Y -lt $script:BackBuffer.Count -and $script:BackBuffer[$Y] -ne $null -and $X -lt $script:BackBuffer[$Y].Count) { return $script:BackBuffer[$Y][$X] } else { return $null } }
function Initialize-Context { Write-AppLog "Initializing application context..." "INFO"; $script:Projects = Load-ProjectTodoJson; if ($script:Projects.Count -gt 0) { $maxIdNum = 0; foreach($proj in $script:Projects){ if($proj.ID2 -match '^P(\d+)$'){ $idNum = [int]$matches[1]; if($idNum -gt $maxIdNum){ $maxIdNum = $idNum } } }; $script:NextProjectId = $maxIdNum + 1 } else { $script:NextProjectId = 1 }; Write-AppLog "Context initialized. Loaded $($script:Projects.Count) projects. Next Project ID Number: $($script:NextProjectId)" "INFO" }
function Get-Projects { return $script:Projects }
function Get-ProjectById { param([string]$ProjectId); return $script:Projects | Where-Object { $_.ID2 -eq $ProjectId } | Select-Object -First 1 }
function Add-Project { param([Parameter(Mandatory=$true)][object]$ProjectDataParam); Write-AppLog "Add-Project called" "DEBUG"; if ($null -eq $ProjectDataParam) { Write-Warning "Add-Project: Project data cannot be null."; return $null }; $ProjectData = if ($ProjectDataParam -is [hashtable]) { [PSCustomObject]$ProjectDataParam } else { $ProjectDataParam }; if (-not $ProjectData.PSObject.Properties.Name.Contains('ID2') -or [string]::IsNullOrWhiteSpace($ProjectData.ID2)) { Write-Warning "Add-Project: Project data is missing a valid ID2."; return $null }; if (-not $ProjectData.PSObject.Properties.Name.Contains('Todos')) { $ProjectData | Add-Member -MemberType NoteProperty -Name 'Todos' -Value @() -Force } elseif ($null -eq $ProjectData.Todos) { $ProjectData.Todos = @() } elseif ($ProjectData.Todos -isnot [array]) { $ProjectData.Todos = @($ProjectData.Todos) }; $script:Projects += $ProjectData; if ($ProjectData.ID2 -match '^P(\d+)$') { $idNum = [int]$matches[1]; if ($idNum -ge $script:NextProjectId) { $script:NextProjectId = $idNum + 1; Write-AppLog "Updated NextProjectId to $($script:NextProjectId) based on manually added ID $($ProjectData.ID2)" "DEBUG" } }; Write-AppLog "Project added: ID=$($ProjectData.ID2)" "INFO"; Save-ProjectTodoJson -ProjectData $script:Projects; return $ProjectData }
function Update-Project { param([PSCustomObject]$ProjectToUpdate); Write-AppLog "Update-Project called for ID='$($ProjectToUpdate.ID2)'" "DEBUG"; $projectIndex = -1; for ($i = 0; $i -lt $script:Projects.Count; $i++) { if ($script:Projects[$i].ID2 -eq $ProjectToUpdate.ID2) { $projectIndex = $i; break } }; if ($projectIndex -eq -1) { Write-Warning "Update-Project: Project with ID '$($ProjectToUpdate.ID2)' not found."; return $false }; $script:Projects[$projectIndex] = $ProjectToUpdate; Write-AppLog "Project updated: ID=$($ProjectToUpdate.ID2)" "INFO"; return (Save-ProjectTodoJson -ProjectData $script:Projects) }
function Set-CurrentScreen { param([Parameter(Mandatory=$true)]$ScreenDefinition, [switch]$ReplaceCurrent = $false); $logFunc = { param($Msg, $Lvl="INFO") Write-AppLog $Msg $Lvl }; if ($null -eq $ScreenDefinition) { $logFunc.Invoke("Set-CurrentScreen called with null ScreenDefinition.", "WARN"); return }; if ($ScreenDefinition.ContainsKey('OnLoad') -and $ScreenDefinition.OnLoad -is [scriptblock]) { $logFunc.Invoke("Executing OnLoad for screen '$($ScreenDefinition.Name)'", "DEBUG"); try { & $ScreenDefinition.OnLoad } catch { Handle-Error $_ "executing OnLoad for screen '$($ScreenDefinition.Name)'" } }; $newFocusTarget = $ScreenDefinition.DefaultFocusViewName ?? $null; if ($null -eq $newFocusTarget) { $focusableViews = Get-FocusableViews -ScreenDefinition $ScreenDefinition; if ($focusableViews.Count -gt 0) { $newFocusTarget = $focusableViews[0].Name } }; $script:FocusedViewName = $newFocusTarget; $logFunc.Invoke("Set-CurrentScreen: Setting focus to '$($script:FocusedViewName ?? 'None')' for screen '$($ScreenDefinition.Name)'", "DEBUG"); if($newFocusTarget -ne $null){ $focusedViewDef = $ScreenDefinition.Views | Where-Object {$_.Name -eq $newFocusTarget} | Select-Object -First 1; if($focusedViewDef -ne $null -and $focusedViewDef.Type -eq 'ListView'){ if (-not $script:ListViewStates.ContainsKey($newFocusTarget)) { $script:ListViewStates[$newFocusTarget] = @{SelectedIndex=0; TopIndex=0; ItemCount=0; Items=@()} }; $script:ListViewStates[$newFocusTarget].SelectedIndex = 0; $script:ListViewStates[$newFocusTarget].TopIndex = 0; Write-AppLog "Set-CurrentScreen: Reset ListView state for '$newFocusTarget'" "TRACE" } }; if ($ReplaceCurrent -and $script:ScreenStack.Count -gt 0) { $logFunc.Invoke("Replacing current screen with: $($ScreenDefinition.Name)", "DEBUG"); $script:ScreenStack[$script:ScreenStack.Count - 1] = $ScreenDefinition } else { $logFunc.Invoke("Pushing screen onto stack: $($ScreenDefinition.Name)", "DEBUG"); $script:ScreenStack.Add($ScreenDefinition) }; $null = Invoke-PmcRenderRequest -ForceRedraw $true }
function Get-CurrentScreen { if ($script:ScreenStack.Count -gt 0) { return $script:ScreenStack[$script:ScreenStack.Count - 1] } else { return $null } }
function Navigate-Back { $logFunc = { param($Msg, $Lvl="INFO") Write-AppLog $Msg $Lvl }; if ($script:ScreenStack.Count -gt 1) { $logFunc.Invoke("Navigating back. Popping '$((Get-CurrentScreen).Name)'.", "DEBUG"); $script:ScreenStack.RemoveAt($script:ScreenStack.Count - 1); $previousScreen = Get-CurrentScreen; if ($previousScreen) { $newFocusTarget = $previousScreen.DefaultFocusViewName ?? $null; if ($null -eq $newFocusTarget) { $focusableViews = Get-FocusableViews -ScreenDefinition $previousScreen; if ($focusableViews.Count -gt 0) { $newFocusTarget = $focusableViews[0].Name } }; $script:FocusedViewName = $newFocusTarget; $logFunc.Invoke("Navigate-Back: Setting focus to '$($script:FocusedViewName ?? 'None')' for screen '$($previousScreen.Name)'", "DEBUG"); if($newFocusTarget -ne $null){ $focusedViewDef = $previousScreen.Views | Where-Object {$_.Name -eq $newFocusTarget} | Select-Object -First 1; if($focusedViewDef -ne $null -and $focusedViewDef.Type -eq 'ListView'){ if (-not $script:ListViewStates.ContainsKey($newFocusTarget)) { $script:ListViewStates[$newFocusTarget] = @{SelectedIndex=0; TopIndex=0; ItemCount=0; Items=@()} }; $script:ListViewStates[$newFocusTarget].SelectedIndex = 0; $script:ListViewStates[$newFocusTarget].TopIndex = 0; Write-AppLog "Navigate-Back: Reset ListView state for '$newFocusTarget'" "TRACE" } } } else { $script:FocusedViewName = $null }; $null = Invoke-PmcRenderRequest -ForceRedraw $true; return $true } elseif ($script:ScreenStack.Count -eq 1) { $logFunc.Invoke("Navigating back from last screen. Signaling quit.", "INFO"); $script:ScreenStack.RemoveAt($script:ScreenStack.Count - 1); $script:FocusedViewName = $null; $script:keepRunning = $false; return $false } else { $logFunc.Invoke("Navigate-Back called on empty stack.", "WARN"); $script:FocusedViewName = $null; return $false } }
function Show-PmcCurrentScreen { $currentScreen = Get-CurrentScreen; $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; if ($script:IsRendering) { $logFunc.Invoke("Show-PmcCurrentScreen: Already rendering, skipping.", "TRACE"); return }; if (-not $script:RenderRequested) { $logFunc.Invoke("Show-PmcCurrentScreen: Render not requested, skipping.", "TRACE"); return }; if ($null -eq $currentScreen) { $logFunc.Invoke("Show-PmcCurrentScreen: No current screen to render.", "WARN"); $script:RenderRequested = $false; return }; $script:IsRendering = $true; $logFunc.Invoke("Show-PmcCurrentScreen: Starting render for '$($currentScreen.Name)'", "DEBUG"); $theme = Get-ActiveTheme; try { Clear-BackBuffer; $dimsRender = Get-BufferDimensions; $borderSettings = Get-PmcThemeProperty $theme "ScreenBorder" $null "Hashtable"; if ($null -ne $borderSettings -and (Get-PmcThemeProperty $borderSettings "Enabled" $false "Boolean")) { $borderStyleName = Get-PmcThemeProperty $borderSettings "Style" "Single" "String"; $borderFG_Ansi = Get-PmcThemeAnsiCode "ScreenBorder.FG"; $borderBG_Ansi = Get-PmcThemeAnsiCode "ScreenBorder.BG"; if ($dimsRender.Width -ge 2 -and $dimsRender.Height -ge 2) { Draw-BoxToBuffer -X 0 -Y 0 -Width $dimsRender.Width -Height $dimsRender.Height -BorderStyle $borderStyleName -FG_Ansi $borderFG_Ansi -BG_Ansi $borderBG_Ansi; $logFunc.Invoke("Screen border drawn to buffer (Style: $borderStyleName).", "TRACE") } else { $logFunc.Invoke("Skipping screen border (dimensions too small).", "TRACE") } } else { $logFunc.Invoke("Screen border disabled in theme or settings null.", "TRACE")}; $viewStartX = 1; $viewStartY = 1; $maxViewWidth = [Math]::Max(0, $dimsRender.Width - 2); $maxViewHeight = [Math]::Max(0, $dimsRender.Height - 2); if ($null -ne $currentScreen.Views -and $maxViewWidth -gt 0 -and $maxViewHeight -gt 0) { $viewsToRender = @(); foreach ($viewDefOriginal in $currentScreen.Views) { if ($null -eq $viewDefOriginal) { Write-AppLog "Show-PmcCurrentScreen - ERROR: viewDefOriginal is NULL in loop!" "ERROR"; continue }; $viewDef = $null; try { $viewDef = $viewDefOriginal.Clone() } catch { Write-AppLog "Show-PmcCurrentScreen - ERROR: Failed to Clone view '$($viewDefOriginal.Name)': $($_.Exception.Message)" "ERROR"; continue }; if ($null -eq $viewDef) { Write-AppLog "Show-PmcCurrentScreen - ERROR: viewDef is NULL after Clone for '$($viewDefOriginal.Name)'!" "ERROR"; continue }; $defX = $viewDefOriginal.X ?? 0; $defY = $viewDefOriginal.Y ?? 0; $defWidth = $viewDefOriginal.Width; $defHeight = $viewDefOriginal.Height; $calculatedY = $defY; if ($calculatedY -lt 0) { $calculatedY = $maxViewHeight + $calculatedY }; $viewDef.Y = $viewStartY + [Math]::Max(0, [Math]::Min($calculatedY, $maxViewHeight - 1)); $calculatedHeight = $defHeight ?? 1; if ($calculatedHeight -eq -1) { $calculatedHeight = $maxViewHeight - $calculatedY } elseif ($calculatedHeight -lt -1) { $spaceToLeave = -1 * ($calculatedHeight + 1); $calculatedHeight = $maxViewHeight - $calculatedY - $spaceToLeave }; $maxPossibleHeight = $maxViewHeight - ($viewDef.Y - $viewStartY); $viewDef.Height = [Math]::Max(0, [Math]::Min($calculatedHeight, $maxPossibleHeight)); $calculatedX = $defX; if ($calculatedX -lt 0) { $calculatedX = $maxViewWidth + $calculatedX }; $viewDef.X = $viewStartX + [Math]::Max(0, [Math]::Min($calculatedX, $maxViewWidth - 1)); $calculatedWidth = $defWidth ?? -1; if ($calculatedWidth -eq -1) { $calculatedWidth = $maxViewWidth - ($viewDef.X - $viewStartX) }; $maxPossibleWidth = $maxViewWidth - ($viewDef.X - $viewStartX); $viewDef.Width = [Math]::Max(0, [Math]::Min($calculatedWidth, $maxPossibleWidth)); try { foreach($prop in $viewDefOriginal.PSObject.Properties){ if($prop.Name -notin @('X','Y','Width','Height','Type')){ $viewDef.($prop.Name) = $prop.Value } } } catch { Write-AppLog "Show-PmcCurrentScreen - ERROR copying properties for view '$($viewDefOriginal.Name)': $($_.Exception.Message)" "ERROR" }; $viewsToRender += $viewDef }; foreach ($viewDef in $viewsToRender) { if ($null -eq $viewDef) { Write-AppLog "Show-PmcCurrentScreen - ERROR: viewDef is NULL in render loop!" "ERROR"; continue }; if ($viewDef.X -ge ($viewStartX + $maxViewWidth) -or $viewDef.Y -ge ($viewStartY + $maxViewHeight) -or $viewDef.Width -le 0 -or $viewDef.Height -le 0) { $logFunc.Invoke("Skipping render for view '$($viewDef.Name)' - outside bounds or zero/negative size.", "TRACE"); continue }; $viewType = $viewDef.Type ?? 'LabelView'; $renderFunctionName = "Render-$viewType"; $cmd = Get-Command $renderFunctionName -ErrorAction SilentlyContinue; if ($cmd) { $logFunc.Invoke("Rendering View: $($viewDef.Name) ($viewType) at ($($viewDef.X), $($viewDef.Y)) Size ($($viewDef.Width)x$($viewDef.Height)) Focusable=$($viewDef.IsFocusable) Focused=$($viewDef.Name -eq $script:FocusedViewName)", "TRACE"); try { if ($viewDef.Contains('RenderOverride') -and $viewDef.RenderOverride -is [scriptblock]) { & $viewDef.RenderOverride -ViewDefinition $viewDef } else { & $cmd -ViewDefinition $viewDef } } catch { Write-AppLog "Show-PmcCurrentScreen - ERROR occurred inside '$renderFunctionName' for view '$($viewDef.Name)': $($_.Exception.Message)" "ERROR"; Handle-Error $_ "Rendering view '$($viewDef.Name)' ($renderFunctionName)" } } else { $logFunc.Invoke("Render function '$renderFunctionName' not found for view type '$viewType'.", "WARN"); $errorFG = Get-PmcThemeAnsiCode "Palette.ErrorFG"; $errorBG = Get-PmcThemeAnsiCode "Palette.ErrorBG"; $errorText = "[No renderer: $viewType]".PadRight($viewDef.Width).Substring(0, [Math]::Min($viewDef.Width, 60)); Write-StringToBuffer -TargetX $viewDef.X -TargetY $viewDef.Y -Text $errorText -FG_Ansi $errorFG -BG_Ansi $errorBG -ClippingView $viewDef } } } else { $logFunc.Invoke("No views to render or view area too small.", "TRACE") }; if ($script:InputState.Mode -ne "Normal") { $inputPromptViewDef = $currentScreen.Views | Where-Object { $_.Name -eq 'InputPromptArea' } | Select-Object -First 1; $inputAreaViewDef = $currentScreen.Views | Where-Object { $_.Name -eq 'InputArea' } | Select-Object -First 1; if ($inputPromptViewDef -and $inputAreaViewDef) { $promptView = $inputPromptViewDef.Clone(); $areaView = $inputAreaViewDef.Clone(); $defY = $promptView.Y ?? 0; if ($defY -lt 0) { $defY = $maxViewHeight + $defY }; $promptView.Y = $viewStartY + [Math]::Max(0, [Math]::Min($defY, $maxViewHeight - 1)); $defX = $promptView.X ?? 0; if ($defX -lt 0) { $defX = $maxViewWidth + $defX }; $promptView.X = $viewStartX + [Math]::Max(0, [Math]::Min($defX, $maxViewWidth - 1)); $defW = $promptView.Width ?? -1; if ($defW -eq -1) { $defW = $maxViewWidth - ($promptView.X - $viewStartX) }; $promptView.Width = [Math]::Max(0, [Math]::Min($defW, $maxViewWidth - ($promptView.X - $viewStartX))); $promptView.Height = 1; $defY = $areaView.Y ?? 0; if ($defY -lt 0) { $defY = $maxViewHeight + $defY }; $areaView.Y = $viewStartY + [Math]::Max(0, [Math]::Min($defY, $maxViewHeight - 1)); $defX = $areaView.X ?? 0; if ($defX -lt 0) { $defX = $maxViewWidth + $defX }; $areaView.X = $viewStartX + [Math]::Max(0, [Math]::Min($defX, $maxViewWidth - 1)); $defW = $areaView.Width ?? -1; if ($defW -eq -1) { $defW = $maxViewWidth - ($areaView.X - $viewStartX) }; $areaView.Width = [Math]::Max(0, [Math]::Min($defW, $maxViewWidth - ($areaView.X - $viewStartX))); $areaView.Height = 1; $areaView.IsFocusable = $true; $logFunc.Invoke("Rendering Input Views: Prompt at ($($promptView.X),$($promptView.Y)) W=$($promptView.Width), Area at ($($areaView.X),$($areaView.Y)) W=$($areaView.Width)", "TRACE"); Render-InputPromptView -ViewDefinition $promptView; Render-InputView -ViewDefinition $areaView } else { $logFunc.Invoke("Input mode active, but InputPromptArea or InputArea view not found on screen '$($currentScreen.Name)'.", "WARN"); $script:CursorState.Visible = $false } } else { $script:CursorState.Visible = $false }; Show-PmcConsoleBuffer; try { if ($script:CursorState.Visible) { [Console]::CursorVisible = $true; $cursorX = [Math]::Max(0, [Math]::Min($script:CursorState.X, $script:BufferWidth - 1)); $cursorY = [Math]::Max(0, [Math]::Min($script:CursorState.Y, $script:BufferHeight - 1)); [Console]::SetCursorPosition($cursorX, $cursorY); $logFunc.Invoke("Set physical cursor to ($cursorX, $cursorY), Visible=True", "TRACE") } else { [Console]::CursorVisible = $false; $logFunc.Invoke("Set physical cursor Visible=False", "TRACE") } } catch { Handle-Error $_ "Setting physical cursor position/visibility"; [Console]::CursorVisible = $false }; $script:RenderRequested = $false; $logFunc.Invoke("Show-PmcCurrentScreen: Render complete.", "DEBUG") } catch { Handle-Error $_ "Critical error during Show-PmcCurrentScreen" } finally { $script:IsRendering = $false } }
function Invoke-PmcRenderRequest { param([bool]$ForceRedraw = $false); if (-not $script:RenderRequested -or $ForceRedraw) { $script:RenderRequested = $true; Write-AppLog "Render requested (Force: $ForceRedraw)." "TRACE" } }
#endregion

#region Input Processing Functions
function Reset-InputState { $script:InputState.Mode = "Normal"; $script:InputState.Buffer.Clear() | Out-Null; $script:InputState.CursorPos = 0; $script:InputState.PromptText = ""; $script:InputState.DefaultValue = ""; $script:InputState.DefaultValueInternal = ""; $script:InputState.ForceDateFormat = $false; $script:InputState.MaxLength = 0; $script:InputState.ValidationCallback = $null; $script:InputState.ValidationMessage = ""; $script:InputState.SubmitCallback = $null; $script:InputState.CancelCallback = $null; $script:InputState.MinValue = 0; $script:InputState.MaxValue = 0; $script:InputState.Options = @{}; $script:InputState.CancelOptionKey = "0"; $script:InputState.CurrentSelectionIndex = 0; $script:InputState.TempData = $null; Write-AppLog "Input state reset to Normal." "DEBUG" }
function Process-KeyPress { param([System.ConsoleKeyInfo]$KeyInfo); $logFunc = { param($Msg, $Lvl="TRACE") Write-AppLog $Msg $Lvl }; $logFunc.Invoke("Process-KeyPress: Key=$($KeyInfo.Key), Char='$($KeyInfo.KeyChar)', Modifiers=$($KeyInfo.Modifiers), Mode=$($script:InputState.Mode)"); switch ($script:InputState.Mode) { "Normal" { Process-NormalModeKey -KeyInfo $KeyInfo } "TextInput" { Process-TextInputKey -KeyInfo $KeyInfo } "NumericChoice" { Process-NumericChoiceKey -KeyInfo $KeyInfo } "ConfirmAction" { Process-ConfirmActionKey -KeyInfo $KeyInfo } "Selection" { Process-SelectionModeKey -KeyInfo $KeyInfo } default { Write-AppLog "Unhandled input mode: $($script:InputState.Mode)" "WARN" } }; $null = Invoke-PmcRenderRequest -ForceRedraw ($script:InputState.Mode -ne "Normal") }
function Process-NormalModeKey { param([System.ConsoleKeyInfo]$KeyInfo); Write-AppLog "Process-NormalModeKey: START Key=$($KeyInfo.Key), Char='$($KeyInfo.KeyChar)', Modifiers=$($KeyInfo.Modifiers)" "TRACE"; $currentScreenDef = Get-CurrentScreen; if ($null -eq $currentScreenDef) { Write-AppLog "Process-NormalModeKey: ERROR - currentScreenDef is null." "ERROR"; return }; if ($KeyInfo.Key -eq 'Tab') { $direction = 'Next'; if ($KeyInfo.Modifiers -band [System.ConsoleModifiers]::Shift) { $direction = 'Previous' }; Move-Focus -Direction $direction; return }; if ($script:FocusedViewName -ne $null) { $focusedViewDef = ($currentScreenDef.Views | Where-Object { $_.Name -eq $script:FocusedViewName } | Select-Object -First 1); if ($focusedViewDef) { $actionHandledByView = $false; $isDisabled = $focusedViewDef.IsDisabled ?? $false; if (-not $isDisabled) { switch ($focusedViewDef.Type) { 'ButtonView' { if ($KeyInfo.Key -eq 'Enter' -and $focusedViewDef.OnClick -is [scriptblock]) { Write-AppLog "Executing ButtonView '$($script:FocusedViewName)' OnClick via Enter." "INFO"; try { & $focusedViewDef.OnClick } catch { Handle-Error $_ "executing ButtonView OnClick" }; $actionHandledByView = $true } } 'CheckboxView' { if ($KeyInfo.Key -eq 'Spacebar' -and $focusedViewDef.OnToggle -is [scriptblock]) { Write-AppLog "Executing CheckboxView '$($script:FocusedViewName)' OnToggle via Spacebar." "INFO"; $currentState = $false; try { if ($focusedViewDef.IsChecked -is [scriptblock]) { $currentState = [bool](& $focusedViewDef.IsChecked) } elseif ($focusedViewDef.ContainsKey('IsChecked')) { $currentState = [bool]$focusedViewDef.IsChecked } } catch {}; $newState = -not $currentState; try { & $focusedViewDef.OnToggle $newState } catch { Handle-Error $_ "executing CheckboxView OnToggle" }; $actionHandledByView = $true } } 'InputView' { if ($KeyInfo.Key -eq 'Enter' -and $currentScreenDef.Name -eq 'SettingsScreen') { Write-AppLog "Process-NormalModeKey: Enter pressed on focused InputView '$($script:FocusedViewName)' on Settings Screen." "DEBUG"; switch ($script:FocusedViewName) { 'Setting1Input' { Edit-Setting_CAAPath } 'Setting2Input' { Edit-Setting_LogSize } default { Show-Warning "Editing not implemented for this input field." 3 } }; $actionHandledByView = $true } } 'ListView' { $viewState = $script:ListViewStates[$script:FocusedViewName]; if ($null -ne $viewState) { $currentIndex = $viewState.SelectedIndex; $itemCount = $viewState.ItemCount; $items = $viewState.Items; switch ($KeyInfo.Key) { 'UpArrow' { if ($itemCount -gt 0) { $viewState.SelectedIndex = ($currentIndex - 1 + $itemCount) % $itemCount; Write-AppLog "ListView '$($script:FocusedViewName)' UpArrow: Index set to $($viewState.SelectedIndex)" "TRACE"; Invoke-PmcRenderRequest -ForceRedraw $true }; $actionHandledByView = $true } 'DownArrow' { if ($itemCount -gt 0) { $viewState.SelectedIndex = ($currentIndex + 1) % $itemCount; Write-AppLog "ListView '$($script:FocusedViewName)' DownArrow: Index set to $($viewState.SelectedIndex)" "TRACE"; Invoke-PmcRenderRequest -ForceRedraw $true }; $actionHandledByView = $true } 'Enter' { if ($itemCount -gt 0 -and $currentIndex -ge 0 -and $currentIndex -lt $itemCount -and $currentScreenDef.HandleItemSelect) { $selectedItemObject = $items[$currentIndex]; Write-AppLog "Executing item selection for index $currentIndex (Object: $($selectedItemObject.ID2 ?? $selectedItemObject.Task ?? $selectedItemObject.DisplayValue ?? '?')) on screen '$($currentScreenDef.Name)' via Enter" "INFO"; try { & $currentScreenDef.HandleItemSelect $selectedItemObject } catch { Handle-Error $_ "Executing item selection via Enter on ListView" } } else { Write-AppLog "Enter on ListView '$($script:FocusedViewName)', but no item selected or no handler." "DEBUG" }; $actionHandledByView = $true } } } else { Write-AppLog "ListView '$($script:FocusedViewName)' state not found!" "WARN" } } } } else { Write-AppLog "Process-NormalModeKey: Focused view '$($script:FocusedViewName)' is disabled. Ignoring action key." "DEBUG"; Show-Warning "($($focusedViewDef.Text ?? $focusedViewDef.Name)) is disabled." 2; $actionHandledByView = $true }; if ($actionHandledByView) { Write-AppLog "Process-NormalModeKey: Action handled by focused view '$($script:FocusedViewName)' or ListView navigation." "DEBUG"; return } else { Write-AppLog "Process-NormalModeKey: Key '$($KeyInfo.Key)' pressed on focused view '$($script:FocusedViewName)', but view type '$($focusedViewDef.Type)' didn't handle it." "TRACE" } } else { Write-AppLog "Process-NormalModeKey: Focused view name '$($script:FocusedViewName)' set, but definition not found in screen views." "WARN" } }; $choiceInput = ""; if (-not [char]::IsControl($KeyInfo.KeyChar)) { $choiceInput = $KeyInfo.KeyChar.ToString(); Write-AppLog "Process-NormalModeKey: Derived choiceInput='$choiceInput' from KeyChar." "TRACE" } elseif ($KeyInfo.Key -eq 'Escape') { Write-AppLog "Process-NormalModeKey: Handling Escape key." "DEBUG"; $backActionKey = $currentScreenDef.BackActionKey ?? '0'; Write-AppLog "Process-NormalModeKey: Escape pressed. BackActionKey='$backActionKey'. Action Keys: $($currentScreenDef.Actions.Keys -join ', ')" "TRACE"; if ($currentScreenDef.Actions -and $currentScreenDef.Actions.ContainsKey($backActionKey)) { Write-AppLog "Executing back action for key '$backActionKey' on screen '$($currentScreenDef.Name)' due to Escape." "INFO"; try { & $currentScreenDef.Actions[$backActionKey] } catch { Handle-Error $_ "Executing back action '$backActionKey'" } } else { $null = Navigate-Back }; return } else { Write-AppLog "Process-NormalModeKey: Ignoring control key: $($KeyInfo.Key)" "TRACE"; return }; $choiceInput = $choiceInput.Trim(); if ([string]::IsNullOrEmpty($choiceInput)) { Write-AppLog "Process-NormalModeKey: choiceInput is empty after trim, returning." "TRACE"; return }; if ($choiceInput -ne '?' -and $script:StatusMessage.Timeout -eq $null -and $script:StatusMessage.Text.Length -gt 0) { Show-Message "" }; if ($choiceInput -eq "?") { Write-AppLog "Process-NormalModeKey: Handling '?' help trigger." "DEBUG"; $helpText = ""; if ($currentScreenDef.AvailableActions -is [scriptblock]) { try { $helpText = & $currentScreenDef.AvailableActions } catch { $helpText = "[ERR]" } } elseif ($currentScreenDef.AvailableActions) { $helpText = $currentScreenDef.AvailableActions } else { $helpText = "No help available for this screen." }; $script:HelpScreenText = $helpText; Set-CurrentScreen -ScreenDefinition $HelpScreen; return }; $actionTaken = $false; $upperChoice = $choiceInput.ToUpper(); Write-AppLog "Process-NormalModeKey: Checking Actions. upperChoice='$upperChoice'. Available Action Keys: $($currentScreenDef.Actions.Keys -join ', ')" "TRACE"; if ($currentScreenDef.Actions -and $currentScreenDef.Actions.ContainsKey($upperChoice)) { Write-AppLog "Process-NormalModeKey: Match found for action key '$upperChoice'. Executing..." "INFO"; try { & $currentScreenDef.Actions[$upperChoice]; $actionTaken = $true } catch { Handle-Error $_ "Executing action '$upperChoice'" } } else { Write-AppLog "Process-NormalModeKey: No action key match for '$upperChoice'." "TRACE" }; $itemNumber = 0; $isNumericMatch = $choiceInput -match '^\d+$'; $canParse = $false; if ($isNumericMatch) { $canParse = [int]::TryParse($choiceInput, [ref]$itemNumber) }; Write-AppLog "Process-NormalModeKey: Checking numeric fallback. IsNumericMatch=$isNumericMatch, CanParse=$canParse, ParsedValue=$itemNumber" "TRACE"; if (-not $actionTaken -and $isNumericMatch -and $canParse) { if ($currentScreenDef.HandleItemSelect) { Write-AppLog "Process-NormalModeKey: Detected numeric input '$itemNumber' for fallback selection." "TRACE"; $targetListViewName = $currentScreenDef.DefaultFocusViewName; $itemCount = 0; $items = @(); if ($script:ListViewStates.ContainsKey($targetListViewName)) { $viewState = $script:ListViewStates[$targetListViewName]; $itemCount = $viewState.ItemCount; $items = $viewState.Items } else { Write-AppLog "Fallback numeric select: ListView state not found for '$targetListViewName'" "WARN" }; Write-AppLog "Process-NormalModeKey: Fallback ItemCount=$itemCount" "TRACE"; if ($itemNumber -ge 1 -and $itemNumber -le $itemCount) { if ($items -ne $null -and $itemNumber -le $items.Count) { $selectedItemObject = $items[$itemNumber - 1]; Write-AppLog "Executing item selection #$itemNumber (Object: $($selectedItemObject.ID2 ?? $selectedItemObject.Task ?? $selectedItemObject.DisplayValue ?? '?')) on screen '$($currentScreenDef.Name)' via numeric fallback" "INFO"; try { & $currentScreenDef.HandleItemSelect $selectedItemObject; $actionTaken = $true } catch { Handle-Error $_ "Executing item selection #$itemNumber (numeric fallback)" } } else { Show-Warning "Internal error retrieving item #$itemNumber." } } elseif ($itemNumber -gt 0) { Write-AppLog "Process-NormalModeKey: Item number $itemNumber out of range (1-$itemCount)." "DEBUG"; Show-Warning "Item number '$itemNumber' is out of range (1-$itemCount)." 5; $actionTaken = $true } else { Write-AppLog "Process-NormalModeKey: Parsed item number $itemNumber is not -ge 1." "TRACE" } } else { Write-AppLog "Process-NormalModeKey: Numeric input detected, but screen '$($currentScreenDef.Name)' has no HandleItemSelect defined." "DEBUG" } }; if (-not $actionTaken) { Write-AppLog "Process-NormalModeKey: No action or valid item selection found for '$choiceInput'." "DEBUG"; Show-Warning "'$choiceInput' is not a valid action or item number." 5 }; Write-AppLog "Process-NormalModeKey: END" "TRACE" }
function Process-TextInputKey { param([System.ConsoleKeyInfo]$KeyInfo); $buffer = $script:InputState.Buffer; $cursorPos = $script:InputState.CursorPos; $maxLength = $script:InputState.MaxLength; switch ($KeyInfo.Key) { 'Enter' { $inputText = $buffer.ToString(); if ($inputText.Length -eq 0 -and -not [string]::IsNullOrEmpty($script:InputState.DefaultValueInternal)) { $inputText = $script:InputState.DefaultValueInternal; Write-AppLog "TextInput submitted with default value: '$inputText'" "DEBUG" } else { Write-AppLog "TextInput submitted: '$inputText'" "DEBUG" }; $isValid = $true; $validationCallback = $script:InputState.ValidationCallback; if ($validationCallback -ne $null) { Write-AppLog "Executing TextInput Validation Callback..." "TRACE"; try { $validationResult = & $validationCallback $inputText; if ($validationResult -is [bool]) { $isValid = $validationResult } else { Write-AppLog "TextInput Validation Callback did not return a boolean. Assuming invalid." "WARN"; $isValid = $false } } catch { Handle-Error $_ "executing TextInput validation callback"; $isValid = $false } }; if ($isValid) { $submitCallback = $script:InputState.SubmitCallback; $tempDataForCallback = $script:InputState.TempData; Reset-InputState; if ($submitCallback -ne $null) { Write-AppLog "Executing TextInput Submit Callback..." "TRACE"; try { & $submitCallback $inputText $tempDataForCallback } catch { Handle-Error $_ "executing TextInput submit callback" } } else { Write-AppLog "TextInput Submit Callback was null after reset." "TRACE" } } else { Show-Error ($script:InputState.ValidationMessage); Write-AppLog "TextInput validation failed for input '$inputText'." "DEBUG" } } 'Escape' { Write-AppLog "TextInput cancelled via Escape." "DEBUG"; $cancelCallback = $script:InputState.CancelCallback; $tempDataForCallback = $script:InputState.TempData; Reset-InputState; if ($cancelCallback -ne $null) { Write-AppLog "Executing TextInput Cancel Callback..." "TRACE"; try { & $cancelCallback $tempDataForCallback } catch { Handle-Error $_ "executing TextInput cancel callback" } } else { Write-AppLog "TextInput Cancel Callback was null after reset." "TRACE" } } 'Backspace' { if ($cursorPos -gt 0) { $buffer.Remove($cursorPos - 1, 1) | Out-Null; $script:InputState.CursorPos-- } } 'Delete' { if ($cursorPos -lt $buffer.Length) { $buffer.Remove($cursorPos, 1) | Out-Null } } 'LeftArrow' { if ($cursorPos -gt 0) { $script:InputState.CursorPos-- } } 'RightArrow'{ if ($cursorPos -lt $buffer.Length) { $script:InputState.CursorPos++ } } 'Home' { $script:InputState.CursorPos = 0 } 'End' { $script:InputState.CursorPos = $buffer.Length } Default { if (-not [char]::IsControl($KeyInfo.KeyChar)) { if ($maxLength -eq 0 -or $buffer.Length -lt $maxLength) { $buffer.Insert($cursorPos, $KeyInfo.KeyChar) | Out-Null; $script:InputState.CursorPos++ } else { Write-AppLog "Max length ($maxLength) reached for TextInput." "TRACE" } } } } }
function Process-NumericChoiceKey { param([System.ConsoleKeyInfo]$KeyInfo); $buffer = $script:InputState.Buffer; $cancelKey = $script:InputState.CancelOptionKey; $minValue = $script:InputState.MinValue; $maxValue = $script:InputState.MaxValue; switch ($KeyInfo.Key) { 'Enter' { $inputText = $buffer.ToString(); $choice = 0; if ([int]::TryParse($inputText, [ref]$choice)) { if ($choice -ge $minValue -and $choice -le $maxValue) { Write-AppLog "NumericChoice submitted: $choice" "DEBUG"; $submitCallback = $script:InputState.SubmitCallback; $tempDataForCallback = $script:InputState.TempData; Reset-InputState; if ($submitCallback -ne $null) { Write-AppLog "Executing NumericChoice Submit Callback..." "TRACE"; try { & $submitCallback $choice $tempDataForCallback } catch { Handle-Error $_ "executing NumericChoice submit callback" } } else { Write-AppLog "NumericChoice Submit Callback was null after reset." "TRACE" }; return } else { Show-Warning "Input '$inputText' is outside the allowed range ($minValue-$maxValue)." 5; } } else { if (-not [string]::IsNullOrEmpty($inputText)) { Show-Warning "Invalid input '$inputText'. Please enter a number between $minValue and $maxValue." 5; } } } 'Escape' { Write-AppLog "NumericChoice cancelled via Escape." "DEBUG"; $cancelCallback = $script:InputState.CancelCallback; $tempDataForCallback = $script:InputState.TempData; Reset-InputState; if ($cancelCallback -ne $null) { Write-AppLog "Executing NumericChoice Cancel Callback..." "TRACE"; try { & $cancelCallback $tempDataForCallback } catch { Handle-Error $_ "executing NumericChoice cancel callback" } } else { Write-AppLog "NumericChoice Cancel Callback was null after reset." "TRACE" } } 'Backspace' { if ($script:InputState.CursorPos -gt 0) { $buffer.Remove($script:InputState.CursorPos - 1, 1) | Out-Null; $script:InputState.CursorPos-- } } Default { if (-not [char]::IsControl($KeyInfo.KeyChar)) { if (-not [string]::IsNullOrEmpty($cancelKey) -and $KeyInfo.KeyChar.ToString() -eq $cancelKey) { Write-AppLog "NumericChoice cancelled via CancelKey '$cancelKey'." "DEBUG"; $cancelCallback = $script:InputState.CancelCallback; $tempDataForCallback = $script:InputState.TempData; Reset-InputState; if ($cancelCallback -ne $null) { Write-AppLog "Executing NumericChoice Cancel Callback (CancelKey)..." "TRACE"; try { & $cancelCallback $tempDataForCallback } catch { Handle-Error $_ "executing NumericChoice cancel callback (CancelKey)" } } else { Write-AppLog "NumericChoice Cancel Callback was null after reset." "TRACE" }; return }; if ($KeyInfo.KeyChar -match '\d') { $buffer.Insert($script:InputState.CursorPos, $KeyInfo.KeyChar) | Out-Null; $script:InputState.CursorPos++ } else { Write-AppLog "Ignoring non-digit character '$($KeyInfo.KeyChar)' in NumericChoice mode." "TRACE" } } } } }
function Process-ConfirmActionKey { param([System.ConsoleKeyInfo]$KeyInfo); $options = $script:InputState.Options; if ($KeyInfo.Key -eq 'Enter') { if ($options.Yes.Key -eq "Enter") { Write-AppLog "ConfirmAction confirmed via Enter key (Yes='Enter')." "DEBUG"; $confirmCallback = $options.Yes.Callback; $tempDataForCallback = $script:InputState.TempData; Reset-InputState; if ($confirmCallback -ne $null) { Write-AppLog "Executing ConfirmAction Yes Callback (Enter)..." "TRACE"; try { & $confirmCallback $tempDataForCallback } catch { Handle-Error $_ "executing ConfirmAction confirm callback (Enter)" } } else { Write-AppLog "ConfirmAction Yes Callback was null after reset." "TRACE" }; return } else { Write-AppLog "Enter key pressed in ConfirmAction, but Yes option is not 'Enter' ($($options.Yes.Key)). Ignoring." "TRACE" } }; if ($KeyInfo.Key -eq 'Escape') { Write-AppLog "ConfirmAction cancelled via Escape." "DEBUG"; $cancelCallback = $options.Cancel.Callback; $tempDataForCallback = $script:InputState.TempData; Reset-InputState; if ($cancelCallback -ne $null) { Write-AppLog "Executing ConfirmAction Cancel Callback (Escape)..." "TRACE"; try { & $cancelCallback $tempDataForCallback } catch { Handle-Error $_ "executing ConfirmAction cancel callback (Escape)" } } else { Write-AppLog "ConfirmAction Cancel Callback was null after reset." "TRACE" }; return }; if (-not [char]::IsControl($KeyInfo.KeyChar)) { $inputChar = $KeyInfo.KeyChar.ToString(); $callbackToExecute = $null; $callbackType = ""; if ($options.Yes.Key -ne "Enter" -and $options.Yes.Key.Equals($inputChar, [System.StringComparison]::OrdinalIgnoreCase)) { $callbackToExecute = $options.Yes.Callback; $callbackType = "Yes" } elseif ($options.No.Key.Equals($inputChar, [System.StringComparison]::OrdinalIgnoreCase)) { $callbackToExecute = $options.No.Callback; $callbackType = "No" } elseif ($options.Cancel.Key.Equals($inputChar, [System.StringComparison]::OrdinalIgnoreCase)) { $callbackToExecute = $options.Cancel.Callback; $callbackType = "Cancel (Key)" }; if ($callbackToExecute -ne $null) { Write-AppLog "ConfirmAction choice made ($callbackType '$inputChar')." "DEBUG"; $tempDataForCallback = $script:InputState.TempData; Reset-InputState; Write-AppLog "Executing ConfirmAction $callbackType Callback..." "TRACE"; try { & $callbackToExecute $tempDataForCallback } catch { Handle-Error $_ "executing ConfirmAction $callbackType callback" } } else { Show-Warning "Invalid option '$inputChar'." 3 } } }
function Process-SelectionModeKey { param([System.ConsoleKeyInfo]$KeyInfo); $currentPageItemsCount = $script:SelectionScreenItems.Count; $currentIndex = $script:InputState.CurrentSelectionIndex; switch ($KeyInfo.Key) { 'Enter' { if ($currentPageItemsCount -gt 0 -and $currentIndex -ge 0 -and $currentIndex -lt $currentPageItemsCount) { $displayIndex = $currentIndex + 1; if ($script:SelectionScreenItemMap.ContainsKey($displayIndex)) { $selectedItem = $script:SelectionScreenItemMap[$displayIndex]; Write-AppLog "SelectionMode confirmed item #$displayIndex." "DEBUG"; $onSelectCallback = $script:SelectionScreenOnItemSelected; $tempDataFromSelection = $script:TempDataForSelection; Reset-InputState; Navigate-Back | Out-Null; if ($onSelectCallback -ne $null) { try { & $onSelectCallback $selectedItem $tempDataFromSelection } catch { Handle-Error $_ "executing SelectionScreen OnItemSelected callback" } } } else { Write-AppLog "SelectionMode Error: Item map doesn't contain key $displayIndex." "ERROR"; Show-Error "Internal selection error." } } else { Write-AppLog "SelectionMode Enter pressed with no valid selection (Index: $currentIndex, Count: $currentPageItemsCount)." "DEBUG" } } 'Escape' { Write-AppLog "SelectionMode cancelled via Escape." "DEBUG"; $onCancelCallback = $script:SelectionScreenOnCancel; $tempDataFromSelection = $script:TempDataForSelection; Reset-InputState; Navigate-Back | Out-Null; if ($onCancelCallback -ne $null) { try { & $onCancelCallback $tempDataFromSelection } catch { Handle-Error $_ "executing SelectionScreen OnCancel callback" } } } 'UpArrow' { if ($currentPageItemsCount -gt 0) { $script:InputState.CurrentSelectionIndex = ($currentIndex - 1 + $currentPageItemsCount) % $currentPageItemsCount; Update-SelectionScreenRowColors } } 'DownArrow' { if ($currentPageItemsCount -gt 0) { $script:InputState.CurrentSelectionIndex = ($currentIndex + 1) % $currentPageItemsCount; Update-SelectionScreenRowColors } } 'PageUp' { if ($script:SelectionScreenPage -gt 0) { $script:SelectionScreenPage--; Update-SelectionScreenPagedData; $script:InputState.CurrentSelectionIndex = 0; Update-SelectionScreenRowColors } } 'PageDown' { if ($script:SelectionScreenPage -lt ($script:SelectionScreenTotalPages - 1)) { $script:SelectionScreenPage++; Update-SelectionScreenPagedData; $script:InputState.CurrentSelectionIndex = 0; Update-SelectionScreenRowColors } } Default { if ($KeyInfo.KeyChar -match '\d') { $num = 0; if ([int]::TryParse($KeyInfo.KeyChar.ToString(), [ref]$num)) { if ($num -ge 1 -and $num -le $currentPageItemsCount) { $script:InputState.CurrentSelectionIndex = $num - 1; Update-SelectionScreenRowColors } else { Show-Warning "Number '$num' out of range for current page (1-$currentPageItemsCount)." 3 } } } elseif ($KeyInfo.KeyChar -match '[0-9A-Za-z]') { $currentScreenDef = Get-CurrentScreen; $upperChoice = $KeyInfo.KeyChar.ToString().ToUpper(); if ($currentScreenDef.Actions -and $currentScreenDef.Actions.ContainsKey($upperChoice)) { Write-AppLog "Executing action '$upperChoice' in SelectionMode." "DEBUG"; try { & $currentScreenDef.Actions[$upperChoice] } catch { Handle-Error $_ "Executing action '$upperChoice' in SelectionMode" } } } } } }
#endregion

#region Focus Management Functions
function Get-FocusableViews { param([Parameter(Mandatory=$true)][hashtable]$ScreenDefinition); if ($null -eq $ScreenDefinition -or -not $ScreenDefinition.ContainsKey('Views')) { return @() }; $focusable = @($ScreenDefinition.Views | Where-Object { $_.IsFocusable -eq $true }); if ($focusable.Count -gt 0 -and $focusable[0].PSObject.Properties.Name.Contains('TabIndex')) { Write-AppLog "Get-FocusableViews: Sorting by TabIndex." "TRACE"; return @($focusable | Sort-Object TabIndex) } else { return $focusable } }
function Move-Focus { param([Parameter(Mandatory=$true)][ValidateSet('Next', 'Previous')]$Direction); $currentScreen = Get-CurrentScreen; if ($null -eq $currentScreen) { Write-AppLog "Move-Focus: No current screen." "WARN"; return }; $focusableViews = Get-FocusableViews -ScreenDefinition $currentScreen; if ($focusableViews.Count -eq 0) { Write-AppLog "Move-Focus: No focusable views on screen '$($currentScreen.Name)'." "DEBUG"; return }; if ($focusableViews.Count -eq 1) { if ($script:FocusedViewName -ne $focusableViews[0].Name) { $script:FocusedViewName = $focusableViews[0].Name; Write-AppLog "Move-Focus: Set focus to only available item '$($script:FocusedViewName)'" "DEBUG"; if ($focusableViews[0].Type -eq 'ListView' -and $script:ListViewStates.ContainsKey($script:FocusedViewName)) { $script:ListViewStates[$script:FocusedViewName].SelectedIndex = 0; $script:ListViewStates[$script:FocusedViewName].TopIndex = 0; Write-AppLog "Move-Focus: Reset ListView state for '$($script:FocusedViewName)'" "TRACE" }; Invoke-PmcRenderRequest -ForceRedraw $true }; return }; $currentFocusIndex = -1; if ($script:FocusedViewName -ne $null) { for ($i = 0; $i -lt $focusableViews.Count; $i++) { if ($focusableViews[$i].Name -eq $script:FocusedViewName) { $currentFocusIndex = $i; break } } }; $nextFocusIndex = 0; if ($currentFocusIndex -eq -1) { $nextFocusIndex = 0 } elseif ($Direction -eq 'Next') { $nextFocusIndex = ($currentFocusIndex + 1) % $focusableViews.Count } else { $nextFocusIndex = ($currentFocusIndex - 1 + $focusableViews.Count) % $focusableViews.Count }; $newFocusedViewName = $focusableViews[$nextFocusIndex].Name; if ($script:FocusedViewName -ne $newFocusedViewName) { $script:FocusedViewName = $newFocusedViewName; Write-AppLog "Move-Focus ($Direction): Set focus to '$($script:FocusedViewName)' (Index: $nextFocusIndex)" "INFO"; if ($focusableViews[$nextFocusIndex].Type -eq 'ListView') { if (-not $script:ListViewStates.ContainsKey($script:FocusedViewName)) { $script:ListViewStates[$script:FocusedViewName] = @{SelectedIndex=0; TopIndex=0; ItemCount=0; Items=@()} }; $script:ListViewStates[$script:FocusedViewName].SelectedIndex = 0; $script:ListViewStates[$script:FocusedViewName].TopIndex = 0; Write-AppLog "Move-Focus: Reset ListView state for '$($script:FocusedViewName)'" "TRACE" }; Invoke-PmcRenderRequest -ForceRedraw $true } else { Write-AppLog "Move-Focus ($Direction): Focus remained on '$($script:FocusedViewName)'" "TRACE" } }
function Get-FocusedListViewSelectedItem { param([string]$ViewName); if ($script:FocusedViewName -ne $ViewName) { return $null }; $viewState = $script:ListViewStates[$ViewName]; if ($null -eq $viewState) { Write-AppLog "Get-FocusedListViewSelectedItem: State not found for '$ViewName'" "WARN"; return $null }; $index = $viewState.SelectedIndex; if ($index -ge 0 -and $index -lt $viewState.ItemCount -and $viewState.Items -ne $null -and $index -lt $viewState.Items.Count) { return $viewState.Items[$index] }; return $null }
#endregion

#region Pomodoro / Clock Functions
function Format-SegmentDigit { param($DigitChar); if ($script:SegmentPatterns.ContainsKey($DigitChar)) { return $script:SegmentPatterns[$DigitChar] } else { Write-AppLog "Format-SegmentDigit: Unknown char '$DigitChar'" "WARN"; $placeholder = @(); for($i=0; $i -lt $script:SegmentHeight; $i++){ $placeholder += "?" * $script:SegmentWidth }; return $placeholder } }
function Format-SegmentTime { param([TimeSpan]$TimeSpan); try { $timeString = $TimeSpan.ToString("mm\:ss"); $outputLines = @(); for($i=0; $i -lt $script:SegmentHeight; $i++){ $outputLines += "" }; foreach($char in $timeString.ToCharArray()){ $digitPattern = Format-SegmentDigit $char; for($i=0; $i -lt $script:SegmentHeight; $i++){ $outputLines[$i] += $digitPattern[$i] + " " } }; for($i=0; $i -lt $script:SegmentHeight; $i++){ $outputLines[$i] = $outputLines[$i].TrimEnd() }; return $outputLines } catch { Write-AppLog "Error in Format-SegmentTime: $($_.Exception.Message)" "ERROR"; return $null } }
function Start-Pomodoro { Write-AppLog "Start-Pomodoro: Starting timer state" "INFO"; $script:PomodoroState.Running = $true; $script:PomodoroState.Mode = 'Work'; $script:PomodoroState.DurationSec = ($Global:AppConfig.pomodoroWorkDurationMin ?? 25) * 60; $script:PomodoroState.RemainingTS = [TimeSpan]::FromSeconds($script:PomodoroState.DurationSec); $script:PomodoroState.StartTime = Get-Date; $script:PomodoroState.LastUpdateTime = $script:PomodoroState.StartTime; $script:PomodoroState.RequestRender = $true; Show-Info "Pomodoro Started (Work)" 3 }
function Stop-Pomodoro { Write-AppLog "Stop-Pomodoro: Stopping timer state" "INFO"; $script:PomodoroState.Running = $false; $script:PomodoroState.StartTime = $null; $script:PomodoroState.LastUpdateTime = $null; $script:PomodoroState.DurationSec = ($Global:AppConfig.pomodoroWorkDurationMin ?? 25) * 60; $script:PomodoroState.RemainingTS = [TimeSpan]::FromSeconds($script:PomodoroState.DurationSec); $script:PomodoroState.RequestRender = $true; Show-Warning "Pomodoro Stopped." 3 }
function Toggle-Pomodoro { if ($script:PomodoroState.Running) { Stop-Pomodoro } else { Start-Pomodoro } }
function Switch-PomodoroMode { if ($script:PomodoroState.Mode -eq 'Work') { $script:PomodoroState.Mode = 'Break'; $script:PomodoroState.DurationSec = ($Global:AppConfig.pomodoroBreakDurationMin ?? 5) * 60; Show-Warning "Work Complete! Starting Break." 0 } else { $script:PomodoroState.Mode = 'Work'; $script:PomodoroState.DurationSec = ($Global:AppConfig.pomodoroWorkDurationMin ?? 25) * 60; Show-Warning "Break Over! Starting Work." 0 }; $script:PomodoroState.RemainingTS = [TimeSpan]::FromSeconds($script:PomodoroState.DurationSec); $script:PomodoroState.StartTime = Get-Date; $script:PomodoroState.LastUpdateTime = $script:PomodoroState.StartTime; $script:PomodoroState.RequestRender = $true; $script:PomodoroState.Running = $true }
#endregion

#region Help Overlay Functions
# (No functions specific to Help Overlay itself, handled by screen definition)
#endregion

#region Project Management Functions
function Add-ManualProject {
    Write-AppLog "Starting Add-ManualProject sequence." "INFO"
    Show-Info "Enter project details. Press Enter to skip optional fields, Esc to cancel."
    $initialTempData = [ordered]@{ AllProjects = Load-ProjectTodoJson }
    $requestParams = @{
        Prompt = "Full Name (Required)"
        ValidationErrorMessage = "Project Full Name is required."
        ValidationCallback = { param($input) -not [string]::IsNullOrWhiteSpace($input) }
        SubmitCallback = {
            param($fullName, $tempData)
            $tempData.FullName = $fullName
            Write-AppLog "Add-ManualProject: Got Full Name: $fullName" "DEBUG"
            Add-ManualProject_ID2 -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Add-ManualProject cancelled at Full Name." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_ID2 {
    param($tempData)
    $requestParams = @{
        Prompt = "Project ID2 (Unique, Required, e.g., P123)"
        ValidationErrorMessage = "Project ID2 cannot be empty and must be unique."
        ValidationCallback = {
            param($id2)
            if ([string]::IsNullOrWhiteSpace($id2)) { return $false }
            if ($tempData.AllProjects | Where-Object { $_.ID2 -eq $id2 }) { return $false }
            return $true
        }
        SubmitCallback = {
            param($id2, $tempDataSubmit)
            $tempDataSubmit.ID2 = $id2
            Write-AppLog "Add-ManualProject: Got ID2: $id2" "DEBUG"
            Add-ManualProject_ID1 -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ManualProject cancelled at ID2." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_ID1 {
    param($tempData)
    $requestParams = @{
        Prompt = "ID1 (Optional)"
        SubmitCallback = {
            param($id1, $tempDataSubmit)
            $tempDataSubmit.ID1 = $id1
            Write-AppLog "Add-ManualProject: Got ID1: $id1" "DEBUG"
            Add-ManualProject_AssignedDate -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ManualProject cancelled at ID1." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_AssignedDate {
    param($tempData)
    $defaultAssignedInternal = (Get-Date).ToString($global:DATE_FORMAT_INTERNAL)
    $requestParams = @{
        Prompt = "Assigned Date (YYYYMMDD or common format)"
        DefaultValue = $defaultAssignedInternal
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($assignedInput)
            $parsedDateInternal = Parse-DateSafeInternal $assignedInput
            return -not ([string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($assignedInput, $tempDataSubmit)
            $tempDataSubmit.AssignedDate = Parse-DateSafeInternal $assignedInput
            Write-AppLog "Add-ManualProject: Got AssignedDate: $($tempDataSubmit.AssignedDate)" "DEBUG"
            Add-ManualProject_DueDate -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ManualProject cancelled at Assigned Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_DueDate {
    param($tempData)
    $assignedDT = try { [datetime]::ParseExact($tempData.AssignedDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { Get-Date }
    $defaultDueInternal = $assignedDT.AddDays(42).ToString($global:DATE_FORMAT_INTERNAL)
    $requestParams = @{
        Prompt = "Due Date (YYYYMMDD or common format)"
        DefaultValue = $defaultDueInternal
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($dueInput)
            $parsedDateInternal = Parse-DateSafeInternal $dueInput
            return -not ([string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($dueInput, $tempDataSubmit)
            $tempDataSubmit.DueDate = Parse-DateSafeInternal $dueInput
            Write-AppLog "Add-ManualProject: Got DueDate: $($tempDataSubmit.DueDate)" "DEBUG"
            Add-ManualProject_BFDate -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ManualProject cancelled at Due Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_BFDate {
    param($tempData)
    $requestParams = @{
        Prompt = "BF Date (YYYYMMDD or common format, Enter to skip)"
        ValidationErrorMessage = "Invalid date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($bfInput)
            if ([string]::IsNullOrWhiteSpace($bfInput)) { return $true } # Allow empty
            $parsedDateInternal = Parse-DateSafeInternal $bfInput
            return (-not [string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($bfInput, $tempDataSubmit)
            $tempDataSubmit.BFDate = Parse-DateSafeInternal $bfInput
            Write-AppLog "Add-ManualProject: Got BFDate: $($tempDataSubmit.BFDate)" "DEBUG"
            Add-ManualProject_ParentFolder -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ManualProject cancelled at BF Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_ParentFolder {
    param($tempData)
    $requestParams = @{
        Prompt = "Parent Folder Path for Project (Optional, Enter to skip)"
        SubmitCallback = {
            param($parentFolder, $tempDataSubmit)
            $tempDataSubmit.ParentFolder = $parentFolder.Trim()
            Write-AppLog "Add-ManualProject: Got ParentFolder: $parentFolder" "DEBUG"
            Add-ManualProject_GetCAAName -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ManualProject cancelled at Parent Folder." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_GetCAAName {
    param($tempData)
    $requestParams = @{
        Prompt = "CAA Filename (optional, relative)"
        SubmitCallback = {
            param($caaName, $tempDataSubmit)
            $tempDataSubmit.CAAName = $caaName
            Write-AppLog "Add-ManualProject: Got CAAName: $caaName" "DEBUG"
            Add-ManualProject_GetRequestName -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ManualProject cancelled at CAA Name." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_GetRequestName {
    param($tempData)
    $requestParams = @{
        Prompt = "Request Filename (optional, relative)"
        SubmitCallback = {
            param($reqName, $tempDataSubmit)
            $tempDataSubmit.RequestName = $reqName
            Write-AppLog "Add-ManualProject: Got RequestName: $reqName" "DEBUG"
            Add-ManualProject_GetT2020Name -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ManualProject cancelled at Request Name." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_GetT2020Name {
    param($tempData)
    $requestParams = @{
        Prompt = "T2020 Filename (optional, relative)"
        SubmitCallback = {
            param($t2020Name, $tempDataSubmit)
            $tempDataSubmit.T2020 = $t2020Name
            Write-AppLog "Add-ManualProject: Got T2020: $t2020Name" "DEBUG"
            Add-ManualProject_Confirm -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ManualProject cancelled at T2020 Name." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-ManualProject_Confirm {
    param($tempData)
    $newProjectData = $tempData.Clone()
    $newProjectData.Remove('AllProjects')
    $newProjectData.Status = "Active"
    $newProjectData.CompletedDate = ""
    $newProjectData.Todos = @()

    $projectFolder = ""
    if (-not [string]::IsNullOrEmpty($newProjectData.ParentFolder)) {
        $sanitizedFolderName = $newProjectData.ID2 -replace '[\\/:*?"<>|]+', '_'
        $projectFolder = Join-Path $newProjectData.ParentFolder $sanitizedFolderName
        $newProjectData.ProjFolder = $projectFolder
        Show-Info "Creating folder structure for '$($newProjectData.ID2)'..."
        $docsFolder = Join-Path $projectFolder "__DOCS__"
        $casDocsFolder = Join-Path $docsFolder "__CAS_DOCS__"
        $tpDocsFolder = Join-Path $docsFolder "__TP_DOCS__"
        if (Test-Path $projectFolder) {
            Write-AppLog "Manual Project: Target folder '$projectFolder' already exists." "WARN"
            Show-Warning "Target project folder '$projectFolder' already exists. Not recreating structure."
        } else {
            try {
                if (-not (Ensure-DirectoryExists -DirectoryPath $projectFolder)) { throw "Failed ensure project folder" }
                if (-not (Ensure-DirectoryExists -DirectoryPath $docsFolder)) { throw "Failed ensure docs folder" }
                if (-not (Ensure-DirectoryExists -DirectoryPath $casDocsFolder)) { throw "Failed ensure cas_docs folder" }
                if (-not (Ensure-DirectoryExists -DirectoryPath $tpDocsFolder)) { throw "Failed ensure tp_docs folder" }
                Show-Success "Created project folder structure at '$projectFolder'."
            } catch {
                Handle-Error $_ "Creating manual project folders for '$($newProjectData.ID2)'"
                return
            }
        }
    } else {
        $newProjectData.ProjFolder = ""
    }
    $newProjectData.Remove('ParentFolder')

    Show-Info "Review the details below:"
    $newProjectData.GetEnumerator() | ForEach-Object {
        $displayValue = $_.Value
        if ($_.Name -match 'Date' -and -not [string]::IsNullOrEmpty($_.Value)) {
            $displayValue = Format-DateSafeDisplay $_.Value
        } elseif ($null -eq $displayValue) {
            $displayValue = ""
        }
        Show-Info (" $($_.Name.PadRight(15)): " + $displayValue)
    }
    Show-Info ("-" * 40)

    $tempDataForConfirm = @{ ProjectDataToSave = $newProjectData }
    $confirmParams = @{
        Prompt = "Save this manually added project?"
        OnConfirm = {
            param($tempDataConfirm)
            Write-AppLog "Manual project add confirmed by user." "INFO"
            $projectToAdd = [PSCustomObject]$tempDataConfirm.ProjectDataToSave
            if ($null -eq $projectToAdd) {
                Write-AppLog "ERROR: ProjectDataToSave was null inside OnConfirm callback." "ERROR"
                Show-Error "Internal Error: Failed to retrieve project data for saving."
                return
            }
            $finalProjectObject = Add-Project -ProjectData $projectToAdd
            if ($finalProjectObject) {
                Show-Success "Project '$($finalProjectObject.ID2)' added manually."
            } else {
                Show-Error "Failed to add/save manually added project."
            }
        }
        OnCancel = {
            param($tempDataConfirm)
            Write-AppLog "Manual project add cancelled by user after review." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempDataForConfirm
    }
    Request-ConfirmAction @confirmParams
}
function Set-Project {
    param ([PSCustomObject]$ProjectContext = $null)
    $allProjects = Load-ProjectTodoJson
    if ($allProjects.Count -eq 0) {
        Show-Warning "No projects exist to update."
        return
    }
    $projectToUpdate = $null
    $indexToUpdate = -1

    $SelectProjectCallback = {
        param($selectedProject, $tempDataSelect)
        if (-not $selectedProject) {
            Write-AppLog "Project update cancelled at selection." "INFO"
            Show-Warning "Update cancelled."
            return
        }
        for ($i = 0; $i -lt $allProjects.Count; $i++) {
            if ($allProjects[$i].ID2 -eq $selectedProject.ID2) {
                $indexToUpdate = $i
                break
            }
        }
        if ($indexToUpdate -eq -1) {
            Write-AppLog "Consistency Error finding selected project ID '$($selectedProject.ID2)' for update." "ERROR"
            Show-Error "Consistency Error: Could not find selected project."
            return
        }
        $projectToUpdate = $allProjects[$indexToUpdate]
        Write-AppLog "Set-Project: Editing project '$($projectToUpdate.ID2)'" "INFO"
        Start-ProjectUpdateSequence -Project $projectToUpdate -AllProjects $allProjects -Index $indexToUpdate
    }

    if ($ProjectContext -ne $null) {
        for ($i = 0; $i -lt $allProjects.Count; $i++) {
            if ($allProjects[$i].ID2 -eq $ProjectContext.ID2) {
                $projectToUpdate = $allProjects[$i]
                $indexToUpdate = $i
                break
            }
        }
        if ($indexToUpdate -eq -1) {
            Write-AppLog "Consistency Error: Project context '$($ProjectContext.ID2)' provided to Set-Project not found." "ERROR"
            Show-Error "Consistency Error: Provided project context not found. Please select manually."
            $projectToUpdate = $null # Force selection below
        } else {
            Write-AppLog "Set-Project called with context: '$($ProjectContext.ID2)'" "INFO"
            Start-ProjectUpdateSequence -Project $projectToUpdate -AllProjects $allProjects -Index $indexToUpdate
            return
        }
    }

    # If no context or context not found, prompt for selection
    if ($null -eq $projectToUpdate) {
        $activeProjects = @($allProjects | Where-Object { [string]::IsNullOrEmpty($_.CompletedDate) })
        if ($activeProjects.Count -eq 0) {
            Show-Warning "No active projects available to update."
            return
        }
        try {
            $sortedActiveProjects = $activeProjects | Sort-Object -Property @{ Expression = { try { [datetime]::ParseExact($_.AssignedDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { [datetime]::MinValue } } } -ErrorAction Stop
        } catch {
            Handle-Error $_ "Sorting active projects for update"
            Show-Warning "Could not sort projects."
            $sortedActiveProjects = $activeProjects
        }
        $selectParams = @{
            Title = "UPDATE PROJECT - SELECT ACTIVE PROJECT"
            Items = $sortedActiveProjects
            ViewType = "ProjectSelection"
            Prompt = "Select project to update (0=Cancel)"
            OnItemSelected = $SelectProjectCallback
            OnCancel = {
                param($tempDataCancel)
                Write-AppLog "Project update cancelled at selection." "INFO"
                Show-Warning "Update cancelled."
            }
        }
        Select-ItemFromList @selectParams
    }
}
function Start-ProjectUpdateSequence {
    param( [PSCustomObject]$Project, [array]$AllProjects, [int]$Index )
    Show-Info "Editing project details for '$($Project.ID2)'. Press Enter to keep current value, Esc to cancel."
    $initialTempData = @{
        OriginalProject = $Project.PSObject.Copy()
        WorkingProject = $Project
        AllProjects = $AllProjects
        Index = $Index
    }
    $requestParams = @{
        Prompt = "Full name"
        DefaultValue = $Project.FullName
        ValidationErrorMessage = "Project Full Name is required."
        ValidationCallback = { param($input) -not [string]::IsNullOrWhiteSpace($input) }
        SubmitCallback = {
            param($fullName, $tempData)
            $tempData.WorkingProject.FullName = $fullName
            Write-AppLog "Set-Project: Got FullName: $fullName" "DEBUG"
            Start-ProjectUpdateSequence_ID1 -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Set-Project cancelled at Full Name." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Start-ProjectUpdateSequence_ID1 {
    param($tempData)
    $requestParams = @{
        Prompt = "ID1"
        DefaultValue = $tempData.WorkingProject.ID1
        SubmitCallback = {
            param($id1, $tempDataSubmit)
            $tempDataSubmit.WorkingProject.ID1 = $id1
            Write-AppLog "Set-Project: Got ID1: $id1" "DEBUG"
            Start-ProjectUpdateSequence_AssignedDate -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Set-Project cancelled at ID1." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Start-ProjectUpdateSequence_AssignedDate {
    param($tempData)
    $requestParams = @{
        Prompt = "Assigned date (YYYYMMDD or common format)"
        DefaultValue = $tempData.WorkingProject.AssignedDate
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($input)
            $parsedDateInternal = Parse-DateSafeInternal $input
            return -not ([string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($assignedInput, $tempDataSubmit)
            $tempDataSubmit.WorkingProject.AssignedDate = Parse-DateSafeInternal $assignedInput
            Write-AppLog "Set-Project: Got AssignedDate: $($tempDataSubmit.WorkingProject.AssignedDate)" "DEBUG"
            Start-ProjectUpdateSequence_DueDate -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Set-Project cancelled at Assigned Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Start-ProjectUpdateSequence_DueDate {
    param($tempData)
    $requestParams = @{
        Prompt = "Due date (YYYYMMDD or common format)"
        DefaultValue = $tempData.WorkingProject.DueDate
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($input)
            $parsedDateInternal = Parse-DateSafeInternal $input
            return -not ([string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($dueInput, $tempDataSubmit)
            $tempDataSubmit.WorkingProject.DueDate = Parse-DateSafeInternal $dueInput
            Write-AppLog "Set-Project: Got DueDate: $($tempDataSubmit.WorkingProject.DueDate)" "DEBUG"
            Start-ProjectUpdateSequence_BFDate -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Set-Project cancelled at Due Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Start-ProjectUpdateSequence_BFDate {
    param($tempData)
    $requestParams = @{
        Prompt = "BF date (YYYYMMDD or common format) or '-' to clear"
        DefaultValue = $tempData.WorkingProject.BFDate
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($input)
            if ($input -eq '-') { return $true }
            if ([string]::IsNullOrWhiteSpace($input)) { return $true }
            $parsedDateInternal = Parse-DateSafeInternal $input
            return (-not [string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($bfInput, $tempDataSubmit)
            if ($bfInput -eq '-') {
                $tempDataSubmit.WorkingProject.BFDate = ""
            } else {
                $tempDataSubmit.WorkingProject.BFDate = Parse-DateSafeInternal $bfInput
            }
            Write-AppLog "Set-Project: Got BFDate: $($tempDataSubmit.WorkingProject.BFDate)" "DEBUG"
            Start-ProjectUpdateSequence_Folder -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Set-Project cancelled at BF Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Start-ProjectUpdateSequence_Folder {
    param($tempData)
    Show-Info "Current Folder: $($tempData.WorkingProject.ProjFolder)"
    $confirmParams = @{
        Prompt = "Update project folder path?"
        OnConfirm = {
            param($tempDataConfirm)
            $initialPath = $tempDataConfirm.WorkingProject.ProjFolder ?? $Global:scriptRoot
            $requestPathParams = @{
                Prompt = "Select NEW Project Folder Path"
                InitialPath = $initialPath
                SelectFolder = $true # Select a folder
                OnPathSelected = {
                    param($newProjFolder, $tempDataPath)
                    if (-not [string]::IsNullOrWhiteSpace($newProjFolder) -and $newProjFolder -ne $tempDataPath.WorkingProject.ProjFolder) {
                        $tempDataPath.WorkingProject.ProjFolder = $newProjFolder.Trim()
                        Show-Info "Folder path updated (in memory)."
                    } else { Show-Warning "Folder path update cancelled or not changed." }
                    Start-ProjectUpdateSequence_Files -tempData $tempDataPath # Proceed regardless
                }
                OnCancel = {
                    param($tempDataPath)
                    Show-Warning "Folder path update cancelled."
                    Start-ProjectUpdateSequence_Files -tempData $tempDataPath # Proceed regardless
                }
                InitialTempData = $tempDataConfirm
            }
            Request-FilePath @requestPathParams
        }
        OnDeny = {
            param($tempDataDeny)
            Start-ProjectUpdateSequence_Files -tempData $tempDataDeny # Skip to next step
        }
        OnCancel = {
            param($tempDataCancel)
            Write-AppLog "Set-Project cancelled at Folder Update prompt." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-ConfirmAction @confirmParams
}
function Start-ProjectUpdateSequence_Files {
    param($tempData)
    # Placeholder - Add individual file selection (CAA, Request, T2020) using Request-FilePath if needed
    Write-AppLog "Set-Project: Skipping individual file updates (requires non-blocking browser or more prompts)." "DEBUG"
    Start-ProjectUpdateSequence_Save -tempData $tempData
}
function Start-ProjectUpdateSequence_Save {
    param($tempData)
    $original = $tempData.OriginalProject
    $updated = $tempData.WorkingProject
    $allProjs = $tempData.AllProjects
    $idx = $tempData.Index

    $changed = $false
    try {
        $propsToCompare = 'FullName', 'ID1', 'AssignedDate', 'DueDate', 'BFDate', 'ProjFolder', 'CAAName', 'RequestName', 'T2020'
        $differences = Compare-Object -ReferenceObject $original -DifferenceObject $updated -Property $propsToCompare -PassThru
        if ($null -ne $differences) {
            $changed = $true
        }
    } catch {
        Write-AppLog "Error comparing project objects: $($_.Exception.Message)" "WARN"
        $changed = $true # Assume changed if comparison fails
    }

    if ($changed) {
        Write-AppLog "Attempting to save updated project '$($updated.ID2)'" "INFO"
        if (Save-ProjectTodoJson -ProjectData $allProjs) {
            Show-Success "Project '$($updated.ID2)' updated successfully."
        } else {
            Show-Error "Failed to save updated project '$($updated.ID2)'."
        }
    } else {
        Show-Info "No changes detected for project '$($updated.ID2)'."
    }
    $script:RefreshDetailScreen = $true # Request detail screen refresh if it's the current one
}
function Set-ProjectComplete {
    param ([PSCustomObject]$ProjectContext = $null)
    $allProjects = Load-ProjectTodoJson
    if ($allProjects.Count -eq 0) {
        Show-Warning "No projects exist."
        return
    }
    $projectToComplete = $null
    $indexToUpdate = -1

    $SelectProjectCallback = {
        param($selectedProject, $tempDataSelect)
        if (-not $selectedProject) {
            Write-AppLog "Project completion cancelled at selection." "INFO"
            Show-Warning "Cancelled."
            return
        }
        for ($i = 0; $i -lt $allProjects.Count; $i++) {
            if ($allProjects[$i].ID2 -eq $selectedProject.ID2) {
                $indexToUpdate = $i
                break
            }
        }
        if ($indexToUpdate -eq -1) {
            Write-AppLog "Consistency Error finding project ID '$($selectedProject.ID2)' for completion." "ERROR"
            Show-Error "Consistency Error: Could not find selected project."
            return
        }
        $projectToComplete = $allProjects[$indexToUpdate]
        Confirm-ProjectCompletion -Project $projectToComplete -AllProjects $allProjects -Index $indexToUpdate
    }

    if ($ProjectContext -ne $null) {
        if (-not [string]::IsNullOrEmpty($ProjectContext.CompletedDate)) {
            Show-Warning "Project '$($ProjectContext.ID2)' is already marked as complete."
            return
        }
        for ($i = 0; $i -lt $allProjects.Count; $i++) {
            if ($allProjects[$i].ID2 -eq $ProjectContext.ID2) {
                $projectToComplete = $allProjects[$i]
                $indexToUpdate = $i
                break
            }
        }
        if ($indexToUpdate -eq -1) {
            Write-AppLog "Consistency Error: Project context '$($ProjectContext.ID2)' provided to Set-ProjectComplete not found." "ERROR"
            Show-Error "Consistency Error: Provided project context not found."
            $projectToComplete = $null # Force selection below
        } else {
            Write-AppLog "Set-ProjectComplete called with context: '$($ProjectContext.ID2)'" "INFO"
            Confirm-ProjectCompletion -Project $projectToComplete -AllProjects $allProjects -Index $indexToUpdate
            return
        }
    }

    if ($null -eq $projectToComplete) {
        $activeProjects = @($allProjects | Where-Object { [string]::IsNullOrEmpty($_.CompletedDate) })
        if ($activeProjects.Count -eq 0) {
            Show-Warning "No active projects to mark as complete."
            return
        }
        try {
            $sortedActiveProjects = $activeProjects | Sort-Object -Property @{ Expression = { try { [datetime]::ParseExact($_.AssignedDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { [datetime]::MinValue } } } -ErrorAction Stop
        } catch {
            Handle-Error $_ "Sorting active projects for completion"
            Show-Warning "Could not sort projects."
            $sortedActiveProjects = $activeProjects
        }
        $selectParams = @{
            Title = "COMPLETE PROJECT - SELECT ACTIVE PROJECT"
            Items = $sortedActiveProjects
            ViewType = "ProjectSelection"
            Prompt = "Select project to mark complete (0=Cancel)"
            OnItemSelected = $SelectProjectCallback
            OnCancel = {
                param($tempDataCancel)
                Write-AppLog "Project completion cancelled at selection." "INFO"
                Show-Warning "Cancelled."
            }
        }
        Select-ItemFromList @selectParams
    }
}
function Confirm-ProjectCompletion {
    param( [PSCustomObject]$Project, [array]$AllProjects, [int]$Index )
    Show-Info "Completing Project: $($Project.ID2) - $($Project.FullName)"
    $confirmParams = @{
        Prompt = "Mark project '$($Project.FullName)' as complete?"
        OnConfirm = {
            param($tempData)
            $completionDateInternal = (Get-Date).ToString($global:DATE_FORMAT_INTERNAL)
            $AllProjects[$Index].CompletedDate = $completionDateInternal
            $AllProjects[$Index].Status = "Completed"
            Write-AppLog "Attempting to mark project '$($Project.ID2)' as complete in data file." "INFO"
            if (Save-ProjectTodoJson -ProjectData $AllProjects) {
                Show-Success "Project '$($Project.ID2)' marked as complete."
            } else {
                Show-Error "Failed to save completion status for project '$($Project.ID2)'."
            }
            $script:RefreshDetailScreen = $true
        }
        OnCancel = {
            param($tempData)
            Write-AppLog "Project completion cancelled by user for '$($Project.ID2)'." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Request-ConfirmAction @confirmParams
}
function Remove-Project {
    param ([PSCustomObject]$ProjectContext = $null)
    $allProjects = Load-ProjectTodoJson
    if ($allProjects.Count -eq 0) {
        Show-Warning "No projects exist to remove."
        return
    }
    $projectToRemove = $null

    $SelectProjectCallback = {
        param($selectedProject, $tempDataSelect)
        if (-not $selectedProject) {
            Write-AppLog "Project removal cancelled at selection." "INFO"
            Show-Warning "Removal cancelled."
            return
        }
        $projectToRemove = $selectedProject
        Confirm-ProjectRemoval -Project $projectToRemove -AllProjects $allProjects
    }

    if ($ProjectContext -ne $null) {
        $foundInList = $allProjects | Where-Object { $_.ID2 -eq $ProjectContext.ID2 } | Select-Object -First 1
        if ($null -eq $foundInList) {
            Write-AppLog "Consistency Error: Project context '$($ProjectContext.ID2)' provided to Remove-Project not found." "ERROR"
            Show-Error "Consistency Error: Provided project context not found. Please select manually."
            $projectToRemove = $null # Force selection below
        } else {
            Write-AppLog "Remove-Project called with context: '$($ProjectContext.ID2)'" "INFO"
            $projectToRemove = $foundInList
            Confirm-ProjectRemoval -Project $projectToRemove -AllProjects $allProjects
            return
        }
    }

    if ($null -eq $projectToRemove) {
        try {
            $sortedAllProjects = $allProjects | Sort-Object -Property @{ Expression = { try { [datetime]::ParseExact($_.AssignedDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { [datetime]::MinValue } } } -ErrorAction Stop
        } catch {
            Handle-Error $_ "Sorting projects for removal"
            Show-Warning "Could not sort projects."
            $sortedAllProjects = $allProjects
        }
        $selectParams = @{
            Title = "REMOVE PROJECT - SELECT PROJECT"
            Items = $sortedAllProjects
            ViewType = "ProjectSelection"
            Prompt = "Select project to REMOVE (0=Cancel)"
            OnItemSelected = $SelectProjectCallback
            OnCancel = {
                param($tempDataCancel)
                Write-AppLog "Project removal cancelled at selection." "INFO"
                Show-Warning "Removal cancelled."
            }
        }
        Select-ItemFromList @selectParams
    }
}
function Confirm-ProjectRemoval {
    param( [PSCustomObject]$Project, [array]$AllProjects )
    $status = if ([string]::IsNullOrEmpty($Project.CompletedDate)) { "ACTIVE" } else { "Completed $(Format-DateSafeDisplay $Project.CompletedDate)" }
    Show-Info "Removing Project: $($Project.ID2) - $($Project.FullName) (Status: $status)"
    Show-Warning "This action PERMANENTLY removes the project entry and its associated Todos from the JSON data file."
    Show-Warning "It does NOT delete the project folder on disk or remove time tracking entries automatically."

    $initialConfirmParams = @{
        Prompt = "Confirm REMOVAL of project entry '$($Project.ID2)'?"
        OnConfirm = {
            param($tempDataInitial)
            if ([string]::IsNullOrEmpty($Project.CompletedDate)) {
                # Extra confirmation for active projects
                $confirmTextParams = @{
                    Prompt = "ACTIVE project. Type 'CONFIRM' to proceed"
                    ValidationErrorMessage = "Input must be 'CONFIRM'."
                    ValidationCallback = { param($input) $input -eq "CONFIRM" }
                    SubmitCallback = {
                        param($confirmText, $tempDataConfirm)
                        Execute-ProjectRemoval -Project $Project -AllProjects $AllProjects
                    }
                    CancelCallback = {
                        param($tempDataConfirm)
                        Write-AppLog "Project removal confirmation cancelled for active project '$($Project.ID2)'." "INFO"
                        Show-Warning "Removal cancelled."
                    }
                    InitialTempData = $tempDataInitial
                }
                Request-TextInput @confirmTextParams
            } else {
                # Directly execute for completed projects
                Execute-ProjectRemoval -Project $Project -AllProjects $AllProjects
            }
        }
        OnCancel = {
            param($tempDataInitial)
            Write-AppLog "Project removal cancelled by user for '$($Project.ID2)'." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Request-ConfirmAction @initialConfirmParams
}
function Execute-ProjectRemoval {
    param( [PSCustomObject]$Project, [array]$AllProjects )
    $updatedProjects = @($AllProjects | Where-Object { $_.ID2 -ne $Project.ID2 })
    Write-AppLog "Attempting to remove project '$($Project.ID2)' from JSON data." "INFO"

    if (Save-ProjectTodoJson -ProjectData $updatedProjects) {
        Show-Success "Project '$($Project.ID2)' removed successfully from JSON data."
        $script:Projects = $updatedProjects # Update in-memory list

        # Ask about removing time entries
        $timeConfirmParams = @{
            Prompt = "Also attempt to remove time tracking entries for ID2 '$($Project.ID2)' from CSV?"
            OnConfirm = {
                param($tempDataTime)
                Write-AppLog "Attempting to remove time
            } # End OnConfirm for time entry removal
            OnCancel = {
                param($tempDataTime)
                # Navigate back if on detail screen after action, even if time removal is cancelled
                $currentScreen = Get-CurrentScreen
                if ($currentScreen.Name -eq 'ProjectDetail') { $null = Navigate-Back }
            }
        } # End $timeConfirmParams hashtable
        Request-ConfirmAction @timeConfirmParams
    } else {
        Show-Error "Failed to save project list after removal. Project '$($Project.ID2)' might still be in the JSON file."
    }
}
function Open-ProjectFiles {
    param ([PSCustomObject]$ProjectContext = $null)
    $allProjects = Load-ProjectTodoJson
    if ($allProjects.Count -eq 0) {
        Show-Warning "No projects exist."
        return
    }
    $selectedProject = $null

    $SelectProjectCallback = {
        param($selProjWrapper, $tempDataSelect) # Parameter is the wrapper object from Select-ItemFromList
        if (-not $selProjWrapper) {
            Write-AppLog "Open Project Files cancelled at selection." "INFO"
            Show-Warning "Cancelled."
            return
        }
        # Extract the original project object from the wrapper
        $selectedProject = $selProjWrapper.OriginalProject
        if ($null -eq $selectedProject) {
             Write-AppLog "Open Project Files Error: OriginalProject not found in selected item wrapper." "ERROR"
             Show-Error "Internal error: Could not get project details from selection."
             return
        }
        Open-ProjectFiles_ActionMenu -Project $selectedProject
    }

    if ($ProjectContext -ne $null) {
        $found = $allProjects | Where-Object { $_.ID2 -eq $ProjectContext.ID2 } | Select-Object -First 1
        if ($found) {
            $selectedProject = $found
            Open-ProjectFiles_ActionMenu -Project $selectedProject
            return
        } else {
            # This is the block where the error was previously misplaced.
            # It should ONLY contain the error handling for the context not being found.
            Write-AppLog "Open-ProjectFiles context error: '$($ProjectContext.ID2)' not found." "WARN"
            Show-Error "Context project not found. Please select manually."
            $selectedProject = $null # Force selection below
        }
    }

    # If no context or context not found, prompt for selection
    if ($null -eq $selectedProject) {
        try {
            $sortedAllProjects = $allProjects | Sort-Object -Property @{ Expression = { try { [datetime]::ParseExact($_.AssignedDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { [datetime]::MinValue } } } -ErrorAction Stop
        } catch {
            Handle-Error $_ "Sorting projects for Open Files"
            Show-Warning "Could not sort projects."
            $sortedAllProjects = $allProjects
        }
        # Add OriginalProject wrapper for selection list
        # This wrapper is needed so the selection list displays correctly AND
        # the callback can retrieve the full original project object.
        $itemsForSelection = $sortedAllProjects | Select-Object @{N='Index';E={$script:i=0}{$script:i++;$script:i}}, ID2, FullName, @{N='Status'; E={if([string]::IsNullOrEmpty($_.CompletedDate)){"Active"}else{"Done $(Format-DateSafeDisplay $_.CompletedDate)"}}}, @{N='OriginalProject'; E={$_}}

        $selectParams = @{
            Title          = "OPEN FILES - SELECT PROJECT"
            Items          = $itemsForSelection
            ViewType       = "ProjectSelection"
            Prompt         = "Select project (0=Cancel)"
            OnItemSelected = $SelectProjectCallback # Use the defined callback
            OnCancel       = {
                param($tempDataCancel)
                Write-AppLog "Open Project Files cancelled at selection." "INFO"
                Show-Warning "Cancelled."
            }
        }
        Select-ItemFromList @selectParams
    }
}

function Open-ProjectFiles_ActionMenu {
    param([PSCustomObject]$Project)
    if ([string]::IsNullOrEmpty($Project.ProjFolder)) {
        Show-Error "No project folder path specified for '$($Project.ID2)'."
        return
    }
    if (-not (Test-Path $Project.ProjFolder -PathType Container)) {
        Show-Error "Project folder not found: $($Project.ProjFolder)"
        return
    }

    $casDocsFolder = Join-Path $Project.ProjFolder "__DOCS__\__CAS_DOCS__"
    $options = @{}
    $displayOptions = @()
    # Use a local variable for index to avoid potential script-scope conflicts
    $localIndex = 1

    # Option 1: Open Project Folder
    $options[$localIndex] = { Start-Process explorer.exe -ArgumentList $Project.ProjFolder }
    $displayOptions += @{ Index = $localIndex; DisplayValue = "Open Project Folder in Explorer" }
    $localIndex++

    # Helper to add file options (defined as a local scriptblock)
    $AddFileOption = {
        param($Label, $FileName, $FilePath)
        if (-not [string]::IsNullOrEmpty($FileName)) {
            if (Test-Path $FilePath -PathType Leaf) {
                $options[$localIndex] = { Start-Process $FilePath }
                $displayOptions += @{ Index = $localIndex; DisplayValue = "Open $Label ($FileName)" }
            } else {
                # File specified but not found - disable option
                $displayOptions += @{ Index = $localIndex; DisplayValue = "$Label file not found ($FileName) [Disabled]" }
            }
        } else {
            # No file specified in project data - disable option
            # --- CORRECTED LINE using -f operator ---
            $displayOptions += @{ Index = $localIndex; DisplayValue = "({0} file not set in project data) [Disabled]" -f $Label }
        }
        $localIndex++ # Increment the local index
    }

    # Add specific file options if CAS_DOCS exists
    if (Test-Path $casDocsFolder -PathType Container) {
        # Use Invoke-Command (&) to execute the local scriptblock helper
        & $AddFileOption "CAA" $Project.CAAName (Join-Path $casDocsFolder $Project.CAAName)
        & $AddFileOption "Request" $Project.RequestName (Join-Path $casDocsFolder $Project.RequestName)
        & $AddFileOption "T2020" $Project.T2020 (Join-Path $casDocsFolder $Project.T2020)
    } else {
        Show-Warning "Standard subfolder '__DOCS__\__CAS_DOCS__' not found. Cannot list specific files."
    }

    # No need to remove $localIndex as it's local to the function call

    $selectParams = @{
        Title = "OPEN FILES FOR: $($Project.ID2)"
        Items = $displayOptions
        ViewType = "SelectionList"
        Prompt = "Select action (0=Cancel)"
        OnItemSelected = {
            param($selectedDisplayItem, $tempDataSelect)
            $choice = $selectedDisplayItem.Index
            if ($options.ContainsKey($choice)) {
                try {
                    Write-AppLog "Executing file open action: $($selectedDisplayItem.DisplayValue)" "INFO"
                    & $options[$choice] # Execute the stored scriptblock
                    Show-Info "Attempted to open: $($selectedDisplayItem.DisplayValue)"
                } catch {
                    Handle-Error $_ "Executing file open action '$($selectedDisplayItem.DisplayValue)'"
                }
            } else {
                Show-Warning "This option is disabled or invalid."
            }
        }
        OnCancel = {
            param($tempDataCancel)
            Write-AppLog "Open files action cancelled." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Select-ItemFromList @selectParams
}
function Open-ProjectFiles_ActionMenu {
    param([PSCustomObject]$Project)
    if ([string]::IsNullOrEmpty($Project.ProjFolder)) {
        Show-Error "No project folder path specified for '$($Project.ID2)'."
        return
    }
    if (-not (Test-Path $Project.ProjFolder -PathType Container)) {
        Show-Error "Project folder not found: $($Project.ProjFolder)"
        return
    }

    $casDocsFolder = Join-Path $Project.ProjFolder "__DOCS__\__CAS_DOCS__"
    $options = @{}
    $displayOptions = @()
    # Use a local variable for index to avoid potential script-scope conflicts if function is called rapidly/re-entrantly
    $localIndex = 1

    # Option 1: Open Project Folder
    $options[$localIndex] = { Start-Process explorer.exe -ArgumentList $Project.ProjFolder }
    $displayOptions += @{ Index = $localIndex; DisplayValue = "Open Project Folder in Explorer" }
    $localIndex++

    # Helper to add file options (defined as a local scriptblock)
  $AddFileOption = {
        param($Label, $FileName, $FilePath)

        # --- DEBUGGING LINE - Remove after testing if needed ---
        Write-Host "DEBUG: AddFileOption called with Label='$Label', FileName='$FileName'"

        if (-not [string]::IsNullOrEmpty($FileName)) {
            if (Test-Path $FilePath -PathType Leaf) {
                $options[$localIndex] = { Start-Process $FilePath }
                $displayOptions += @{ Index = $localIndex; DisplayValue = "Open $Label ($FileName)" }
            } else {
                # File specified but not found - disable option
                $displayValueString = "$Label file not found ($FileName) [Disabled]"
                $displayOptions += @{ Index = $localIndex; DisplayValue = $displayValueString }
            }
        } else {
            # No file specified in project data - disable option
            # --- ALTERNATIVE FIX 2: Explicit String Concatenation ---
            $theLabelValue = $Label # Ensure we have the value
            if ($null -eq $theLabelValue) { $theLabelValue = "Item" } # Basic fallback if label is null
            $displayValueString = "(" + $theLabelValue + " file not set in project data) [Disabled]"
            $displayOptions += @{ Index = $localIndex; DisplayValue = $displayValueString }
        }
        $localIndex++ # Increment the local index
    }

    # Add specific file options if CAS_DOCS exists
    if (Test-Path $casDocsFolder -PathType Container) {
        # Use Invoke-Command (&) to execute the local scriptblock helper
        & $AddFileOption "CAA" $Project.CAAName (Join-Path $casDocsFolder $Project.CAAName)
        & $AddFileOption "Request" $Project.RequestName (Join-Path $casDocsFolder $Project.RequestName)
        & $AddFileOption "T2020" $Project.T2020 (Join-Path $casDocsFolder $Project.T2020)
    } else {
        Show-Warning "Standard subfolder '__DOCS__\__CAS_DOCS__' not found. Cannot list specific files."
    }

    # No need to remove $localIndex as it's local to the function call

    $selectParams = @{
        Title = "OPEN FILES FOR: $($Project.ID2)"
        Items = $displayOptions
        ViewType = "SelectionList"
        Prompt = "Select action (0=Cancel)"
        OnItemSelected = {
            param($selectedDisplayItem, $tempDataSelect)
            $choice = $selectedDisplayItem.Index
            if ($options.ContainsKey($choice)) {
                try {
                    Write-AppLog "Executing file open action: $($selectedDisplayItem.DisplayValue)" "INFO"
                    & $options[$choice] # Execute the stored scriptblock
                    Show-Info "Attempted to open: $($selectedDisplayItem.DisplayValue)"
                } catch {
                    Handle-Error $_ "Executing file open action '$($selectedDisplayItem.DisplayValue)'"
                }
            } else {
                Show-Warning "This option is disabled or invalid."
            }
        }
        OnCancel = {
            param($tempDataCancel)
            Write-AppLog "Open files action cancelled." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Select-ItemFromList @selectParams
}
#endregion

#region Time Tracking Functions
function Add-TimeEntryCore {
    param (
        [string]$ID2,
        [double]$Hours,
        [string]$DateInternal,
        [string]$Description = ""
    )
    if ($Hours -lt 0) {
        Show-Error "Hours worked cannot be negative."
        return $false
    }
    if (-not ($DateInternal -match '^\d{8}$')) {
        Show-Error "Invalid internal date format '$DateInternal'. Expected YYYYMMDD."
        return $false
    }
    try {
        [void][datetime]::ParseExact($DateInternal, $global:DATE_FORMAT_INTERNAL, $null)
    } catch {
        Handle-Error $_ "Parsing internal date '$DateInternal' for time entry"
        return $false
    }

    $timeEntries = Get-CsvDataSafely -FilePath $Global:AppConfig.timeTrackingFile
    if ($null -eq $timeEntries) {
        Show-Error "Failed to read time tracking file."
        return $false
    }

    $isCustomTask = $ID2 -match '\s' -or $ID2.Length -gt 20
    $entryDescription = if ($isCustomTask) { "" } else { $Description }
    $entryID2 = $ID2
    Write-AppLog "Adding time entry: $Hours hrs for '$entryID2' on $DateInternal" "INFO"

    $newEntry = [PSCustomObject]@{
        Date = $DateInternal
        ID2 = $entryID2
        Hours = $Hours.ToString("0.0")
        Description = $entryDescription
        TimeEntryID = [guid]::NewGuid().ToString()
    }

    $timeEntries = @($timeEntries) + $newEntry
    try {
        $timeEntries = @($timeEntries | Sort-Object Date, ID2 -ErrorAction Stop)
    } catch {
        Handle-Error $_ "Sorting time entries before save"
    }

    if (-not (Set-CsvData -FilePath $Global:AppConfig.timeTrackingFile -Data $timeEntries)) {
        Show-Error "Failed to save time tracking data."
        return $false
    }

    Show-Success "Time entry ($($Hours.ToString('F1')) hours) added for '$entryID2' on $(Format-DateSafeDisplay $DateInternal)."
    return $true
}
function Add-ProjectTimeInteractive {
    param ([PSCustomObject]$ProjectContext = $null)
    $projectID2 = $null
    $projectName = ""

    $SelectProjectCallback = {
        param($selectedProjectWrapper, $tempDataSelect)
        if (-not $selectedProjectWrapper) {
            Write-AppLog "Log project time cancelled at selection." "INFO"
            Show-Warning "Cancelled."
            return
        }
        $selectedProject = $selectedProjectWrapper.OriginalProject # Get original object
        $projectID2 = $selectedProject.ID2
        $projectName = $selectedProject.FullName
        Start-ProjectTimeLogSequence -ProjectID2 $projectID2 -ProjectName $projectName
    }

    if ($ProjectContext -ne $null) {
        $projectID2 = $ProjectContext.ID2
        $projectName = $ProjectContext.FullName
        Write-AppLog "Add-ProjectTimeInteractive called with context: '$projectID2'" "INFO"
        Start-ProjectTimeLogSequence -ProjectID2 $projectID2 -ProjectName $projectName
        return
    }

    $allProjects = Load-ProjectTodoJson
    if ($allProjects.Count -eq 0) {
        Show-Warning "No projects exist to log time against."
        return
    }
    $activeProjects = @($allProjects | Where-Object { [string]::IsNullOrEmpty($_.CompletedDate) })
    if ($activeProjects.Count -eq 0) {
        Show-Warning "No active projects available to log time against."
        return
    }
    try {
        $sortedActiveProjects = $activeProjects | Sort-Object -Property @{ Expression = { try { [datetime]::ParseExact($_.AssignedDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { [datetime]::MinValue } } } -ErrorAction Stop
    } catch {
        Handle-Error $_ "Sorting projects for time log"
        Show-Warning "Could not sort projects."
        $sortedActiveProjects = $activeProjects
    }
    # Add OriginalProject wrapper for selection list
    $itemsForSelection = $sortedActiveProjects | Select-Object *, @{N='OriginalProject'; E={$_}}
    $selectParams = @{
        Title = "LOG PROJECT TIME - SELECT PROJECT"
        Items = $itemsForSelection
        ViewType = "ProjectSelection"
        Prompt = "Select project (0=Cancel)"
        OnItemSelected = $SelectProjectCallback
        OnCancel = {
            param($tempDataCancel)
            Write-AppLog "Log project time cancelled at selection." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Select-ItemFromList @selectParams
}
function Start-ProjectTimeLogSequence {
    param($ProjectID2, $ProjectName)
    Show-Info "Logging time for Project: $ProjectID2 ($ProjectName)"
    $initialTempData = @{ ID2 = $ProjectID2 }
    $defaultDateInternal = (Get-Date).ToString($global:DATE_FORMAT_INTERNAL)
    $requestParams = @{
        Prompt = "Date (YYYYMMDD or common format)"
        DefaultValue = $defaultDateInternal
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($input)
            $parsedDateInternal = Parse-DateSafeInternal $input
            return -not ([string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($dateInput, $tempData)
            $tempData.DateInternal = Parse-DateSafeInternal $dateInput
            Write-AppLog "Add-ProjectTime: Got Date: $($tempData.DateInternal)" "DEBUG"
            Start-ProjectTimeLogSequence_Hours -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Add-ProjectTime cancelled at Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Start-ProjectTimeLogSequence_Hours {
    param($tempData)
    $requestParams = @{
        Prompt = "Hours worked (e.g., 7.5, 0.5)"
        ValidationErrorMessage = "Invalid hours entered. Must be a positive number."
        ValidationCallback = {
            param($hoursInput)
            $hours = 0.0
            if (-not ([double]::TryParse($hoursInput, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$hours)) -or $hours -lt 0) { return $false }
            return $true
        }
        SubmitCallback = {
            param($hoursInput, $tempDataSubmit)
            [double]::TryParse($hoursInput, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$tempDataSubmit.Hours) | Out-Null
            Write-AppLog "Add-ProjectTime: Got Hours: $($tempDataSubmit.Hours)" "DEBUG"
            Start-ProjectTimeLogSequence_Desc -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ProjectTime cancelled at Hours." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Start-ProjectTimeLogSequence_Desc {
    param($tempData)
    $requestParams = @{
        Prompt = "Description (optional)"
        SubmitCallback = {
            param($description, $tempDataSubmit)
            $tempDataSubmit.Description = $description
            Write-AppLog "Add-ProjectTime: Got Description: $description" "DEBUG"
            Add-TimeEntryCore -ID2 $tempDataSubmit.ID2 -Hours $tempDataSubmit.Hours -DateInternal $tempDataSubmit.DateInternal -Description $tempDataSubmit.Description
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-ProjectTime cancelled at Description." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-NonProjectTimeInteractive {
    Show-Info "Enter details for non-project time (e.g., Admin, Meeting)."
    $initialTempData = @{}
    $requestParams = @{
        Prompt = "Task description (Required)"
        ValidationErrorMessage = "Description is required."
        ValidationCallback = { param($desc) -not [string]::IsNullOrWhiteSpace($desc) }
        SubmitCallback = {
            param($description, $tempData)
            $tempData.Description = $description
            Write-AppLog "Add-NonProjectTime: Got Description: $description" "DEBUG"
            Add-NonProjectTime_Hours -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Add-NonProjectTime cancelled at Description." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Add-NonProjectTime_Hours {
    param($tempData)
    $requestParams = @{
        Prompt = "Hours worked (e.g., 1.0, 2.25)"
        ValidationErrorMessage = "Invalid hours entered. Must be a positive number."
        ValidationCallback = {
            param($hoursInput)
            $hours = 0.0
            # Use TryParse with specific culture for decimal separator robustness
            if (-not ([double]::TryParse($hoursInput, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$hours)) -or $hours -lt 0) { return $false }
            return $true
        }
        SubmitCallback = {
            param($hoursInput, $tempDataSubmit)
            [double]::TryParse($hoursInput, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$tempDataSubmit.Hours) | Out-Null
            Write-AppLog "Add-NonProjectTime: Got Hours: $($tempDataSubmit.Hours)" "DEBUG"
            Add-NonProjectTime_Date -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-NonProjectTime cancelled at Hours." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-NonProjectTime_Date {
    param($tempData)
    $defaultDateInternal = (Get-Date).ToString($global:DATE_FORMAT_INTERNAL)
    $requestParams = @{
        Prompt = "Date (YYYYMMDD or common format)"
        DefaultValue = $defaultDateInternal
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($input)
            $parsedDateInternal = Parse-DateSafeInternal $input
            return -not ([string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($dateInput, $tempDataSubmit)
            $tempDataSubmit.DateInternal = Parse-DateSafeInternal $dateInput
            Write-AppLog "Add-NonProjectTime: Got Date: $($tempDataSubmit.DateInternal)" "DEBUG"
            Add-TimeEntryCore -ID2 $tempDataSubmit.Description -Hours $tempDataSubmit.Hours -DateInternal $tempDataSubmit.DateInternal -Description ""
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-NonProjectTime cancelled at Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Get-TimeSheet {
    Show-Info "Select week start date for timesheet summary."
    $initialTempData = @{}
    $defaultStartDateInternal = (Get-Date).Date
    while ($defaultStartDateInternal.DayOfWeek -ne [System.DayOfWeek]::Monday) {
        $defaultStartDateInternal = $defaultStartDateInternal.AddDays(-1)
    }
    $defaultStartDateStringInternal = $defaultStartDateInternal.ToString($global:DATE_FORMAT_INTERNAL)
    $requestParams = @{
        Prompt = "Enter start date (YYYYMMDD or common format) for week"
        DefaultValue = $defaultStartDateStringInternal
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid start date format entered."
        ValidationCallback = {
            param($input)
            $parsedDateInternal = Parse-DateSafeInternal $input
            return -not ([string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($startDateInput, $tempData)
            $startDateInternal = Parse-DateSafeInternal $startDateInput
            try {
                $startDate = [datetime]::ParseExact($startDateInternal, $global:DATE_FORMAT_INTERNAL, $null)
            } catch {
                Handle-Error $_ "Parsing start date for timesheet"
                return
            }
            # Ensure it's Monday
            while ($startDate.DayOfWeek -ne [System.DayOfWeek]::Monday) {
                $startDate = $startDate.AddDays(-1)
            }
            $endDate = $startDate.AddDays(6) # Mon-Sun for display
            $weekStartDateStr = $startDate.ToString($global:AppConfig.displayDateFormat ?? $global:DATE_FORMAT_DISPLAY_FALLBACK)
            Show-Info "Displaying time entries for week starting: $weekStartDateStr (Mon-Sun)"

            $allTimeEntries = Get-CsvDataSafely -FilePath $Global:AppConfig.timeTrackingFile
            if ($null -eq $allTimeEntries) {
                Show-Warning "No time entries found or file could not be read."
                return
            }

            $processedEntriesForWeek = @()
            $totalHours = 0.0
            foreach ($entry in $allTimeEntries) {
                $entryDate = $null
                $hoursValue = 0.0
                if (-not $entry.PSObject.Properties.Name.Contains('Date') -or $entry.Date -notmatch '^\d{8}$') { continue }
                if (-not $entry.PSObject.Properties.Name.Contains('Hours') -or -not ([double]::TryParse($entry.Hours, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$hoursValue))) { continue }
                try {
                    $entryDate = [datetime]::ParseExact($entry.Date, $global:DATE_FORMAT_INTERNAL, $null).Date
                } catch { continue }

                if ($entryDate.Date -ge $startDate.Date -and $entryDate.Date -le $endDate.Date) {
                    $descriptionForEntry = if ($entry.PSObject.Properties.Name.Contains('Description')) {$entry.Description} else {""}
                    $processedEntriesForWeek += [PSCustomObject]@{
                        ParsedDate = $entryDate
                        DisplayDate = Format-DateSafeDisplay $entry.Date
                        ID2 = $entry.ID2
                        HoursValue = $hoursValue
                        Description = $descriptionForEntry
                    }
                    $totalHours += $hoursValue
                }
            }

            if ($processedEntriesForWeek.Count -eq 0) {
                Show-Warning "No time entries found for this specific week."
                return
            }

            $tableData = $processedEntriesForWeek | Sort-Object ParsedDate, ID2 | Select-Object DisplayDate, ID2, @{N='HoursValue';E={$_.HoursValue.ToString("F1")}}, Description
            # Add total row
            $tableData += [PSCustomObject]@{DisplayDate=""; ID2="WEEKLY TOTAL:"; HoursValue=$totalHours.ToString("F1"); Description=""}
            $rowColors = @{ ($tableData.Count - 1) = "Selected" } # Highlight total row

            $script:SelectionScreenTitle = "TIME SHEET: Week of $weekStartDateStr"
            $script:SelectionScreenItems = $tableData
            $script:SelectionScreenViewType = "TimeSheet"
            $script:SelectionScreenRowColors = $rowColors
            Set-CurrentScreen -ScreenDefinition $DisplayListScreen
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Get-TimeSheet cancelled at date selection." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Create-FormattedTimesheet {
    Show-Info "Select week start date for formatted timesheet export."
    $initialTempData = @{}
    $defaultStartDateInternal = (Get-Date).Date
    while ($defaultStartDateInternal.DayOfWeek -ne [System.DayOfWeek]::Monday) {
        $defaultStartDateInternal = $defaultStartDateInternal.AddDays(-1)
    }
    $defaultStartDateStringInternal = $defaultStartDateInternal.ToString($global:DATE_FORMAT_INTERNAL)
    $requestParams = @{
        Prompt = "Enter start date (YYYYMMDD or common format) for week"
        DefaultValue = $defaultStartDateStringInternal
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid start date format entered."
        ValidationCallback = {
            param($input)
            $parsedDateInternal = Parse-DateSafeInternal $input
            return -not ([string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($startDateInput, $tempData)
            $startDateInternal = Parse-DateSafeInternal $startDateInput
            try {
                $startDate = [datetime]::ParseExact($startDateInternal, $global:DATE_FORMAT_INTERNAL, $null)
            } catch {
                Handle-Error $_ "Parsing start date for timesheet creation"
                return
            }
            # Ensure it's Monday
            while ($startDate.DayOfWeek -ne [System.DayOfWeek]::Monday) {
                $startDate = $startDate.AddDays(-1)
            }
            $endDate = $startDate.AddDays(4) # Mon-Fri for export
            $weekStartDateStr = $startDate.ToString($global:AppConfig.displayDateFormat ?? $global:DATE_FORMAT_DISPLAY_FALLBACK)
            Show-Info "Generating timesheet for week: $weekStartDateStr (Mon-Fri)"

            $allTimeEntries = Get-CsvDataSafely -FilePath $Global:AppConfig.timeTrackingFile
            $allProjects = Load-ProjectTodoJson
            if ($null -eq $allTimeEntries) {
                Show-Error "Failed to load time entries. Cannot create timesheet."
                return
            }

            $projectIDLookup = @{}
            foreach ($proj in $allProjects) {
                if (-not $projectIDLookup.ContainsKey($proj.ID2)) {
                    $projectIDLookup[$proj.ID2] = $proj.ID1
                }
            }

            $processedEntries = @{}
            $validEntryFound = $false
            $skippedCount = 0
            foreach ($entry in $allTimeEntries) {
                $entryDate = $null
                $hoursValue = 0.0
                $props = $entry.PSObject.Properties.Name
                if (-not ($props -contains 'Date') -or $entry.Date -notmatch '^\d{8}$') { $skippedCount++; continue }
                if (-not ($props -contains 'Hours') -or -not ([double]::TryParse($entry.Hours, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$hoursValue))) { $skippedCount++; continue }
                try {
                    $entryDate = [datetime]::ParseExact($entry.Date, $global:DATE_FORMAT_INTERNAL, $null).Date
                } catch { $skippedCount++; continue }

                if ($entryDate.Date -ge $startDate.Date -and $entryDate.Date -le $endDate.Date) {
                    $validEntryFound = $true
                    $id2Key = $entry.ID2
                    $dayOfWeekShort = $entryDate.DayOfWeek.ToString().Substring(0,3)
                    if (-not $processedEntries.ContainsKey($id2Key)) {
                        $id1Value = if ($projectIDLookup.ContainsKey($id2Key)) { $projectIDLookup[$id2Key] } else { "" }
                        $processedEntries[$id2Key] = @{ ID1 = $id1Value; Mon=0.0; Tue=0.0; Wed=0.0; Thu=0.0; Fri=0.0 }
                    }
                    if ($processedEntries[$id2Key].ContainsKey($dayOfWeekShort)) {
                        $processedEntries[$id2Key][$dayOfWeekShort] += $hoursValue
                    }
                }
            }

            if ($skippedCount -gt 0) { Show-Warning "$skippedCount time entries skipped due to format errors (see log)." }
            if (-not $validEntryFound) {
                Show-Warning "No valid time entries found for the specified week (Mon-Fri)."
                return
            }

            $outputDataForCsv = @()
            foreach ($id2Key in $processedEntries.Keys | Sort-Object) {
                $entryData = $processedEntries[$id2Key]
                $outputDataForCsv += [PSCustomObject]@{
                    ID1 = $entryData.ID1
                    ID2 = $id2Key
                    _Empty1 = ""
                    _Empty2 = ""
                    _Empty3 = ""
                    _Empty4 = ""
                    Mon = $entryData.Mon.ToString("0.0")
                    Tue = $entryData.Tue.ToString("0.0")
                    Wed = $entryData.Wed.ToString("0.0")
                    Thu = $entryData.Thu.ToString("0.0")
                    Fri = $entryData.Fri.ToString("0.0")
                }
            }

            $tempCsvPath = $Global:AppConfig.tempTimesheetCsvPath
            if ([string]::IsNullOrWhiteSpace($tempCsvPath)) {
                $tempCsvPath = Join-Path $scriptRoot "_temp_timesheet.csv"
                Write-AppLog "Temp timesheet path not in config, using default: $tempCsvPath" "DEBUG"
            }

            try {
                $headerString = "ID1,ID2,,,,Mon,Tue,Wed,Thu,Fri"
                $headerString | Out-File -FilePath $tempCsvPath -Encoding UTF8 -Force -EA Stop
                $outputDataForCsv | ConvertTo-Csv -NoTypeInformation -UseQuotes AsNeeded | Select-Object -Skip 1 | Out-File -FilePath $tempCsvPath -Encoding UTF8 -Append -EA Stop
                Write-AppLog "Created formatted timesheet CSV: $tempCsvPath" "INFO"
                Show-Info "Temporary timesheet CSV created at: $tempCsvPath"
                try {
                    Get-Content -Path $tempCsvPath -Raw -Encoding UTF8 | Set-Clipboard -EA Stop
                    Show-Success "Formatted timesheet content copied to clipboard!"
                } catch {
                    Handle-Error $_ "Copying timesheet CSV content to clipboard"
                }
            } catch {
                Handle-Error $_ "Creating or writing formatted timesheet CSV '$tempCsvPath'"
            }
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Create-FormattedTimesheet cancelled at date selection." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
#endregion

#region Todo Helper Functions
function Add-TodoItemToProject {
    param([Parameter(Mandatory=$true)][PSCustomObject]$ProjectObject)
    Show-Info "Adding new Todo to Project: $($ProjectObject.ID2)"
    $initialTempData = @{ Project = $ProjectObject }
    $requestParams = @{
        Prompt = "Task description (Required)"
        ValidationErrorMessage = "Task description cannot be empty."
        ValidationCallback = { param($task) -not [string]::IsNullOrWhiteSpace($task) }
        SubmitCallback = {
            param($Task, $tempData)
            $tempData.Task = $Task
            Write-AppLog "Add-Todo: Got Task: $Task" "DEBUG"
            Add-TodoItem_DueDate -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Add-Todo cancelled at Task." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Add-TodoItem_DueDate {
    param($tempData)
    $requestParams = @{
        Prompt = "Due date (YYYYMMDD or common format) or Enter for none"
        ValidationErrorMessage = "Invalid due date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($input)
            if ([string]::IsNullOrWhiteSpace($input)) { return $true } # Allow empty
            $parsedDateInternal = Parse-DateSafeInternal $input
            return (-not [string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($dueDateInput, $tempDataSubmit)
            $tempDataSubmit.DueDate = Parse-DateSafeInternal $dueDateInput
            Write-AppLog "Add-Todo: Got DueDate: $($tempDataSubmit.DueDate)" "DEBUG"
            Add-TodoItem_Priority -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-Todo cancelled at Due Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-TodoItem_Priority {
    param($tempData)
    $requestParams = @{
        Prompt = "Priority"
        MinValue = 1
        MaxValue = 3
        ExtraPromptInfo = "(1=High, 2=Normal, 3=Low, 0=Cancel)"
        SubmitCallback = {
            param($priorityChoice, $tempDataSubmit)
            $priorityText = switch ($priorityChoice) {
                1 {"High"}
                2 {"Normal"}
                3 {"Low"}
                default {"Normal"}
            }
            $tempDataSubmit.Priority = $priorityText
            Write-AppLog "Add-Todo: Got Priority: $priorityText" "DEBUG"
            Add-TodoItem_Save -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Add-Todo cancelled at Priority." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-NumericChoice @requestParams
}
function Add-TodoItem_Save {
    param($tempData)
    $proj = $tempData.Project
    $newTask = $tempData.Task
    $newDueDate = $tempData.DueDate
    $newPriority = $tempData.Priority

    $newTodo = [PSCustomObject]@{
        TodoID = [guid]::NewGuid().ToString()
        Task = $newTask
        DueDate = $newDueDate
        Priority = $newPriority
        Status = "Pending"
        CreatedDate = (Get-Date).ToString($global:DATE_FORMAT_INTERNAL)
        CompletedDate = ""
    }

    try {
        if (-not $proj.PSObject.Properties.Name.Contains('Todos') -or $proj.Todos -eq $null) {
            $proj | Add-Member -MemberType NoteProperty -Name 'Todos' -Value @() -Force
        } elseif ($proj.Todos -isnot [array]) {
            $proj.Todos = @($proj.Todos)
        }
        $proj.Todos += $newTodo
        Write-AppLog "Added Todo '$newTask' to project '$($proj.ID2)' (in memory)." "INFO"
        if(Save-ProjectTodoJson -ProjectData $script:Projects){
            Show-Success "Todo '$newTask' added and project saved."
        } else{
            Show-Error "Todo added in memory, but FAILED TO SAVE project."
        }
        $script:RefreshDetailScreen = $true
    } catch {
        Handle-Error $_ "Adding new Todo object to project's Todos array"
    }
}
function Update-TodoInProject {
    param(
        [Parameter(Mandatory=$true)][PSCustomObject]$ProjectObject,
        [Parameter(Mandatory=$true)][PSCustomObject]$TodoObject
    )
    Show-Info "Editing Todo for Project: $($ProjectObject.ID2). Press Enter to keep current value, Esc to cancel."
    $initialTempData = @{
        Project = $ProjectObject
        Todo = $TodoObject
        OriginalTodo = $TodoObject.PSObject.Copy()
        Changed = $false
    }
    $requestParams = @{
        Prompt = "Task description"
        DefaultValue = $TodoObject.Task
        ValidationErrorMessage = "Task cannot be empty."
        ValidationCallback = { param($task) -not [string]::IsNullOrWhiteSpace($task) }
        SubmitCallback = {
            param($newTask, $tempData)
            if ($tempData.Todo.Task -ne $newTask) {
                $tempData.Todo.Task = $newTask
                $tempData.Changed = $true
            }
            Write-AppLog "Update-Todo: Got Task: $newTask" "DEBUG"
            Update-Todo_DueDate -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Update-Todo cancelled at Task." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Update-Todo_DueDate {
    param($tempData)
    $requestParams = @{
        Prompt = "Due date (YYYYMMDD or common format) or '-' to clear"
        DefaultValue = $tempData.Todo.DueDate
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid due date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($input)
            if ($input -eq '-') { return $true }
            if ([string]::IsNullOrWhiteSpace($input)) { return $true }
            $parsedDateInternal = Parse-DateSafeInternal $input
            return (-not [string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($dueDateInput, $tempDataSubmit)
            $newDueDateInternal = ""
            if ($dueDateInput -eq '-') {
                $newDueDateInternal = ""
            } else {
                $newDueDateInternal = Parse-DateSafeInternal $dueDateInput
            }
            if ($tempDataSubmit.Todo.DueDate -ne $newDueDateInternal) {
                $tempDataSubmit.Todo.DueDate = $newDueDateInternal
                $tempDataSubmit.Changed = $true
            }
            Write-AppLog "Update-Todo: Got DueDate: $newDueDateInternal" "DEBUG"
            Update-Todo_Priority -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Update-Todo cancelled at Due Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Update-Todo_Priority {
    param($tempData)
    $priorityMapReverse = @{ "High"=1; "Normal"=2; "Low"=3 }
    $currentPriorityValue = if ($priorityMapReverse.ContainsKey($tempData.Todo.Priority)) { $priorityMapReverse[$tempData.Todo.Priority] } else { 2 }
    $requestParams = @{
        Prompt = "Priority (Current: $($tempData.Todo.Priority) [$currentPriorityValue])"
        MinValue = 1
        MaxValue = 3
        ExtraPromptInfo = "(1=H, 2=N, 3=L, 0=Cancel)"
        SubmitCallback = {
            param($priorityChoice, $tempDataSubmit)
            $newPriorityText = switch ($priorityChoice) {
                1 {"High"}
                2 {"Normal"}
                3 {"Low"}
            }
            if ($tempDataSubmit.Todo.Priority -ne $newPriorityText) {
                $tempDataSubmit.Todo.Priority = $newPriorityText
                $tempDataSubmit.Changed = $true
            }
            Write-AppLog "Update-Todo: Got Priority: $newPriorityText" "DEBUG"
            Update-Todo_Status -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Update-Todo cancelled at Priority." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-NumericChoice @requestParams
}
function Update-Todo_Status {
    param($tempData)
    $statusMapReverse = @{ "Pending"=1; "Completed"=2 }
    $currentStatusValue = if ($statusMapReverse.ContainsKey($tempData.Todo.Status)) { $statusMapReverse[$tempData.Todo.Status] } else { 1 }
    $requestParams = @{
        Prompt = "Status (Current: $($tempData.Todo.Status) [$currentStatusValue])"
        MinValue = 1
        MaxValue = 2
        ExtraPromptInfo = "(1=Pending, 2=Completed, 0=Cancel)"
        SubmitCallback = {
            param($statusChoice, $tempDataSubmit)
            $newStatus = switch ($statusChoice) {
                1 {"Pending"}
                2 {"Completed"}
            }
            if ($tempDataSubmit.Todo.Status -ne $newStatus) {
                $tempDataSubmit.Todo.Status = $newStatus
                if ($newStatus -eq "Completed") {
                    $tempDataSubmit.Todo.CompletedDate = (Get-Date).ToString($global:DATE_FORMAT_INTERNAL)
                } else {
                    $tempDataSubmit.Todo.CompletedDate = ""
                }
                $tempDataSubmit.Changed = $true
            }
            Write-AppLog "Update-Todo: Got Status: $newStatus" "DEBUG"
            Update-Todo_Save -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Update-Todo cancelled at Status." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-NumericChoice @requestParams
}
function Update-Todo_Save {
    param($tempData)
    if ($tempData.Changed) {
        Write-AppLog "Updated Todo '$($tempData.Todo.TodoID)' for project '$($tempData.Project.ID2)' (in memory)." "INFO"
        if(Save-ProjectTodoJson -ProjectData $script:Projects){
            Show-Success "Todo updated and project saved."
        } else{
            Show-Error "Todo updated in memory, but FAILED TO SAVE project."
        }
        $script:RefreshDetailScreen = $true
    } else {
        Show-Info "No changes were made to the Todo."
    }
}
function Remove-TodoFromProject {
    param(
        [Parameter(Mandatory=$true)][PSCustomObject]$ProjectObject,
        [Parameter(Mandatory=$true)][PSCustomObject]$TodoObjectToRemove
    )
    Show-Warning "This will remove the Todo item '$($TodoObjectToRemove.Task)' from Project: $($ProjectObject.ID2)"
    $confirmParams = @{
        Prompt = "Confirm removal of this Todo?"
        OnConfirm = {
            param($tempData)
            try {
                if ($null -eq $ProjectObject.Todos -or $ProjectObject.Todos -isnot [array]) {
                    Write-AppLog "Cannot remove Todo '$($TodoObjectToRemove.TodoID)', Todos array is missing or invalid on project '$($ProjectObject.ID2)'." "ERROR"
                    Show-Error "Cannot remove Todo - project data seems inconsistent."
                    return
                }
                $originalCount = $ProjectObject.Todos.Count
                $updatedTodos = @($ProjectObject.Todos | Where-Object { $_.TodoID -ne $TodoObjectToRemove.TodoID })
                if ($updatedTodos.Count -lt $originalCount) {
                    $ProjectObject.Todos = $updatedTodos
                    Write-AppLog "Removed Todo '$($TodoObjectToRemove.TodoID)' from project '$($ProjectObject.ID2)' (in memory)." "INFO"
                    if(Save-ProjectTodoJson -ProjectData $script:Projects){
                        Show-Success "Todo removed and project saved."
                    } else{
                        Show-Error "Todo removed in memory, but FAILED TO SAVE project."
                    }
                    $script:RefreshDetailScreen = $true
                } else {
                    Write-AppLog "Todo '$($TodoObjectToRemove.TodoID)' not found in project '$($ProjectObject.ID2)' Todos array during removal attempt." "WARN"
                    Show-Warning "Todo item was not found in the project's list. No changes made."
                }
            } catch {
                Handle-Error $_ "Removing Todo object from project's Todos array"
            }
        }
        OnCancel = {
            param($tempData)
            Write-AppLog "Remove Todo cancelled by user for '$($TodoObjectToRemove.TodoID)'." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Request-ConfirmAction @confirmParams
}
#endregion

#region Schedule View Function
function Show-ScheduleView {
    Show-Info "Loading schedule data..."
    $today = (Get-Date).Date
    $currentWeekStart = $today
    while ($currentWeekStart.DayOfWeek -ne [System.DayOfWeek]::Monday) { $currentWeekStart = $currentWeekStart.AddDays(-1) }
    $currentWeekEnd = $currentWeekStart.AddDays(4) # Mon-Fri
    $nextWeekStart = $currentWeekStart.AddDays(7)
    $nextWeekEnd = $nextWeekStart.AddDays(4) # Mon-Fri

    $allProjects = Load-ProjectTodoJson
    if ($allProjects.Count -eq 0) {
        Show-Warning "No projects found."
        return
    }

    $upcomingTodos = @()
    foreach ($project in $allProjects) {
        if ($null -eq $project.Todos -or $project.Todos -isnot [array] -or $project.Todos.Count -eq 0) { continue }
        foreach ($item in $project.Todos) {
            if ($item.Status -ne "Pending" -or [string]::IsNullOrEmpty($item.DueDate)) { continue }
            $dueDate = $null
            if ($item.DueDate -notmatch '^\d{8}$') { continue }
            try { $dueDate = [datetime]::ParseExact($item.DueDate, $global:DATE_FORMAT_INTERNAL, $null).Date } catch { continue }

            if (($dueDate -ge $currentWeekStart -and $dueDate -le $currentWeekEnd) -or ($dueDate -ge $nextWeekStart -and $dueDate -le $nextWeekEnd)) {
                try {
                    $priorityValue = switch($item.Priority){'High'{1}'Normal'{2}'Low'{3}default{4}}
                    $processedTodo = [PSCustomObject]@{
                        TodoID=$item.TodoID
                        Task=$item.Task
                        DueDate=$item.DueDate
                        Priority=$item.Priority
                        Status=$item.Status
                        CreatedDate=$item.CreatedDate
                        CompletedDate=$item.CompletedDate
                        ProjectID2=$project.ID2
                        ParsedDueDate=$dueDate
                        PriorityValue=$priorityValue
                        IsNextWeek=($dueDate -ge $nextWeekStart)
                        OriginalTodo = $item
                    }
                    $upcomingTodos += $processedTodo
                } catch {
                    Handle-Error $_ "Creating processed Todo object for schedule view (Project: $($project.ID2), Todo: $($item.Task))"
                }
            }
        }
    }

    if ($upcomingTodos.Count -eq 0) {
        Show-Warning "No pending ToDos found for the current or next work week (Mon-Fri)."
        return
    }

    try {
        $sortedUpcoming = @($upcomingTodos | Sort-Object ParsedDueDate, PriorityValue -ErrorAction Stop)
    } catch {
        Handle-Error $_ "Sorting upcoming Todos for schedule view"
        Show-Warning "Could not sort Todos."
        $sortedUpcoming = $upcomingTodos
    }

    $tableData = @()
    $rowColors = @{}
    $idCounter = 1
    foreach ($item in $sortedUpcoming) {
        $rowHighlightKey = ""
        $cellHighlights = @{}
        if ($item.ParsedDueDate.Date -lt $today) {
            $rowHighlightKey = "Overdue"
        } elseif ($item.IsNextWeek) {
            $rowHighlightKey = "SchedNext"
        } else {
            $rowHighlightKey = "SchedCurrent"
        }

        $tableData += [PSCustomObject]@{
            Index=$idCounter
            Task=$item.Task
            ProjectID2=$item.ProjectID2
            DueDate=(Format-DateSafeDisplay $item.DueDate)
            Priority=$item.Priority
            Status=$item.Status
            OriginalTodo = $item.OriginalTodo
        }
        if ($rowHighlightKey) { $rowColors[$idCounter - 1] = $rowHighlightKey }
        $idCounter++
    }

    $script:SelectionScreenTitle = "UPCOMING TODO SCHEDULE (Current/Next Week)"
    $script:SelectionScreenItems = $tableData
    $script:SelectionScreenViewType = "Todos"
    $script:SelectionScreenRowColors = $rowColors
    Set-CurrentScreen -ScreenDefinition $DisplayListScreen
}
#endregion

#region Notes and Commands Functions
function Initialize-NotesFolder {
    if ($null -eq $Global:AppConfig) { Load-AppConfig }
    if ($null -eq $Global:AppConfig) {
        Show-Error "Cannot initialize notes folder - config failed to load."
        return $false
    }
    $notesDir = $Global:AppConfig.notesFolder
    if (-not $notesDir -or -not (Ensure-DirectoryExists -DirectoryPath $notesDir)) {
        Show-Warning "Could not ensure Notes directory exists at: $($Global:AppConfig.notesFolder)."
        return $false
    }
    return $true
}
function Add-Note {
    if (-not (Initialize-NotesFolder)) { return }
    $initialTempData = @{ ContentLines = [System.Collections.Generic.List[string]]::new() }
    $requestParams = @{
        Prompt = "Note filename (alphanumeric, underscores allowed, no .txt)"
        ValidationErrorMessage = "Invalid note filename. Use only letters, numbers, underscores."
        ValidationCallback = { param($name) -not ([string]::IsNullOrWhiteSpace($name) -or $name -match '[\\/:*?"<>| ]+') }
        SubmitCallback = {
            param($name, $tempData)
            $tempData.Name = $name
            Write-AppLog "AddNote: Got Name: $name" "DEBUG"
            Add-Note_Content -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "AddNote cancelled at Name." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Add-Note_Content {
    param($tempData)
    Show-Warning "Multi-line input not fully supported. Use '\\n' for newlines."
    $requestParams = @{
        Prompt = "Note Text (Use '\\n' for newlines, Enter to Save)"
        SubmitCallback = {
            param($content, $tempDataSubmit)
            $tempDataSubmit.RawContent = $content
            $processedContent = $content -replace '\\n', [System.Environment]::NewLine
            $tempDataSubmit.ContentLines.AddRange(($processedContent -split [System.Environment]::NewLine))
            Write-AppLog "AddNote: Got Content (processed)." "DEBUG"
            Add-Note_Save -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "AddNote cancelled at Content." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-Note_Save {
    param($tempData)
    if ($tempData.ContentLines.Count -eq 0) {
        Write-AppLog "Add note cancelled - no content provided." "INFO"
        Show-Warning "Cancelled - no note content entered."
        return
    }
    $fileName = "$($tempData.Name).txt"
    $filePath = Join-Path $Global:AppConfig.notesFolder $fileName
    $fullFileContent = ($tempData.ContentLines -join [System.Environment]::NewLine)

    if (Test-Path $filePath) {
        $confirmParams = @{
            Prompt = "Note file '$fileName' already exists. Overwrite?"
            OnConfirm = {
                param($tempDataConfirm)
                try {
                    $fullFileContent | Out-File -FilePath $filePath -Encoding utf8 -Force -EA Stop
                    Write-AppLog "Saved note '$($tempDataConfirm.Name)' to '$filePath'" "INFO"
                    Show-Success "Note '$($tempDataConfirm.Name)' saved successfully."
                } catch {
                    Handle-Error $_ "Saving note file '$filePath'"
                }
            }
            OnCancel = {
                param($tempDataConfirm)
                Write-AppLog "Add note cancelled - file exists, user chose not to overwrite." "INFO"
                Show-Warning "Cancelled. File not overwritten."
            }
            InitialTempData = $tempData
        }
        Request-ConfirmAction @confirmParams
    } else {
        try {
            $fullFileContent | Out-File -FilePath $filePath -Encoding utf8 -Force -EA Stop
            Write-AppLog "Saved note '$($tempData.Name)' to '$filePath'" "INFO"
            Show-Success "Note '$($tempData.Name)' saved successfully."
        } catch {
            Handle-Error $_ "Saving note file '$filePath'"
        }
    }
}
function Edit-Note {
    param([Parameter(Mandatory=$true)][System.IO.FileInfo]$SelectedFileObject)
    $filePath = $SelectedFileObject.FullName
    $currentContentLines = @()
    try {
        $currentContentLines = @(Get-Content -Path $filePath -Encoding utf8 -EA Stop)
    } catch {
        Handle-Error $_ "Reading note file '$filePath' for edit"
        return
    }

    Show-Info "Editing Note: $($SelectedFileObject.Name)"
    Show-Info "--- Current Content Preview ---"
    $currentContentLines | Select-Object -First 5 | ForEach-Object { Show-Info "  $_" }
    if ($currentContentLines.Count -gt 5) { Show-Info "  ..." }
    Show-Info "--- End Preview ---"
    Show-Warning "Multi-line input not fully supported. Use '\\n' for newlines."

    $initialTempData = @{
        FilePath = $filePath
        BaseName = $SelectedFileObject.BaseName
        NewContentLines = [System.Collections.Generic.List[string]]::new()
    }
    $requestParams = @{
        Prompt = "NEW Note Text (Use '\\n' for newlines, Enter to Save)"
        DefaultValue = ($currentContentLines -join '\n') # Provide current content as default
        SubmitCallback = {
            param($content, $tempDataSubmit)
            $tempDataSubmit.RawContent = $content
            $processedContent = $content -replace '\\n', [System.Environment]::NewLine
            $tempDataSubmit.NewContentLines.AddRange(($processedContent -split [System.Environment]::NewLine))
            Write-AppLog "EditNote: Got Content (processed)." "DEBUG"
            Edit-Note_Save -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "EditNote cancelled at Content." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Edit-Note_Save {
    param($tempData)
    $fullNewContent = ($tempData.NewContentLines -join [System.Environment]::NewLine)
    try {
        $fullNewContent | Out-File -FilePath $tempData.FilePath -Encoding utf8 -Force -EA Stop
        Write-AppLog "Updated note '$($tempData.BaseName)'" "INFO"
        Show-Success "Note '$($tempData.BaseName)' updated successfully."
    } catch {
        Handle-Error $_ "Saving updated note '$($tempData.FilePath)'"
    }
}
function Remove-Note {
    param([Parameter(Mandatory=$true)][System.IO.FileInfo]$SelectedFileObject)
    Show-Warning "This will permanently delete the note file: $($SelectedFileObject.Name)"
    Show-Info "File: $($SelectedFileObject.FullName)"
    try {
        $preview = Get-Content -Path $SelectedFileObject.FullName -TotalCount 10 -Encoding utf8 -EA SilentlyContinue
        Show-Info "Preview:"
        $preview | ForEach-Object {Show-Info "  $_"}
        if($preview.Count -ge 10){ Show-Info "  ..."}
    } catch { }

    $confirmParams = @{
        Prompt = "Confirm deletion of this note file?"
        OnConfirm = {
            param($tempData)
            try {
                Remove-Item -Path $SelectedFileObject.FullName -Force -EA Stop
                Write-AppLog "Deleted note '$($SelectedFileObject.BaseName)' from '$($SelectedFileObject.FullName)'" "INFO"
                Show-Success "Note '$($SelectedFileObject.BaseName)' deleted successfully."
            } catch {
                Handle-Error $_ "Deleting note '$($SelectedFileObject.FullName)'"
            }
        }
        OnCancel = {
            param($tempData)
            Write-AppLog "Remove note cancelled by user for '$($SelectedFileObject.Name)'." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Request-ConfirmAction @confirmParams
}
function Select-And-Action-Note {
    param(
        [Parameter(Mandatory=$true)][System.IO.FileInfo[]]$NoteFiles,
        [string]$Caller = "List Notes"
    )
    if ($NoteFiles.Count -eq 0) {
        Show-Warning "No notes provided for action."
        return
    }
    $selectionItems = @($NoteFiles | ForEach-Object -Begin {$idx=1} -Process {
        [PSCustomObject]@{
            Index=$idx++
            Item = $_
            Name = $_.Name
            LastWriteTime = $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
        }
    })
    $selectParams = @{
        Title = "$Caller - SELECT NOTE"
        Items = $selectionItems
        ViewType = "NoteSelection"
        Prompt = "Select note number (0=Cancel)"
        OnItemSelected = {
            param($selectedObjectWrapper, $tempDataSelect)
            $selectedFileObject = $selectedObjectWrapper.Item
            Select-And-Action-Note_ActionMenu -SelectedFileObject $selectedFileObject
        }
        OnCancel = {
            param($tempDataCancel)
            Write-AppLog "Note action cancelled at selection ($Caller)." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Select-ItemFromList @selectParams
}
function Select-And-Action-Note_ActionMenu {
    param( [Parameter(Mandatory=$true)][System.IO.FileInfo]$SelectedFileObject )
    Show-Info "Note: $($SelectedFileObject.Name)"
    $options = @{
        "1" = {
            param($tempData)
            try {
                $noteContent = Get-Content -Path $SelectedFileObject.FullName -Encoding utf8 -Raw -EA Stop
                Show-Info "--- Note Content ---"
                Show-Info "Content copied to clipboard."
                $noteContent | Set-Clipboard -EA Stop
                Pause-Screen "Press Enter to continue..."
            } catch {
                Handle-Error $_ "Viewing/Copying note '$($SelectedFileObject.Name)'"
            }
        }
        "2" = { param($tempData); Edit-Note -SelectedFileObject $SelectedFileObject }
        "3" = { param($tempData); Remove-Note -SelectedFileObject $SelectedFileObject }
    }
    $requestParams = @{
        Prompt = "Choose action for '$($SelectedFileObject.Name)'"
        MinValue = 1
        MaxValue = 3
        ExtraPromptInfo = "(1=View/Copy, 2=Edit, 3=Delete, 0=Cancel)"
        SubmitCallback = {
            param($choice, $tempData)
            if ($options.ContainsKey($choice.ToString())) {
                & $options[$choice.ToString()] $tempData
            } else {
                Show-Warning "Invalid action choice."
            }
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Note action menu cancelled." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Request-NumericChoice @requestParams
}
function Show-NotesMenu {
    if (-not (Initialize-NotesFolder)) {
        Show-Error "Notes folder could not be initialized. Check config and permissions."
        return
    }
    $noteFiles = @()
    try {
        $noteFiles = @(Get-ChildItem -Path $Global:AppConfig.notesFolder -Filter "*.txt" -File -EA Stop | Sort-Object LastWriteTime -Descending)
    } catch {
        Handle-Error $_ "Listing notes from '$($Global:AppConfig.notesFolder)'"
        return
    }
    if ($noteFiles.Count -eq 0) {
        $confirmParams = @{
            Prompt = "No notes found. Add one now?"
            OnConfirm = { param($tempData) Add-Note }
            OnCancel = { param($tempData) Show-Warning "No notes available." }
        }
        Request-ConfirmAction @confirmParams
        return
    }
    # If notes exist, show the selection screen (which is handled by the NotesScreen definition's OnLoad)
    # This function primarily ensures the folder exists and handles the "no notes" case.
    # The actual display logic is triggered by Set-CurrentScreen calling OnLoad.
}
function Initialize-CommandSnippetFolder {
    if ($null -eq $Global:AppConfig) { Load-AppConfig }
    if ($null -eq $Global:AppConfig) {
        Show-Error "Cannot initialize snippet folder - config failed to load."
        return $false
    }
    $configDir = Join-Path $scriptRoot $Global:DefaultDataSubDir
    if (-not (Ensure-DirectoryExists -DirectoryPath $configDir)) { return $false }
    if (-not (Ensure-DirectoryExists -DirectoryPath $Global:AppConfig.commandsFolder)) {
        Show-Warning "Could not ensure Commands directory exists at: $($Global:AppConfig.commandsFolder)."
        return $false
    }
    return $true
}
function Add-CommandSnippet {
    if (-not (Initialize-CommandSnippetFolder)) { return }
    $initialTempData = @{ ContentLines = [System.Collections.Generic.List[string]]::new() }
    $requestParams = @{
        Prompt = "Snippet name (alphanumeric, underscores allowed)"
        ValidationErrorMessage = "Invalid snippet name. Use only letters, numbers, underscores."
        ValidationCallback = { param($name) -not ([string]::IsNullOrWhiteSpace($name) -or $name -match '[\\/:*?"<>| ]+') }
        SubmitCallback = {
            param($name, $tempData)
            $tempData.Name = $name
            Write-AppLog "AddSnippet: Got Name: $name" "DEBUG"
            Add-CommandSnippet_Desc -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "AddSnippet cancelled at Name." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Add-CommandSnippet_Desc {
    param($tempData)
    $requestParams = @{
        Prompt = "Description (optional, first line of snippet)"
        SubmitCallback = {
            param($desc, $tempDataSubmit)
            $tempDataSubmit.Description = $desc
            Write-AppLog "AddSnippet: Got Desc: $desc" "DEBUG"
            Add-CommandSnippet_Content -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "AddSnippet cancelled at Description." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-CommandSnippet_Content {
    param($tempData)
    Show-Warning "Multi-line input not fully supported. Use '\\n' for newlines."
    $requestParams = @{
        Prompt = "Snippet Text (Use '\\n' for newlines, Enter to Save)"
        SubmitCallback = {
            param($content, $tempDataSubmit)
            $tempDataSubmit.RawContent = $content
            $processedContent = $content -replace '\\n', [System.Environment]::NewLine
            $tempDataSubmit.ContentLines.AddRange(($processedContent -split [System.Environment]::NewLine))
            Write-AppLog "AddSnippet: Got Content (processed)." "DEBUG"
            Add-CommandSnippet_Save -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "AddSnippet cancelled at Content." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Add-CommandSnippet_Save {
    param($tempData)
    if ($tempData.ContentLines.Count -eq 0) {
        Write-AppLog "Add snippet cancelled - no content provided." "INFO"
        Show-Warning "Cancelled - no snippet content entered."
        return
    }
    $fileName = "$($tempData.Name).txt"
    $filePath = Join-Path $Global:AppConfig.commandsFolder $fileName
    $fileHeader = "# Description: $($tempData.Description)`n---`n"
    $fullFileContent = $fileHeader + ($tempData.ContentLines -join [System.Environment]::NewLine)

    if (Test-Path $filePath) {
        $confirmParams = @{
            Prompt = "Snippet file '$fileName' already exists. Overwrite?"
            OnConfirm = {
                param($tempDataConfirm)
                try {
                    $fullFileContent | Out-File -FilePath $filePath -Encoding utf8 -Force -EA Stop
                    Write-AppLog "Saved command snippet '$($tempDataConfirm.Name)' to '$filePath'" "INFO"
                    Show-Success "Snippet '$($tempDataConfirm.Name)' saved successfully."
                } catch {
                    Handle-Error $_ "Saving command snippet file '$filePath'"
                }
            }
            OnCancel = {
                param($tempDataConfirm)
                Write-AppLog "Add snippet cancelled - file exists, user chose not to overwrite." "INFO"
                Show-Warning "Cancelled. File not overwritten."
            }
            InitialTempData = $tempData
        }
        Request-ConfirmAction @confirmParams
    } else {
        try {
            $fullFileContent | Out-File -FilePath $filePath -Encoding utf8 -Force -EA Stop
            Write-AppLog "Saved command snippet '$($tempData.Name)' to '$filePath'" "INFO"
            Show-Success "Snippet '$($tempData.Name)' saved successfully."
        } catch {
            Handle-Error $_ "Saving command snippet file '$filePath'"
        }
    }
}
function Edit-CommandSnippet {
    param([Parameter(Mandatory=$true)][System.IO.FileInfo]$SelectedFileObject)
    $filePath = $SelectedFileObject.FullName
    $description = ""
    $currentContentLines = @()
    try {
        $allLines = Get-Content -Path $filePath -Encoding utf8 -EA Stop
        $separatorFound = $false
        for ($i = 0; $i -lt $allLines.Count; $i++) {
            if (-not $separatorFound) {
                if ($allLines[$i] -match '^\s*#\s*Description:\s*(.+)') { $description = $matches[1].Trim() }
                elseif ($allLines[$i].Trim() -eq '---') { $separatorFound = $true }
            } else {
                $currentContentLines += $allLines[$i]
            }
        }
        if (-not $separatorFound) {
            Write-AppLog "Separator '---' not found editing '$($SelectedFileObject.Name)'." "WARN"
            $startIndex = 0
            if ($allLines.Count -gt 0 -and $allLines[0] -match '^\s*#\s*Description:') { $startIndex = 1 }
            $currentContentLines = $allLines[$startIndex..($allLines.Count - 1)]
        }
    } catch {
        Handle-Error $_ "Reading snippet file '$filePath' for edit"
        return
    }

    Show-Info "Editing Snippet: $($SelectedFileObject.BaseName)"
    Show-Info "Current Description: $description"
    Show-Info "--- Current Content Preview ---"
    $currentContentLines | Select-Object -First 5 | ForEach-Object { Show-Info "  $_" }
    if ($currentContentLines.Count -gt 5) { Show-Info "  ..." }
    Show-Info "--- End Preview ---"
    Show-Warning "Multi-line input not fully supported. Use '\\n' for newlines."

    $initialTempData = @{
        FilePath = $filePath
        BaseName = $SelectedFileObject.BaseName
        NewContentLines = [System.Collections.Generic.List[string]]::new()
    }
    $requestParams = @{
        Prompt = "New Description (Enter to keep current)"
        DefaultValue = $description
        SubmitCallback = {
            param($newDesc, $tempData)
            $tempData.NewDescription = $newDesc
            Write-AppLog "EditSnippet: Got Desc: $newDesc" "DEBUG"
            Edit-CommandSnippet_Content -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "EditSnippet cancelled at Description." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Edit-CommandSnippet_Content {
    param($tempData)
    Show-Warning "Multi-line input not fully supported. Use '\\n' for newlines."
    $requestParams = @{
        Prompt = "NEW Snippet Text (Use '\\n' for newlines, Enter to Save)"
        # Provide current content as default
        DefaultValue = {
             $currentContent = ""
             try {
                 $allLines = Get-Content -Path $tempData.FilePath -Encoding utf8 -EA Stop
                 $separatorFound = $false; $contentLines = @()
                 for ($i = 0; $i -lt $allLines.Count; $i++) {
                     if (-not $separatorFound) { if ($allLines[$i].Trim() -eq '---') { $separatorFound = $true } }
                     else { $contentLines += $allLines[$i] }
                 }
                 if (-not $separatorFound) {
                     $startIndex = 0; if ($allLines.Count -gt 0 -and $allLines[0] -match '^\s*#\s*Description:') { $startIndex = 1 }; $contentLines = $allLines[$startIndex..($allLines.Count - 1)]
                 }
                 $currentContent = $contentLines -join '\n'
             } catch { Write-AppLog "Error getting current content for EditSnippet default: $($_.Exception.Message)" "WARN" }
             return $currentContent
        }.Invoke()
        SubmitCallback = {
            param($content, $tempDataSubmit)
            $tempDataSubmit.RawContent = $content
            $processedContent = $content -replace '\\n', [System.Environment]::NewLine
            $tempDataSubmit.NewContentLines.AddRange(($processedContent -split [System.Environment]::NewLine))
            Write-AppLog "EditSnippet: Got Content (processed)." "DEBUG"
            Edit-CommandSnippet_Save -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "EditSnippet cancelled at Content." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Edit-CommandSnippet_Save {
    param($tempData)
    $newFileHeader = "# Description: $($tempData.NewDescription)`n---`n"
    $fullNewContent = $newFileHeader + ($tempData.NewContentLines -join [System.Environment]::NewLine)
    try {
        $fullNewContent | Out-File -FilePath $tempData.FilePath -Encoding utf8 -Force -EA Stop
        Write-AppLog "Updated command snippet '$($tempData.BaseName)'" "INFO"
        Show-Success "Snippet '$($tempData.BaseName)' updated successfully."
    } catch {
        Handle-Error $_ "Saving updated command snippet '$($tempData.FilePath)'"
    }
}
function Remove-CommandSnippet {
    param([Parameter(Mandatory=$true)][System.IO.FileInfo]$SelectedFileObject)
    Show-Warning "This will permanently delete the snippet file: $($SelectedFileObject.Name)"
    Show-Info "File: $($SelectedFileObject.FullName)"
    try {
        $preview = Get-Content -Path $SelectedFileObject.FullName -TotalCount 10 -Encoding utf8 -EA SilentlyContinue
        Show-Info "Preview:"
        $preview | ForEach-Object {Show-Info "  $_"}
        if($preview.Count -ge 10){ Show-Info "  ..."}
    } catch { }

    $confirmParams = @{
        Prompt = "Confirm deletion of this snippet file?"
        OnConfirm = {
            param($tempData)
            try {
                Remove-Item -Path $SelectedFileObject.FullName -Force -EA Stop
                Write-AppLog "Deleted command snippet '$($SelectedFileObject.BaseName)' from '$($SelectedFileObject.FullName)'" "INFO"
                Show-Success "Snippet '$($SelectedFileObject.BaseName)' deleted successfully."
            } catch {
                Handle-Error $_ "Deleting command snippet '$($SelectedFileObject.FullName)'"
            }
        }
        OnCancel = {
            param($tempData)
            Write-AppLog "Remove snippet cancelled by user for '$($SelectedFileObject.Name)'." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Request-ConfirmAction @confirmParams
}
function Search-CommandSnippets {
    if (-not (Initialize-CommandSnippetFolder)) { return }
    $initialTempData = @{}
    $requestParams = @{
        Prompt = "Enter search term (searches name and description)"
        ValidationErrorMessage = "No search term entered."
        ValidationCallback = { param($term) -not [string]::IsNullOrWhiteSpace($term) }
        SubmitCallback = {
            param($searchTerm, $tempData)
            $commandFiles = @()
            try {
                $commandFiles = @(Get-ChildItem -Path $Global:AppConfig.commandsFolder -Filter "*.txt" -File -EA Stop)
            } catch {
                Handle-Error $_ "Listing command snippets for search"
                return
            }
            if ($commandFiles.Count -eq 0) {
                Show-Warning "No command snippets found in the folder."
                return
            }

            $matchingFiles = [System.Collections.Generic.List[System.IO.FileInfo]]::new()
            $pattern = ""
            try { $pattern = [regex]::Escape($searchTerm) } catch { Handle-Error $_ "Escaping search term regex"; return }

            foreach ($file in $commandFiles) {
                $matchFound = $false
                if ($file.BaseName -match $pattern) { $matchFound = $true }
                if (-not $matchFound) {
                    try {
                        $headerLines = Get-Content -Path $file.FullName -TotalCount 3 -Encoding utf8 -EA SilentlyContinue
                        $descLine = $headerLines | Where-Object { $_ -match '^\s*#\s*Description:\s*(.+)' } | Select-Object -First 1
                        if ($descLine -and $matches[1] -match $pattern) { $matchFound = $true }
                    } catch { Write-AppLog "Could not read header for snippet search: $($file.Name)" "WARN" }
                }
                if ($matchFound) { $matchingFiles.Add($file) }
            }

            if ($matchingFiles.Count -eq 0) {
                Show-Warning "No snippets found matching '$searchTerm'."
                return
            }
            Show-Info "$($matchingFiles.Count) snippet(s) found matching '$searchTerm'."
            Select-And-Action-CommandSnippet -SnippetFiles $matchingFiles.ToArray() -Caller "Search Results"
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Search snippets cancelled." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Select-And-Action-CommandSnippet {
    param(
        [Parameter(Mandatory=$true)][System.IO.FileInfo[]]$SnippetFiles,
        [string]$Caller = "List Snippets"
    )
    if ($SnippetFiles.Count -eq 0) {
        Show-Warning "No snippets provided for action."
        return
    }
    $selectionItems = @($SnippetFiles | ForEach-Object -Begin {$idx=1} -Process {
        $name = $_.BaseName
        $description = ""
        try {
            $headerLines = Get-Content -Path $_.FullName -TotalCount 3 -Encoding utf8 -EA SilentlyContinue
            $descLine = $headerLines | Where-Object { $_ -match '^\s*#\s*Description:\s*(.+)' } | Select-Object -First 1
            if ($descLine) { $description = $matches[1].Trim() }
        } catch {}
        [PSCustomObject]@{
            Index = $idx++ # Add Index for selection
            Item = $_
            BaseName = $name
            FullName=$_.FullName
            Description = $description
        }
    })
    $selectParams = @{
        Title = "$Caller - SELECT SNIPPET"
        Items = $selectionItems
        ViewType = "CommandSelection"
        Prompt = "Select snippet number (0=Cancel)"
        OnItemSelected = {
            param($selectedObjectWrapper, $tempDataSelect)
            $selectedFileObject = $selectedObjectWrapper.Item
            Select-And-Action-CommandSnippet_ActionMenu -SelectedFileObject $selectedFileObject -Description $selectedObjectWrapper.Description
        }
        OnCancel = {
            param($tempDataCancel)
            Write-AppLog "Snippet action cancelled at selection ($Caller)." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Select-ItemFromList @selectParams
}
function Select-And-Action-CommandSnippet_ActionMenu {
    param(
        [Parameter(Mandatory=$true)][System.IO.FileInfo]$SelectedFileObject,
        [string]$Description
    )
    Show-Info "Snippet: $($SelectedFileObject.BaseName)"
    Show-Info "Description: $Description"
    $options = @{
        "1" = {
            param($tempData)
            try {
                $scriptLines = Get-Content -Path $SelectedFileObject.FullName -Encoding utf8 -EA Stop
                $startIndex = -1
                $separatorFound = $false
                for ($i = 0; $i -lt $scriptLines.Count; $i++) {
                    if ($scriptLines[$i].Trim() -eq '---') { $startIndex = $i + 1; $separatorFound = $true; break }
                }
                if (-not $separatorFound) {
                    $startIndex = 0
                    if ($scriptLines.Count -gt 0 -and $scriptLines[0] -match '^\s*#\s*Description:') { $startIndex = 1 }
                    Write-AppLog "Separator '---' not found in snippet '$($SelectedFileObject.Name)' for copy." "WARN"
                }
                $snippetContentToCopy = ""
                if ($startIndex -ge 0 -and $startIndex -lt $scriptLines.Count) {
                    $snippetContentToCopy = ($scriptLines[$startIndex..($scriptLines.Count - 1)] -join [System.Environment]::NewLine)
                }
                $snippetContentToCopy | Set-Clipboard -EA Stop
                Show-Success "Snippet content copied to clipboard."
            } catch {
                Handle-Error $_ "Copying snippet '$($SelectedFileObject.Name)' to clipboard"
            }
        }
        "2" = { param($tempData); Edit-CommandSnippet -SelectedFileObject $SelectedFileObject }
        "3" = { param($tempData); Remove-CommandSnippet -SelectedFileObject $SelectedFileObject }
    }
    $requestParams = @{
        Prompt = "Choose action for '$($SelectedFileObject.BaseName)'"
        MinValue = 1
        MaxValue = 3
        ExtraPromptInfo = "(1=Copy, 2=Edit, 3=Delete, 0=Cancel)"
        SubmitCallback = {
            param($choice, $tempData)
            if ($options.ContainsKey($choice.ToString())) {
                & $options[$choice.ToString()] $tempData
            } else {
                Show-Warning "Invalid action choice."
            }
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Snippet action menu cancelled." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Request-NumericChoice @requestParams
}
function Show-CommandsMenu {
    if (-not (Initialize-CommandSnippetFolder)) {
        Show-Error "Command Snippet folder could not be initialized. Check config and permissions."
        return
    }
    $commandFiles = @()
    try {
        $commandFiles = @(Get-ChildItem -Path $Global:AppConfig.commandsFolder -Filter "*.txt" -File -EA Stop | Sort-Object Name)
    } catch {
        Handle-Error $_ "Listing command snippets from '$($Global:AppConfig.commandsFolder)'"
        return
    }
    if ($commandFiles.Count -eq 0) {
        $confirmParams = @{
            Prompt = "No command snippets found. Add one now?"
            OnConfirm = { param($tempData) Add-CommandSnippet }
            OnCancel = { param($tempData) Show-Warning "No snippets available." }
        }
        Request-ConfirmAction @confirmParams
        return
    }
    # Actual display is handled by CommandsScreen OnLoad
}
#endregion

#region Time Entry Management Functions
function Show-TimeEntryManagementScreen {
    Write-AppLog "Starting Time Entry Management." "INFO"
    $timeEntries = Get-CsvDataSafely -FilePath $Global:AppConfig.timeTrackingFile
    if ($null -eq $timeEntries) {
        Show-Error "Could not load time entries."
        return
    }
    if ($timeEntries.Count -eq 0) {
        Show-Warning "No time entries found to manage."
        return
    }

    $entriesWithId = @()
    foreach($entry in $timeEntries){
        if(-not $entry.PSObject.Properties.Name.Contains('TimeEntryID') -or [string]::IsNullOrWhiteSpace($entry.TimeEntryID)){
            Write-AppLog "Found time entry missing ID. Date:$($entry.Date), ID2:$($entry.ID2). Assigning temporary ID for selection." "WARN"
            $entry | Add-Member -MemberType NoteProperty -Name 'TimeEntryID' -Value "[TEMP_ID_$([guid]::NewGuid())]" -Force
        }
        $entriesWithId += $entry
    }

    $sortedEntries = $entriesWithId | Sort-Object Date -Descending
    $selectionItems = $sortedEntries | ForEach-Object -Begin {$idx=1} -Process {
        [PSCustomObject]@{
            Index = $idx++
            DisplayDate = Format-DateSafeDisplay $_.Date
            ID2 = $_.ID2
            HoursValue = $_.Hours
            Description = $_.Description
            OriginalEntry = $_ # Keep reference to original object with TimeEntryID
        }
    }

    $script:CurrentTimeManagementEntries = $selectionItems
    $script:CurrentTimeManagementCount = $selectionItems.Count
    $script:CurrentTimeManagementRowColors = @{}
    # Screen is set by the caller or main menu action
}
function Show-TimeEntryActions {
    param([Parameter(Mandatory=$true)][PSCustomObject]$Entry) # Expects the OriginalEntry object
    $display = "$(Format-DateSafeDisplay $Entry.Date) | $($Entry.ID2) | $($Entry.Hours) hrs | $($Entry.Description)"
    Show-Info "Selected Entry: $display"
    $confirmParams = @{
        Prompt = "Update or Delete this time entry?"
        YesOption = "U"
        YesText = "Update"
        NoOption = "D"
        NoText = "Delete"
        CancelOption = "0"
        CancelText = "Cancel"
        OnConfirm = { param($tempData) Start-UpdateTimeEntrySequence -Entry $Entry }
        OnDeny = { param($tempData) Confirm-DeleteTimeEntry -Entry $Entry }
        OnCancel = {
            param($tempData)
            Write-AppLog "Time entry action cancelled." "INFO"
            Show-Warning "Cancelled."
        }
    }
    Request-ConfirmAction @confirmParams
}
function Start-UpdateTimeEntrySequence {
    param([Parameter(Mandatory=$true)][PSCustomObject]$Entry) # Expects OriginalEntry
    Show-Info "Updating Time Entry (ID: $($Entry.TimeEntryID))"
    Show-Info "Current: $(Format-DateSafeDisplay $Entry.Date) | $($Entry.ID2) | $($Entry.Hours) hrs | $($Entry.Description)"
    $initialTempData = @{
        OriginalEntry = $Entry
        NewData = $Entry.PSObject.Copy() # Copy to modify
    }
    $requestParams = @{
        Prompt = "New Date (YYYYMMDD or common format)"
        DefaultValue = $Entry.Date
        ForceDateFormat = $true
        ValidationErrorMessage = "Invalid date format. Try YYYY-MM-DD or YYYYMMDD."
        ValidationCallback = {
            param($input)
            $parsedDateInternal = Parse-DateSafeInternal $input
            return -not ([string]::IsNullOrEmpty($parsedDateInternal))
        }
        SubmitCallback = {
            param($dateInput, $tempData)
            $tempData.NewData.Date = Parse-DateSafeInternal $dateInput
            Write-AppLog "Update Time: Got Date: $($tempData.NewData.Date)" "DEBUG"
            Start-UpdateTimeEntrySequence_ID2 -tempData $tempData
        }
        CancelCallback = {
            param($tempData)
            Write-AppLog "Update Time cancelled at Date." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $initialTempData
    }
    Request-TextInput @requestParams
}
function Start-UpdateTimeEntrySequence_ID2 {
    param($tempData)
    $requestParams = @{
        Prompt = "New Project ID2 or Non-Project Task"
        DefaultValue = $tempData.OriginalEntry.ID2
        ValidationErrorMessage = "ID2/Task cannot be empty."
        ValidationCallback = { param($id2) -not [string]::IsNullOrWhiteSpace($id2) }
        SubmitCallback = {
            param($id2Input, $tempDataSubmit)
            $tempDataSubmit.NewData.ID2 = $id2Input.Trim()
            Write-AppLog "Update Time: Got ID2: $($tempDataSubmit.NewData.ID2)" "DEBUG"
            Start-UpdateTimeEntrySequence_Hours -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Update Time cancelled at ID2." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Start-UpdateTimeEntrySequence_Hours {
    param($tempData)
    $requestParams = @{
        Prompt = "New Hours (e.g., 7.5, 0.5)"
        DefaultValue = $tempData.OriginalEntry.Hours
        ValidationErrorMessage = "Invalid hours. Must be a positive number."
        ValidationCallback = {
            param($hoursInput)
            $hours = 0.0
            if (-not ([double]::TryParse($hoursInput, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$hours)) -or $hours -lt 0) { return $false }
            return $true
        }
        SubmitCallback = {
            param($hoursInput, $tempDataSubmit)
            [double]::TryParse($hoursInput, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$hoursVal) | Out-Null
            $tempDataSubmit.NewData.Hours = $hoursVal.ToString("0.0")
            Write-AppLog "Update Time: Got Hours: $($tempDataSubmit.NewData.Hours)" "DEBUG"
            Start-UpdateTimeEntrySequence_Desc -tempData $tempDataSubmit
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Update Time cancelled at Hours." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Start-UpdateTimeEntrySequence_Desc {
    param($tempData)
    $requestParams = @{
        Prompt = "New Description (optional)"
        DefaultValue = $tempData.OriginalEntry.Description
        SubmitCallback = {
            param($descInput, $tempDataSubmit)
            $isCustomTask = $tempDataSubmit.NewData.ID2 -match '\s' -or $tempDataSubmit.NewData.ID2.Length -gt 20
            $tempDataSubmit.NewData.Description = if ($isCustomTask) { "" } else { $descInput.Trim() }
            Write-AppLog "Update Time: Got Description: $($tempDataSubmit.NewData.Description)" "DEBUG"
            Execute-UpdateTimeEntry -TimeEntryID $tempDataSubmit.OriginalEntry.TimeEntryID -NewEntryData $tempDataSubmit.NewData
        }
        CancelCallback = {
            param($tempDataCancel)
            Write-AppLog "Update Time cancelled at Description." "INFO"
            Show-Warning "Cancelled."
        }
        InitialTempData = $tempData
    }
    Request-TextInput @requestParams
}
function Execute-UpdateTimeEntry {
    param(
        [Parameter(Mandatory=$true)][string]$TimeEntryID,
        [Parameter(Mandatory=$true)][PSCustomObject]$NewEntryData
    )
    Write-AppLog "Executing update for TimeEntryID: $TimeEntryID" "INFO"
    $allTimeEntries = Get-CsvDataSafely -FilePath $Global:AppConfig.timeTrackingFile
    if ($null -eq $allTimeEntries) {
        Show-Error "Failed to load time entries for update."
        return
    }

    $entryFound = $false
    for ($i = 0; $i -lt $allTimeEntries.Count; $i++) {
        if ($allTimeEntries[$i].PSObject.Properties.Name.Contains('TimeEntryID') -and $allTimeEntries[$i].TimeEntryID -eq $TimeEntryID) {
            Write-AppLog "Found entry to update at index $i." "DEBUG"
            $allTimeEntries[$i].Date = $NewEntryData.Date
            $allTimeEntries[$i].ID2 = $NewEntryData.ID2
            $allTimeEntries[$i].Hours = $NewEntryData.Hours
            $allTimeEntries[$i].Description = $NewEntryData.Description
            $entryFound = $true
            break
        }
    }

    if (-not $entryFound) {
        Write-AppLog "Execute-UpdateTimeEntry: Could not find TimeEntryID '$TimeEntryID' to update." "ERROR"
        Show-Error "Error: Could not find the time entry to update. It might have been modified or deleted."
        return
    }

    try {
        $allTimeEntries = @($allTimeEntries | Sort-Object Date, ID2 -ErrorAction Stop)
    } catch {
        Handle-Error $_ "Sorting time entries before save (update)"
    }

    if (Set-CsvData -FilePath $Global:AppConfig.timeTrackingFile -Data $allTimeEntries) {
        Show-Success "Time entry updated successfully."
        # Refresh the list if we are on the Time Management screen
        if ((Get-CurrentScreen).Name -eq 'TimeManagementScreen') {
            Show-TimeEntryManagementScreen # Reloads data and sets screen state
            Invoke-PmcRenderRequest -ForceRedraw $true # Ensure redraw
        }
    } else {
        Show-Error "Failed to save updated time tracking data."
    }
}
function Confirm-DeleteTimeEntry {
    param([Parameter(Mandatory=$true)][PSCustomObject]$Entry) # Expects OriginalEntry
    Show-Warning "PERMANENTLY DELETE this time entry?"
    Show-Info "$(Format-DateSafeDisplay $Entry.Date) | $($Entry.ID2) | $($Entry.Hours) hrs | $($Entry.Description)"
    $confirmParams = @{
        Prompt = "Confirm Deletion"
        OnConfirm = { param($tempData) Execute-DeleteTimeEntry -TimeEntryID $Entry.TimeEntryID }
        OnCancel = {
            param($tempData)
            Write-AppLog "Time entry deletion cancelled." "INFO"
            Show-Warning "Deletion cancelled."
        }
    }
    Request-ConfirmAction @confirmParams
}
function Execute-DeleteTimeEntry {
    param([Parameter(Mandatory=$true)][string]$TimeEntryID)
    Write-AppLog "Executing delete for TimeEntryID: $TimeEntryID" "INFO"
    $allTimeEntries = Get-CsvDataSafely -FilePath $Global:AppConfig.timeTrackingFile
    if ($null -eq $allTimeEntries) {
        Show-Error "Failed to load time entries for deletion."
        return
    }

    $originalCount = $allTimeEntries.Count
    $updatedTimeEntries = @($allTimeEntries | Where-Object { -not ($_.PSObject.Properties.Name.Contains('TimeEntryID') -and $_.TimeEntryID -eq $TimeEntryID) })
    $removedCount = $originalCount - $updatedTimeEntries.Count

    if ($removedCount -eq 0) {
        Write-AppLog "Execute-DeleteTimeEntry: Could not find TimeEntryID '$TimeEntryID' to delete." "ERROR"
        Show-Error "Error: Could not find the time entry to delete. It might have already been deleted."
        return
    }

    Write-AppLog "Removed $removedCount time entries with ID '$TimeEntryID'." "INFO"
    if (Set-CsvData -FilePath $Global:AppConfig.timeTrackingFile -Data $updatedTimeEntries) {
        Show-Success "Time entry deleted successfully."
        # Refresh the list if we are on the Time Management screen
        if ((Get-CurrentScreen).Name -eq 'TimeManagementScreen') {
            Show-TimeEntryManagementScreen # Reloads data and sets screen state
            Invoke-PmcRenderRequest -ForceRedraw $true # Ensure redraw
        }
    } else {
        Show-Error "Failed to save time tracking data after deletion."
    }
}
#endregion

#region Calendar Functions
function Get-CalendarData {
    param([datetime]$Month)
    try {
        $firstDayOfMonth = Get-Date -Year $Month.Year -Month $Month.Month -Day 1
        $daysInMonth = [System.DateTime]::DaysInMonth($Month.Year, $Month.Month)
        $lastDayOfMonth = $firstDayOfMonth.AddDays($daysInMonth - 1)

        # Find the first Sunday to display (might be in previous month)
        $startDisplayDate = $firstDayOfMonth
        while ($startDisplayDate.DayOfWeek -ne [System.DayOfWeek]::Sunday) {
            $startDisplayDate = $startDisplayDate.AddDays(-1)
        }

        # Find the last Saturday to display (might be in next month)
        $endDisplayDate = $lastDayOfMonth
        while ($endDisplayDate.DayOfWeek -ne [System.DayOfWeek]::Saturday) {
            $endDisplayDate = $endDisplayDate.AddDays(1)
        }

        $weeks = [System.Collections.Generic.List[object]]::new()
        $currentDate = $startDisplayDate
        while ($currentDate -le $endDisplayDate) {
            $week = @{ Days = [System.Collections.Generic.List[object]]::new() }
            for ($d = 0; $d -lt 7; $d++) {
                $week.Days.Add([PSCustomObject]@{
                    Date = $currentDate
                    IsCurrentMonth = ($currentDate.Month -eq $Month.Month)
                    # Add Todo/Event data here later
                })
                $currentDate = $currentDate.AddDays(1)
            }
            $weeks.Add($week)
        }
        return @{ Month = $Month; Weeks = $weeks }
    } catch {
        Handle-Error $_ "Generating calendar data for $($Month.ToString('yyyy-MM'))"
        return $null
    }
}
#endregion

#region File Browser Functions
function Update-FileBrowserList {
    param(
        [Parameter(Mandatory=$true)][string]$CurrentPath,
        [switch]$SelectFolder
    )
    $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }
    $logFunc.Invoke("Update-FileBrowserList: Path='$CurrentPath', SelectFolder=$SelectFolder")
    $items = @()
    $parentPath = ""
    try {
        # Add ".." entry if not at root
        $parentPath = Split-Path -Path $CurrentPath -Parent
        if (-not [string]::IsNullOrEmpty($parentPath) -and $parentPath -ne $CurrentPath) {
            $items += [PSCustomObject]@{ Index=0; Type="[..]"; Name="Parent Directory"; FullPath=$parentPath; IsDir=$true }
        } elseif (Test-Path "$CurrentPath\..") { # Handle drive root case like C:\
            try { $parentPath = (Get-Item "$CurrentPath\..").FullName } catch { $parentPath = "" }
            if (-not [string]::IsNullOrEmpty($parentPath)) {
                 $items += [PSCustomObject]@{ Index=0; Type="[..]"; Name="Parent Directory"; FullPath=$parentPath; IsDir=$true }
            }
        }

        # Get directories
        $dirs = Get-ChildItem -Path $CurrentPath -Directory -ErrorAction SilentlyContinue | Sort-Object Name
        $items += $dirs | ForEach-Object -Begin {$idx=1} -Process {
            [PSCustomObject]@{ Index=$idx++; Type="[Dir]"; Name=$_.Name; FullPath=$_.FullName; IsDir=$true }
        }

        # Get files only if not in SelectFolder mode
        if (-not $SelectFolder) {
            $files = Get-ChildItem -Path $CurrentPath -File -ErrorAction SilentlyContinue | Sort-Object Name
            $items += $files | ForEach-Object -Begin {$idx=$items.Count+1} -Process {
                [PSCustomObject]@{ Index=$idx++; Type="File"; Name=$_.Name; FullPath=$_.FullName; IsDir=$false }
            }
        }
        $logFunc.Invoke("Update-FileBrowserList: Found $($items.Count) items.")
    } catch {
        Handle-Error $_ "Listing directory '$CurrentPath' for file browser"
        Show-Error "Error accessing path: $CurrentPath"
        # Return empty list on error? Or previous state? Empty for now.
        $items = @()
    }

    # Update SelectionScreen state
    $script:SelectionScreenTitle = "BROWSE: $CurrentPath"
    $script:SelectionScreenItems = $items
    $script:SelectionScreenViewType = "FileBrowserList"
    $script:SelectionScreenItemMap = @{} # Rebuild map
    $items | ForEach-Object { $script:SelectionScreenItemMap[$_.Index] = $_ }
    $script:SelectionScreenRowColors = @{} # Reset colors
    $script:InputState.CurrentSelectionIndex = 0 # Reset selection index
    if ($script:TempDataForSelection -ne $null) {
        $script:TempDataForSelection.CurrentPath = $CurrentPath # Update path in temp data
    } else {
        Write-AppLog "Update-FileBrowserList: Warning - TempDataForSelection is null." "WARN"
    }

    Invoke-PmcRenderRequest -ForceRedraw $true
}
function Request-FilePath {
    param(
        [string]$Prompt = "Select Path",
        [string]$InitialPath = $Global:scriptRoot,
        [switch]$SelectFolder = $false, # If true, Enter on a folder selects it
        [scriptblock]$OnPathSelected,
        [scriptblock]$OnCancel,
        [hashtable]$InitialTempData = @{}
    )
    $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }
    $logFunc.Invoke("Request-FilePath: Prompt='$Prompt', Initial='$InitialPath', SelectFolder=$SelectFolder")

    # Ensure initial path exists and is a directory
    if (-not (Test-Path $InitialPath -PathType Container)) {
        $InitialPath = Split-Path -Path $InitialPath -Parent -ErrorAction SilentlyContinue
        if (-not (Test-Path $InitialPath -PathType Container)) {
            $InitialPath = $Global:scriptRoot # Fallback to script root
        }
    }

    # Store state needed by the selection screen and callbacks
    $tempData = $InitialTempData.Clone() # Clone to avoid modifying original
    $tempData.CurrentPath = $InitialPath
    $tempData.SelectFolder = $SelectFolder
    $tempData.OriginalOnPathSelected = $OnPathSelected
    $tempData.OriginalOnCancel = $OnCancel

    # Define the item selection handler for the file browser
    $FileBrowserItemSelected = {
        param($selectedItem, $tempDataSelect)
        $logFunc.Invoke("FileBrowserItemSelected: Selected Index $($selectedItem.Index), Name '$($selectedItem.Name)', IsDir=$($selectedItem.IsDir)")

        if ($selectedItem.IsDir) {
            # Navigate into directory or select if SelectFolder is true
            if ($tempDataSelect.SelectFolder -and $selectedItem.Index -ne 0) { # Don't select ".."
                $logFunc.Invoke("FileBrowserItemSelected: Folder selected: $($selectedItem.FullPath)")
                Reset-InputState; Navigate-Back | Out-Null # Close selection screen first
                if ($tempDataSelect.OriginalOnPathSelected) {
                    try { & $tempDataSelect.OriginalOnPathSelected $selectedItem.FullPath $tempDataSelect }
                    catch { Handle-Error $_ "executing FileBrowser OnPathSelected callback" }
                }
            } else {
                # Navigate into the directory (including "..")
                $logFunc.Invoke("FileBrowserItemSelected: Navigating to: $($selectedItem.FullPath)")
                Update-FileBrowserList -CurrentPath $selectedItem.FullPath -SelectFolder:$tempDataSelect.SelectFolder
            }
        } else {
            # File selected (only possible if SelectFolder is false)
            $logFunc.Invoke("FileBrowserItemSelected: File selected: $($selectedItem.FullPath)")
            Reset-InputState; Navigate-Back | Out-Null # Close selection screen first
            if ($tempDataSelect.OriginalOnPathSelected) {
                try { & $tempDataSelect.OriginalOnPathSelected $selectedItem.FullPath $tempDataSelect }
                catch { Handle-Error $_ "executing FileBrowser OnPathSelected callback" }
            }
        }
    }

    # Define the cancel handler
    $FileBrowserCancel = {
        param($tempDataSelect)
        $logFunc.Invoke("FileBrowser Cancelled.")
        if ($tempDataSelect.OriginalOnCancel) {
            try { & $tempDataSelect.OriginalOnCancel $tempDataSelect }
            catch { Handle-Error $_ "executing FileBrowser OnCancel callback" }
        }
    }

    # Set up parameters for Select-ItemFromList
    $selectParams = @{
        Title = "FILE BROWSER" # Title will be updated by Update-FileBrowserList
        Prompt = $Prompt
        ViewType = "FileBrowserList"
        OnItemSelected = $FileBrowserItemSelected
        OnCancel = $FileBrowserCancel
        InitialTempData = $tempData # Pass our state
        # Items, RowColors, etc., are set by Update-FileBrowserList
    }

    # Initial population of the list
    Update-FileBrowserList -CurrentPath $InitialPath -SelectFolder:$SelectFolder

    # Start the selection process
    Select-ItemFromList @selectParams
}
#endregion

#region Main Application Loop
function Show-MainMenu {
    if ($script:ScreenStack.Count -eq 0) {
        Write-AppLog "Screen stack empty at Show-MainMenu start. Resetting to Dashboard." "WARN"
        Set-CurrentScreen -ScreenDefinition $DashboardScreen
        if ($script:ScreenStack.Count -eq 0) {
            Write-Error "FATAL: Could not set initial Dashboard screen."
            $script:keepRunning = $false
            return
        }
    }
    while ($script:keepRunning) {
        $currentScreenDef = Get-CurrentScreen
        if ($null -eq $currentScreenDef) {
            Write-AppLog "No current screen definition found. Exiting." "ERROR"
            $script:keepRunning = $false
            continue
        }
        $theme = Get-ActiveTheme
        $dims = Get-BufferDimensions

        # Handle Console Resize
        try {
            $currentWidth = $Host.UI.RawUI.WindowSize.Width
            $currentHeight = $Host.UI.RawUI.WindowSize.Height
            if ($currentWidth -ne $script:lastWidth -or $currentHeight -ne $script:lastHeight) {
                Write-AppLog "Console resized to $currentWidth x $currentHeight" "INFO"
                Resize-ConsoleBuffers -NewWidth $currentWidth -NewHeight $currentHeight
                $script:lastWidth = $currentWidth
                $script:lastHeight = $currentHeight
                $null = Invoke-PmcRenderRequest -ForceRedraw $true
            }
        } catch {
            Write-AppLog "Error checking/handling console resize: $($_.Exception.Message)" "WARN"
        }

        # Update Pomodoro Timer
        if ($script:PomodoroState.Running) {
            $now = Get-Date
            if ($script:PomodoroState.LastUpdateTime -ne $null) {
                $elapsedSinceLastUpdate = $now - $script:PomodoroState.LastUpdateTime
                $script:PomodoroState.RemainingTS = $script:PomodoroState.RemainingTS - $elapsedSinceLastUpdate
            }
            $script:PomodoroState.LastUpdateTime = $now
            if ($script:PomodoroState.RemainingTS.TotalSeconds -le 0) {
                Write-AppLog "Pomodoro Timer Finished ($($script:PomodoroState.Mode))" "INFO"
                Switch-PomodoroMode # This also requests render
            } else {
                Invoke-PmcRenderRequest # Request render to update time display
            }
        } elseif ($script:PomodoroState.RequestRender) {
            Invoke-PmcRenderRequest
            $script:PomodoroState.RequestRender = $false
        }

        # Handle Detail Screen Refresh Request
        if ($currentScreenDef.Name -eq 'ProjectDetail' -and $script:RefreshDetailScreen) {
            Write-AppLog "Refreshing Project Detail Screen..." "DEBUG"
            # Call OnLoad logic directly to refresh data
            try { & $ProjectDetailScreen.OnLoad } catch { Handle-Error $_ "refreshing Project Detail Screen" }
            $script:RefreshDetailScreen = $false
            $null = Invoke-PmcRenderRequest -ForceRedraw $true
        }

        # Update Status Line and Action List Line (Dynamic Views)
        $statusLineView = $currentScreenDef.Views | Where-Object { $_.Name -eq 'StatusLine' }
        if ($null -ne $statusLineView) {
            $statusWidth = $dims.Width
            $statusText = ""
            $statusFG = ""
            $statusBG = ""
            if ($statusWidth -gt 0) {
                $statusText = $script:StatusMessage.Text
                $statusType = $script:StatusMessage.Type ?? "Info"
                if ($script:StatusMessage.Timeout -ne $null -and (Get-Date) -ge $script:StatusMessage.Timeout) {
                    $statusText = ""
                    $script:StatusMessage.Text = ""
                    $script:StatusMessage.Timeout = $null
                }
                if (-not [string]::IsNullOrEmpty($statusText)) {
                    $styleInfo = Get-PmcThemeProperty $theme "StatusMessage.Types.$statusType" $null "Hashtable"
                    if ($styleInfo) {
                        $statusFG = Get-PmcThemeAnsiCode "StatusMessage.Types.$statusType.FG"
                        $statusBG = Get-PmcThemeAnsiCode "StatusMessage.Types.$statusType.BG"
                        $prefix = Get-PmcThemeProperty $theme "StatusMessage.Types.$statusType.Prefix" "" "String"
                        $statusText = "$prefix$statusText"
                    } else {
                        $statusFG = Get-PmcThemeAnsiCode "StatusLine.FG"
                        $statusBG = Get-PmcThemeAnsiCode "StatusLine.BG"
                    }
                } else {
                    $statusFG = Get-PmcThemeAnsiCode "StatusLine.FG"
                    $statusBG = Get-PmcThemeAnsiCode "StatusLine.BG"
                }

                # Special handling for Project List status bar
                if ($currentScreenDef.Name -eq 'ProjectsListScreen') {
                     $filterSortInfo = "Filter: $($script:ProjectFilter) | Sort: $($script:ProjectSort)"
                     $availableWidth = $script:BufferWidth - (Measure-StringWidth $filterSortInfo) - 4 # -4 for padding/border
                     if (Measure-StringWidth $statusText -gt $availableWidth) { $statusText = $statusText.Substring(0, [Math]::Max(0, $availableWidth - 1)) + "…" }
                     $statusLineView.Text = $statusText.PadRight($availableWidth) + "  " + $filterSortInfo
                } else {
                    if (Measure-StringWidth $statusText -gt $statusWidth) { $statusText = $statusText.Substring(0, [Math]::Min($statusText.Length, $statusWidth - 1)) + "…" }
                    $statusLineView.Text = $statusText.PadRight($statusWidth)
                }
                $statusLineView.FG_Ansi = $statusFG
                $statusLineView.BG_Ansi = $statusBG
            } else {
                $statusLineView.Text = ""
            }
        }

        $actionListLineView = $currentScreenDef.Views | Where-Object { $_.Name -eq 'ActionListLine' }
        if ($null -ne $actionListLineView) {
            $actionsWidth = $dims.Width
            $actionsText = ""
            if ($actionsWidth -gt 0) {
                if ($currentScreenDef.AvailableActions -is [scriptblock]) {
                    try { $actionsText = & $currentScreenDef.AvailableActions } catch { $actionsText = "[ERR]" }
                } elseif ($currentScreenDef.AvailableActions) {
                    $actionsText = $currentScreenDef.AvailableActions
                } else {
                    $actionsText = ""
                }
                if (Measure-StringWidth $actionsText -gt $actionsWidth) { $actionsText = $actionsText.Substring(0, [Math]::Min($actionsText.Length, $actionsWidth - 1)) + "…" }
                $actionListLineView.Text = $actionsText.PadRight($actionsWidth)
                $actionListLineView.FG_Ansi = Get-PmcThemeAnsiCode "ActionListLine.FG"
                $actionListLineView.BG_Ansi = Get-PmcThemeAnsiCode "ActionListLine.BG"
            } else {
                $actionListLineView.Text = ""
            }
        }

        # Render Screen and Process Input
        if ($currentScreenDef.Contains('ProcessKeyPressOverride') -and $currentScreenDef.ProcessKeyPressOverride -is [scriptblock]) {
            # Screen handles its own input loop (e.g., Help Screen)
            if ([Console]::KeyAvailable) {
                $keyInfo = [Console]::ReadKey($true)
                try { & $currentScreenDef.ProcessKeyPressOverride $keyInfo } catch { Handle-Error $_ "executing ProcessKeyPressOverride for screen '$($currentScreenDef.Name)'" }
            } else {
                $null = Show-PmcCurrentScreen # Render if no key pressed
                Start-Sleep -Milliseconds 50
            }
        } else {
            # Standard render and input processing
            $null = Show-PmcCurrentScreen
            if ([Console]::KeyAvailable) {
                $keyInfo = [Console]::ReadKey($true)
                Process-KeyPress -KeyInfo $keyInfo
            } else {
                Start-Sleep -Milliseconds 50
            }
        }
    } # End while ($script:keepRunning)
}
#endregion

#region Initialization and Main Execution
function Start-ProjectManagement {
    $Host.UI.RawUI.WindowTitle = "Project Management Console (v19.2)"
    Load-AppConfig
    if ($null -eq $Global:AppConfig) {
        Write-Error "FATAL: App config failed to load."
        Pause-Screen
        exit 1
    }
    Write-AppLog "--- PMC Application Start (v19.2) ---" "INFO"
    Write-AppLog "Active theme set to '$($script:ActiveThemeName)' ($($script:ActiveTheme.Name))" "INFO"

    if (-not (Initialize-DataDirectory)) {
        Write-Error "FATAL: Data directory init failed."
        Pause-Screen
        exit 1
    }
    if (-not (Load-ExcelMappings)) {
        Write-Error "FATAL: Excel mapping load failed."
        Pause-Screen
        exit 1
    }
    Initialize-Context
    Write-AppLog "Application context initialized." "INFO"

    $script:lastWidth = 0
    $script:lastHeight = 0
    try {
        $script:lastWidth = $Host.UI.RawUI.WindowSize.Width
        $script:lastHeight = $Host.UI.RawUI.WindowSize.Height
        Write-AppLog "Initial console dimensions: W=$script:lastWidth H=$script:lastHeight" "DEBUG"
    } catch {
        Write-AppLog "Failed to get initial console dimensions: $($_.Exception.Message)" "WARN"
        $script:lastWidth = 80
        $script:lastHeight = 25
    }
    Initialize-ConsoleBuffers -Width $script:lastWidth -Height $script:lastHeight
    Write-AppLog "Console buffers initialized." "INFO"

#region Screen Definitions (v19.2 - Settings Implemented)

# --- SCREEN DEFINITIONS (v19.2) ---
# ===============================================
# --- Dashboard Data Sources ---
function Get-UpcomingTodosForDashboard { $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; $today = (Get-Date).Date; $daysAhead = $Global:AppConfig.dashboardUpcomingDays ?? 14; $maxItems = $Global:AppConfig.dashboardMaxTodos ?? 10; $endDate = $today.AddDays($daysAhead); $logFunc.Invoke("Get-UpcomingTodosForDashboard: Today=$today, EndDate=$endDate, MaxItems=$maxItems"); $allProjects = Get-Projects; $upcomingTodos = @(); foreach ($project in $allProjects) { if ($null -eq $project.Todos -or $project.Todos -isnot [array] -or $project.Todos.Count -eq 0) { continue }; foreach ($item in $project.Todos) { if ($item.Status -ne "Pending" -or [string]::IsNullOrEmpty($item.DueDate)) { continue }; $dueDate = $null; if ($item.DueDate -notmatch '^\d{8}$') { continue }; try { $dueDate = [datetime]::ParseExact($item.DueDate, $global:DATE_FORMAT_INTERNAL, $null).Date } catch { continue }; if ($dueDate -ge $today -and $dueDate -le $endDate) { try { $priorityValue = switch($item.Priority){'High'{1}'Normal'{2}'Low'{3}default{4}}; $upcomingTodos += [PSCustomObject]@{ TodoID=$item.TodoID; Task=$item.Task; DueDate=$item.DueDate; Priority=$item.Priority; Status=$item.Status; ProjectID2=$project.ID2; ParsedDueDate=$dueDate; PriorityValue=$priorityValue; OriginalTodo = $item } } catch { Handle-Error $_ "Creating processed Todo object for dashboard (Project: $($project.ID2), Todo: $($item.Task))" } } } }; $sortedUpcoming = @($upcomingTodos | Sort-Object ParsedDueDate, PriorityValue | Select-Object -First $maxItems); $script:DashboardUpcomingTodos = $sortedUpcoming; $script:DashboardUpcomingTodosCount = $sortedUpcoming.Count; $logFunc.Invoke("Get-UpcomingTodosForDashboard: Found $($script:DashboardUpcomingTodosCount) items."); $index = 1; return @($sortedUpcoming | ForEach-Object { [PSCustomObject]@{ Index=$index++; DueDate=(Format-DateSafeDisplay $_.DueDate); Task=$_.Task; ProjectID2=$_.ProjectID2; Priority=$_.Priority; OriginalTodo=$_.OriginalTodo } }) }
function Get-ActiveProjectsForDashboard { $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; $maxItems = $Global:AppConfig.dashboardMaxProjects ?? 10; $projects = Get-Projects | Where-Object { [string]::IsNullOrEmpty($_.CompletedDate) }; $logFunc.Invoke("Get-ActiveProjectsForDashboard: Found $($projects.Count) active projects. MaxItems=$maxItems"); $projectsWithBf = $projects | Where-Object { $_.BFDate -match '^\d{8}$' } | Sort-Object @{Expression = {[datetime]::ParseExact($_.BFDate, $global:DATE_FORMAT_INTERNAL, $null)} }; $projectsWithoutBf = $projects | Where-Object { -not ($_.BFDate -match '^\d{8}$') } | Sort-Object @{Expression = { try { [datetime]::ParseExact($_.AssignedDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { [datetime]::MaxValue } } }; $sortedProjects = @($projectsWithBf) + @($projectsWithoutBf) | Select-Object -First $maxItems; $script:DashboardProjectItems = $sortedProjects; $script:DashboardProjectItemsCount = $sortedProjects.Count; $logFunc.Invoke("Get-ActiveProjectsForDashboard: Returning $($script:DashboardProjectItemsCount) items."); $index = 1; return @($sortedProjects | ForEach-Object { $latestTodoTask = ($_.Todos | Where-Object Status -eq 'Pending' | Sort-Object CreatedDate -Desc | Select-Object -First 1).Task -replace "`n|`r",' '; $latestTodoColWidth = ($global:tableConfig.Columns.DashboardProjects | Where-Object {$_.Title -eq 'Latest Todo'}).Width; $maxLength = [Math]::Max(5, $latestTodoColWidth - 1); if ($latestTodoTask.Length -gt $maxLength) { $latestTodoTask = $latestTodoTask.Substring(0, $maxLength - 1) + "…" }; [PSCustomObject]@{ Index=$index++; ID2=$_.ID2; FullName=$_.FullName; BFDate=(Format-DateSafeDisplay $_.BFDate); LatestTodo=$latestTodoTask; OriginalProject = $_ } }) }
# --- Dashboard Screen ---
$DashboardScreen = @{
    Name = "Dashboard";
    AvailableActions = "[Tab]Focus [Enter]Select [P]rojects [A]dd [M]anage Time [L]Calendar [N]otes [C]ommands [O]ptions [X]Pomodoro [Q]uit ?";
    DefaultFocusViewName = "UpcomingTodosList";
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text=" PROJECT MANAGEMENT CONSOLE - DASHBOARD "; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="PomodoroDisplay"; Type="SegmentDisplayView"; X=-22; Y=0; Width=21; Height=$script:SegmentHeight; HAlign="Right" },
        @{ Name="UpcomingTodosHeader"; Type="LabelView"; X=0; Y=1; Width=-1; Height=1; Text=" --- Upcoming Todos (Next $($Global:AppConfig.dashboardUpcomingDays ?? 14) Days) ---" },
        @{ Name="UpcomingTodosList"; Type="ListView"; X=0; Y=2; Width=-1; Height=($Global:AppConfig.dashboardMaxTodos ?? 10) + 1; ViewType="DashboardTodos"; IsFocusable=$true; TabIndex=1; DataSource = { Get-UpcomingTodosForDashboard }; RowColors = { $script:DashboardUpcomingTodosRowColors = @{}; $today = (Get-Date).Date; for($i = 0; $i -lt $script:DashboardUpcomingTodos.Count; $i++){ $todo = $script:DashboardUpcomingTodos[$i]; $rowHighlightKey = ""; $cellHighlights = @{}; try { if ($todo.DueDate -match '^\d{8}$') { $dueDate = [datetime]::ParseExact($todo.DueDate, $global:DATE_FORMAT_INTERNAL, $null); if ($dueDate.Date -lt $today) { $rowHighlightKey = "Overdue" } elseif (($dueDate.Date - $today).Days -lt 7) { $cellHighlights[1] = "DueSoon" } } } catch {}; $rowColorInfo = @{}; if($rowHighlightKey){ $rowColorInfo = $rowHighlightKey }; if ($cellHighlights.Count -gt 0) { if ($rowColorInfo -is [string]) { $tempKey = $rowColorInfo; $rowColorInfo = @{ "_ROW_KEY_" = $tempKey } }; foreach($cellIdx in $cellHighlights.Keys) { $rowColorInfo["_CELL_$cellIdx"] = $cellHighlights[$cellIdx] } }; if ($rowColorInfo.Keys.Count -gt 0) { $script:DashboardUpcomingTodosRowColors[$i] = $rowColorInfo } }; return $script:DashboardUpcomingTodosRowColors } },
        @{ Name="ActiveProjectsHeader"; Type="LabelView"; X=0; Y=($Global:AppConfig.dashboardMaxTodos ?? 10) + 3; Width=-1; Height=1; Text=" --- Active Projects (BF First) ---" },
        @{ Name="ActiveProjectsList"; Type="ListView"; X=0; Y=($Global:AppConfig.dashboardMaxTodos ?? 10) + 4; Width=-1; Height=-5; ViewType="DashboardProjects"; IsFocusable=$true; TabIndex=2; DataSource = { Get-ActiveProjectsForDashboard }; RowColors = { $script:DashboardProjectItemsRowColors = @{}; $todayInternal = (Get-Date).ToString($global:DATE_FORMAT_INTERNAL); $todayDate = (Get-Date).Date; for($i = 0; $i -lt $script:DashboardProjectItems.Count; $i++){ $proj = $script:DashboardProjectItems[$i]; if ($proj.BFDate -match '^\d{8}$') { if ($proj.BFDate -lt $todayInternal) { $script:DashboardProjectItemsRowColors[$i] = "Overdue" } elseif (($proj.BFDate -eq $todayInternal) -or ([datetime]::ParseExact($proj.BFDate, $global:DATE_FORMAT_INTERNAL, $null).Date -le $todayDate.AddDays(7))) { $script:DashboardProjectItemsRowColors[$i] = @{ "_CELL_3" = "DueSoon" } } } }; return $script:DashboardProjectItemsRowColors } },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-5; Width=-1; Height=1; Text="" },
        @{ Name="InputPromptArea";Type="InputPromptView"; X=0; Y=-4; Width=-1; Height=1 },
        @{ Name="InputArea"; Type="InputView"; X=0; Y=-3; Width=-1; Height=1; IsFocusable=$true },
        @{ Name="StatusLine"; Type="LabelView"; X=0; Y=-2; Width=-1; Height=1; Text="" }
    );
    Actions = @{
        'Q' = { $script:keepRunning = $false; Write-AppLog "Quit action selected." "INFO" };
        'P' = { Set-CurrentScreen -ScreenDefinition $ProjectsListScreen };
        'A' = { Request-ConfirmAction -Prompt "Add Project, Todo, or Time?" -YesOption "P" -YesText "Project" -NoOption "T" -NoText "Todo" -CancelOption "M" -CancelText "Time" -OnConfirm { Add-ManualProject } -OnDeny { $allProjects = Get-Projects | Where-Object { [string]::IsNullOrEmpty($_.CompletedDate) }; if($allProjects.Count -eq 0){ Show-Warning "No active projects to add Todo to."; return }; Select-ItemFromList -Title "ADD TODO - SELECT PROJECT" -Items ($allProjects | Select-Object *, @{N='OriginalProject'; E={$_}}) -ViewType "ProjectSelection" -OnItemSelected { param($selProj, $temp); Add-TodoItemToProject -ProjectObject $selProj.OriginalProject } -OnCancel { Show-Warning "Cancelled." } } -OnCancel { Request-ConfirmAction -Prompt "Add time for Project or Non-Project Task?" -YesOption "P" -YesText "Project" -NoOption "N" -NoText "Non-Project" -CancelOption "0" -CancelText "Cancel" -OnConfirm { Add-ProjectTimeInteractive } -OnDeny { Add-NonProjectTimeInteractive } } };
        'M' = { Set-CurrentScreen -ScreenDefinition $TimeManagementScreen }; # Load handled by screen
        'L' = { Set-CurrentScreen -ScreenDefinition $CalendarScreen };
        'N' = { Set-CurrentScreen -ScreenDefinition $NotesScreen }; # Load handled by screen
        'C' = { Set-CurrentScreen -ScreenDefinition $CommandsScreen }; # Load handled by screen
        'O' = { Set-CurrentScreen -ScreenDefinition $SettingsScreen };
        'X' = { Toggle-Pomodoro };
    };
    ItemCount = { 0 }; # No single item count for dashboard
    HandleItemSelect = { param($selectedItemObject); if ($null -eq $selectedItemObject) { Show-Warning "Invalid item selected."; return }; if ($selectedItemObject.PSObject.Properties.Name -contains 'OriginalTodo') { $originalTodo = $selectedItemObject.OriginalTodo; $parentProject = Get-ProjectById $selectedItemObject.ProjectID2; if ($parentProject -and $originalTodo) { Write-AppLog "Selected Todo from Dashboard: '$($originalTodo.Task)' for action." "INFO"; $script:CurrentDetailProject = $parentProject; $script:RefreshDetailScreen = $true; Set-CurrentScreen -ScreenDefinition $ProjectDetailScreen } else { Show-Warning "Could not find parent project or original Todo object." 5 } } elseif ($selectedItemObject.PSObject.Properties.Name -contains 'OriginalProject') { $fullProjectObject = $selectedItemObject.OriginalProject; if ($fullProjectObject) { Write-AppLog "Item selected on Dashboard: Project $($fullProjectObject.ID2)" "INFO"; $script:CurrentDetailProject = $fullProjectObject; $script:RefreshDetailScreen = $true; Set-CurrentScreen -ScreenDefinition $ProjectDetailScreen } else { Show-Error "Could not find full details for project '$($selectedItemObject.ID2)'." } } else { Show-Warning "Unknown item type selected on Dashboard." } }
}

# --- Projects List Screen ---
$ProjectsListScreen = @{
    Name = "ProjectsListScreen"; # Unique name
    AvailableActions = "[Tab]Focus [Enter]View [A]dd [E]dit [C]omplete [D]elete [T]ime [O]pen [F1]Filter [F2]Sort [0]Back ?";
    BackActionKey = '0'; DefaultFocusViewName = "ProjectListMain";
    OnLoad = { $script:CurrentProjectListTitle = " PROJECTS LIST ($($script:ProjectFilter) / $($script:ProjectSort)) " }; # Update title on load
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text={ $script:CurrentProjectListTitle }; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="ProjectListMain";Type="ListView"; X=0; Y=1; Width=-1; Height=-5; ViewType="ProjectSelection"; IsFocusable=$true;
           DataSource={ $allProjects = Get-Projects; $filtered = if ($script:ProjectFilter -eq 'All') { $allProjects } else { $allProjects | Where-Object { [string]::IsNullOrEmpty($_.CompletedDate) } }; $sortProp = if($script:ProjectSort -eq 'Name'){'FullName'}else{@{Expression = { try { [datetime]::ParseExact($_.BFDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { [datetime]::MaxValue } } }}; $sorted = $filtered | Sort-Object $sortProp; $script:CurrentProjectList = $sorted; $script:CurrentProjectListCount = $sorted.Count; $index = 1; $sorted | Select-Object @{N='Index';E={$script:index++}}, ID2, FullName, @{N='Status'; E={if([string]::IsNullOrEmpty($_.CompletedDate)){"Active"}else{"Done $(Format-DateSafeDisplay $_.CompletedDate)"}}}, @{N='OriginalProject'; E={$_}} };
           RowColors = { $script:CurrentProjectListRowColors = @{}; for($i=0; $i -lt $script:CurrentProjectList.Count; $i++){ if(-not [string]::IsNullOrEmpty($script:CurrentProjectList[$i].CompletedDate)){ $script:CurrentProjectListRowColors[$i] = "Completed" } }; return $script:CurrentProjectListRowColors }
        },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-5; Width=-1; Height=1; Text="" },
        @{ Name="InputPromptArea";Type="InputPromptView"; X=0; Y=-4; Width=-1; Height=1 },
        @{ Name="InputArea"; Type="InputView"; X=0; Y=-3; Width=-1; Height=1; IsFocusable=$true },
        @{ Name="StatusLine"; Type="LabelView"; X=0; Y=-2; Width=-1; Height=1; # Text handled by main loop
           FG_Ansi = { if (-not [string]::IsNullOrEmpty($script:StatusMessage.Text)) { Get-PmcThemeAnsiCode "StatusMessage.Types.$($script:StatusMessage.Type).FG" } else { Get-PmcThemeAnsiCode "StatusLine.FG" } };
           BG_Ansi = { if (-not [string]::IsNullOrEmpty($script:StatusMessage.Text)) { Get-PmcThemeAnsiCode "StatusMessage.Types.$($script:StatusMessage.Type).BG" } else { Get-PmcThemeAnsiCode "StatusLine.BG" } }
        }
    );
    Actions = @{
        '0' = { $null = Navigate-Back };
        'A' = { Add-ManualProject };
        'E' = { $sel = Get-FocusedListViewSelectedItem -ViewName "ProjectListMain"; if($sel){ Set-Project -ProjectContext $sel.OriginalProject } else { Show-Warning "Select a project first."} };
        'C' = { $sel = Get-FocusedListViewSelectedItem -ViewName "ProjectListMain"; if($sel){ Set-ProjectComplete -ProjectContext $sel.OriginalProject } else { Show-Warning "Select a project first."} };
        'D' = { $sel = Get-FocusedListViewSelectedItem -ViewName "ProjectListMain"; if($sel){ Remove-Project -ProjectContext $sel.OriginalProject } else { Show-Warning "Select a project first."} };
        'T' = { $sel = Get-FocusedListViewSelectedItem -ViewName "ProjectListMain"; if($sel){ Add-ProjectTimeInteractive -ProjectContext $sel.OriginalProject } else { Show-Warning "Select a project first."} };
        'O' = { $sel = Get-FocusedListViewSelectedItem -ViewName "ProjectListMain"; if($sel){ Open-ProjectFiles -ProjectContext $sel.OriginalProject } else { Show-Warning "Select a project first."} };
        'V' = { $sel = Get-FocusedListViewSelectedItem -ViewName "ProjectListMain"; if($sel){ $script:CurrentDetailProject = $sel.OriginalProject; $script:RefreshDetailScreen = $true; Set-CurrentScreen -ScreenDefinition $ProjectDetailScreen } else { Show-Warning "Select a project first."} }; # View Details action
        'F1'= { if ($script:ProjectFilter -eq 'All') { $script:ProjectFilter = 'Active' } else { $script:ProjectFilter = 'All' }; $script:CurrentProjectListTitle = " PROJECTS LIST ($($script:ProjectFilter) / $($script:ProjectSort)) "; Show-Info "Filter set to: $($script:ProjectFilter)" 3; Invoke-PmcRenderRequest -ForceRedraw $true };
        'F2'= { if ($script:ProjectSort -eq 'BF') { $script:ProjectSort = 'Name' } else { $script:ProjectSort = 'BF' }; $script:CurrentProjectListTitle = " PROJECTS LIST ($($script:ProjectFilter) / $($script:ProjectSort)) "; Show-Info "Sort set to: $($script:ProjectSort)" 3; Invoke-PmcRenderRequest -ForceRedraw $true };
    };
    ItemCount = { $script:CurrentProjectListCount };
    HandleItemSelect = { param($selectedItemObject); if ($null -eq $selectedItemObject) { Show-Warning "Invalid item selected."; return }; $selectedProj = $selectedItemObject.OriginalProject; if ($selectedProj) { Write-AppLog "Item selected on Project List: Project $($selectedProj.ID2)" "INFO"; $script:CurrentDetailProject = $selectedProj; $script:RefreshDetailScreen = $true; Set-CurrentScreen -ScreenDefinition $ProjectDetailScreen } else { Show-Warning "Invalid project selected or project list not loaded." } }
}

# --- Project Detail Screen ---
$ProjectDetailScreen = @{
    Name = "ProjectDetail";
    AvailableActions = "[Tab]Focus [Enter]Select Todo [E]dit Proj [A]dd Todo [C]omplete Proj [T]ime [O]pen Files [R]emove Proj [0]Back ?";
    BackActionKey = '0'; DefaultFocusViewName = "ProjectTodos";
    OnLoad = {
        Write-AppLog "ProjectDetailScreen OnLoad: Loading data for '$($script:CurrentDetailProject.ID2)'" "DEBUG"
        if ($null -eq $script:CurrentDetailProject) { Write-AppLog "ProjectDetailScreen OnLoad: CurrentDetailProject is null. Navigating back." "WARN"; Show-Error "No project selected for detail view."; Navigate-Back | Out-Null; return }
        $reloadedProject = Get-ProjectById $script:CurrentDetailProject.ID2
        if ($null -eq $reloadedProject) { Write-AppLog "ProjectDetailScreen OnLoad: Failed to reload project '$($script:CurrentDetailProject.ID2)'. Navigating back." "ERROR"; Show-Error "Failed to reload project details."; Navigate-Back | Out-Null; return }
        $script:CurrentDetailProject = $reloadedProject
        $script:CurrentDetailInfoData = @(
            [PSCustomObject]@{ Field = "ID2"; Value = $script:CurrentDetailProject.ID2 },
            [PSCustomObject]@{ Field = "ID1"; Value = $script:CurrentDetailProject.ID1 },
            [PSCustomObject]@{ Field = "Full Name"; Value = $script:CurrentDetailProject.FullName },
            [PSCustomObject]@{ Field = "Assigned"; Value = (Format-DateSafeDisplay $script:CurrentDetailProject.AssignedDate) },
            [PSCustomObject]@{ Field = "Due"; Value = (Format-DateSafeDisplay $script:CurrentDetailProject.DueDate) },
            [PSCustomObject]@{ Field = "BF Date"; Value = (Format-DateSafeDisplay $script:CurrentDetailProject.BFDate) },
            [PSCustomObject]@{ Field = "Status"; Value = $script:CurrentDetailProject.Status },
            [PSCustomObject]@{ Field = "Completed"; Value = (Format-DateSafeDisplay $script:CurrentDetailProject.CompletedDate) },
            [PSCustomObject]@{ Field = "Folder"; Value = $script:CurrentDetailProject.ProjFolder },
            [PSCustomObject]@{ Field = "CAA File"; Value = $script:CurrentDetailProject.CAAName },
            [PSCustomObject]@{ Field = "Request File"; Value = $script:CurrentDetailProject.RequestName },
            [PSCustomObject]@{ Field = "T2020 File"; Value = $script:CurrentDetailProject.T2020 }
        )
        $sortedTodos = @($script:CurrentDetailProject.Todos | Sort-Object @{ Expression = { try { [datetime]::ParseExact($_.DueDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { [datetime]::MaxValue } } }, Status)
        $script:CurrentDetailTodosData = @($sortedTodos | ForEach-Object -Begin {$script:idx=1} -Process {
            $todoItem = $_
            if (-not $todoItem.PSObject.Properties.Name.Contains('TodoID') -or [string]::IsNullOrWhiteSpace($todoItem.TodoID)) {
                Write-AppLog "ProjectDetailScreen OnLoad: Todo '$($todoItem.Task)' missing TodoID. Assigning new one." "WARN"
                $todoItem | Add-Member -MemberType NoteProperty -Name 'TodoID' -Value ([guid]::NewGuid().ToString()) -Force
            }
            $todoItem | Select-Object @{N='Index'; E={$script:idx++}}, Task, @{N='DueDate'; E={Format-DateSafeDisplay $_.DueDate}}, Priority, Status, TodoID, @{N='OriginalTodo'; E={$_}}
        })
        $script:CurrentDetailTodosRowColors = @{}
        $today = (Get-Date).Date
        for($i = 0; $i -lt $sortedTodos.Count; $i++) {
            $todo = $sortedTodos[$i]
            $rowHighlightKey = ""
            $cellHighlights = @{}
            if ($todo.Status -eq "Completed") { $rowHighlightKey = "Completed" }
            else {
                try {
                    if ($todo.DueDate -match '^\d{8}$') {
                        $dueDate = [datetime]::ParseExact($todo.DueDate, $global:DATE_FORMAT_INTERNAL, $null)
                        if ($dueDate.Date -lt $today) { $rowHighlightKey = "Overdue" }
                        elseif (($dueDate.Date - $today).Days -lt 7) { $cellHighlights[2] = "DueSoon" } # DueDate is column index 2
                    }
                } catch {}
            }
            $rowColorInfo = @{}
            if($rowHighlightKey){ $rowColorInfo = $rowHighlightKey }
            if ($cellHighlights.Count -gt 0) {
                if ($rowColorInfo -is [string]) { $tempKey = $rowColorInfo; $rowColorInfo = @{ "_ROW_KEY_" = $tempKey } }
                foreach($cellIdx in $cellHighlights.Keys) { $rowColorInfo["_CELL_$cellIdx"] = $cellHighlights[$cellIdx] }
            }
            if ($rowColorInfo.Keys.Count -gt 0) { $script:CurrentDetailTodosRowColors[$i] = $rowColorInfo }
        }
        # Update TitleBar Text dynamically
        $titleView = $ProjectDetailScreen.Views | Where-Object {$_.Name -eq 'TitleBar'}
        if($titleView){ $titleView.Text = " PROJECT: $($script:CurrentDetailProject.ID2) " }
        Write-AppLog "ProjectDetailScreen OnLoad: Data loaded successfully." "DEBUG"
    };
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text=" PROJECT DETAIL "; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="ProjectInfo"; Type="ListView"; X=0; Y=1; Width=-1; Height=14; ViewType="ProjectInfoDetail"; DataSource={ $script:CurrentDetailInfoData } },
        @{ Name="TodoListHeader"; Type="LabelView"; X=0; Y=15; Width=-1; Height=1; Text=" --- Todos ([Enter]Select, [A]dd) ---" },
        @{ Name="ProjectTodos"; Type="ListView"; X=0; Y=16; Width=-1; Height=-5; ViewType="ProjectTodos"; IsFocusable=$true; DataSource={ $script:CurrentDetailTodosData }; RowColors= { $script:CurrentDetailTodosRowColors } },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-5; Width=-1; Height=1; Text="" },
        @{ Name="InputPromptArea";Type="InputPromptView"; X=0; Y=-4; Width=-1; Height=1 },
        @{ Name="InputArea"; Type="InputView"; X=0; Y=-3; Width=-1; Height=1; IsFocusable=$true },
        @{ Name="StatusLine"; Type="LabelView"; X=0; Y=-2; Width=-1; Height=1; Text="" }
    );
    Actions = @{
        '0' = { $null = Navigate-Back };
        'E' = { Set-Project -ProjectContext $script:CurrentDetailProject };
        'A' = { Add-TodoItemToProject -ProjectObject $script:CurrentDetailProject };
        'C' = { Set-ProjectComplete -ProjectContext $script:CurrentDetailProject };
        'T' = { Add-ProjectTimeInteractive -ProjectContext $script:CurrentDetailProject };
        'O' = { Open-ProjectFiles -ProjectContext $script:CurrentDetailProject };
        'R' = { Remove-Project -ProjectContext $script:CurrentDetailProject }
    };
    ItemCount = { $script:CurrentDetailTodosData.Count };
    HandleItemSelect = {
        param($selectedItemObject)
        if ($null -eq $selectedItemObject) { Show-Warning "Invalid item selected."; return }
        $originalTodo = $selectedItemObject.OriginalTodo
        if ($originalTodo) {
            Write-AppLog "Selected Todo '$($originalTodo.Task)' for action." "INFO";
            Request-ConfirmAction -Prompt "Update or Remove Todo '$($originalTodo.Task)'?" -YesOption "U" -YesText "Update" -NoOption "R" -NoText "Remove" -CancelOption "0" -CancelText "Cancel" -OnConfirm { Update-TodoInProject -ProjectObject $script:CurrentDetailProject -TodoObject $originalTodo } -OnDeny { Remove-TodoFromProject -ProjectObject $script:CurrentDetailProject -TodoObject $originalTodo }
        } else { Show-Warning "Could not find matching original Todo to action." 5 }
    }
}

# --- All Todos Screen ---
$TodosScreen = @{
    Name = "TodosList";
    AvailableActions = "[Tab]Focus [Enter]Update [0]Back ?";
    BackActionKey = '0'; DefaultFocusViewName = "TodoListMain";
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text=" ALL ACTIVE TODOS "; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="TodoListMain"; Type="ListView"; X=0; Y=1; Width=-1; Height=-5; ViewType="Todos"; IsFocusable=$true;
           DataSource={
               $allProjects = Get-Projects; $allActiveTodos = @();
               foreach ($proj in $allProjects | Where-Object { [string]::IsNullOrEmpty($_.CompletedDate) }) {
                   if ($proj.Todos) {
                       $validTodos = $proj.Todos | Where-Object { $_.Status -ne 'Completed' -and $_.PSObject.Properties.Name -contains 'TodoID' }
                       $allActiveTodos += $validTodos | Select-Object *, @{N='ProjectID2'; E={$proj.ID2}}, @{N='OriginalTodo'; E={$_}}
                   }
               }
               $sorted = $allActiveTodos | Sort-Object @{Expression = { try { [datetime]::ParseExact($_.DueDate, $global:DATE_FORMAT_INTERNAL, $null) } catch { [datetime]::MaxValue } } }, @{Expression = { try { [int]$_.Priority } catch { 99 } } };
               $script:CurrentTodoList = $sorted; $script:CurrentTodoListCount = $sorted.Count; $index = 1;
               $sorted | Select-Object @{N='Index';E={$script:index++}}, Task, ProjectID2, @{N='DueDate'; E={Format-DateSafeDisplay $_.DueDate}}, Priority, Status, OriginalTodo
           };
           RowColors = {
               $script:CurrentTodoListRowColors = @{}; $today = (Get-Date).Date;
               for($i=0; $i -lt $script:CurrentTodoList.Count; $i++){
                   $todo = $script:CurrentTodoList[$i]; $rowHighlightKey = ""; $cellHighlights = @{};
                   try {
                       if ($todo.DueDate -match '^\d{8}$') {
                           $dueDate = [datetime]::ParseExact($todo.DueDate, $global:DATE_FORMAT_INTERNAL, $null);
                           if ($dueDate.Date -lt $today) { $rowHighlightKey = "Overdue" }
                           elseif (($dueDate.Date - $today).Days -lt 7) { $cellHighlights[3] = "DueSoon" } # DueDate is column index 3
                       }
                   } catch {};
                   $rowColorInfo = @{}; if($rowHighlightKey){ $rowColorInfo = $rowHighlightKey };
                   if ($cellHighlights.Count -gt 0) {
                       if ($rowColorInfo -is [string]) { $tempKey = $rowColorInfo; $rowColorInfo = @{ "_ROW_KEY_" = $tempKey } };
                       foreach($cellIdx in $cellHighlights.Keys) { $rowColorInfo["_CELL_$cellIdx"] = $cellHighlights[$cellIdx] }
                   }
                   if ($rowColorInfo.Keys.Count -gt 0) { $script:CurrentTodoListRowColors[$i] = $rowColorInfo }
               }
               return $script:CurrentTodoListRowColors
           }
        },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-5; Width=-1; Height=1; Text="" },
        @{ Name="InputPromptArea";Type="InputPromptView"; X=0; Y=-4; Width=-1; Height=1 },
        @{ Name="InputArea"; Type="InputView"; X=0; Y=-3; Width=-1; Height=1; IsFocusable=$true },
        @{ Name="StatusLine"; Type="LabelView"; X=0; Y=-2; Width=-1; Height=1; Text="" }
    );
    Actions = @{ '0' = { $null = Navigate-Back }; };
    ItemCount = { $script:CurrentTodoListCount };
    HandleItemSelect = {
        param($selectedItemObject)
        if ($null -eq $selectedItemObject) { Show-Warning "Invalid item selected."; return }
        $originalTodo = $selectedItemObject.OriginalTodo
        $parentProject = Get-ProjectById $selectedItemObject.ProjectID2
        if ($parentProject -and $originalTodo) {
            Write-AppLog "Selected Todo from All Todos List: '$($originalTodo.Task)' for update." "INFO"
            Update-TodoInProject -ProjectObject $parentProject -TodoObject $originalTodo
        } else { Show-Warning "Could not find parent project or original Todo object." 5 }
    }
}

# --- Time Management Screen ---
$TimeManagementScreen = @{
    Name = "TimeManagementScreen";
    AvailableActions = "[Tab]Focus [Enter]Select [A]dd Proj Time [N]on-Proj Time [E]xport [0]Back ?";
    BackActionKey = '0'; DefaultFocusViewName = "TimeEntryList";
    OnLoad = { Show-TimeEntryManagementScreen }; # This function populates the data source variables
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text=" MANAGE TIME ENTRIES "; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="TimeEntryList"; Type="ListView"; X=0; Y=1; Width=-1; Height=-5; ViewType="TimeManagementList"; IsFocusable=$true;
           DataSource={ $script:CurrentTimeManagementEntries }; # Use pre-loaded data
           RowColors = { $script:CurrentTimeManagementRowColors }
        },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-5; Width=-1; Height=1; Text="" },
        @{ Name="InputPromptArea";Type="InputPromptView"; X=0; Y=-4; Width=-1; Height=1 },
        @{ Name="InputArea"; Type="InputView"; X=0; Y=-3; Width=-1; Height=1; IsFocusable=$true },
        @{ Name="StatusLine"; Type="LabelView"; X=0; Y=-2; Width=-1; Height=1; Text="" }
    );
    Actions = @{
        '0' = { $null = Navigate-Back };
        'A' = { Add-ProjectTimeInteractive };
        'N' = { Add-NonProjectTimeInteractive };
        'E' = { Create-FormattedTimesheet };
    };
    ItemCount = { $script:CurrentTimeManagementCount };
    HandleItemSelect = {
        param($selectedItemObject)
        if ($null -eq $selectedItemObject) { Show-Warning "Invalid item selected."; return }
        $originalEntry = $selectedItemObject.OriginalEntry
        if ($originalEntry) {
            Write-AppLog "Selected Time Entry '$($originalEntry.TimeEntryID)' for action." "INFO"
            Show-TimeEntryActions -Entry $originalEntry
        } else { Show-Warning "Could not find matching original time entry." 5 }
    }
}

# --- Notes Screen ---
$NotesScreen = @{
    Name = "NotesScreen";
    AvailableActions = "[Tab]Focus [Enter]Select [A]dd Note [0]Back ?";
    BackActionKey = '0'; DefaultFocusViewName = "NotesList";
    OnLoad = {
        # Load notes and prepare for display
        if (-not (Initialize-NotesFolder)) { Show-Error "Notes folder could not be initialized."; Navigate-Back | Out-Null; return }
        $noteFiles = @(); try { $noteFiles = @(Get-ChildItem -Path $Global:AppConfig.notesFolder -Filter "*.txt" -File -EA Stop | Sort-Object LastWriteTime -Descending) } catch { Handle-Error $_ "Listing notes from '$($Global:AppConfig.notesFolder)'"; Navigate-Back | Out-Null; return }
        if ($noteFiles.Count -eq 0) {
            # Set empty data source for list view
            $script:SelectionScreenItems = @()
            $script:SelectionScreenItemMap = @{}
            Show-Warning "No notes found. Use [A]dd to create one." 5
        } else {
            # Prepare data for list view
            $script:SelectionScreenItems = @($noteFiles | ForEach-Object -Begin {$idx=1} -Process { [PSCustomObject]@{ Index=$idx++; Item = $_; Name = $_.Name; LastWriteTime = $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") } })
            $script:SelectionScreenItemMap = @{}
            $script:SelectionScreenItems | ForEach-Object { $script:SelectionScreenItemMap[$_.Index] = $_ }
        }
        $script:SelectionScreenViewType = "NoteSelection" # Set view type for list view
        $script:SelectionScreenRowColors = @{} # Reset row colors
    };
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text=" NOTES "; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="NotesList"; Type="ListView"; X=0; Y=1; Width=-1; Height=-5; IsFocusable=$true;
           ViewType = { $script:SelectionScreenViewType }; # Use dynamic view type
           DataSource = { $script:SelectionScreenItems }; # Use data loaded in OnLoad
           RowColors = { $script:SelectionScreenRowColors }
        },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-5; Width=-1; Height=1; Text="" },
        @{ Name="InputPromptArea";Type="InputPromptView"; X=0; Y=-4; Width=-1; Height=1 },
        @{ Name="InputArea"; Type="InputView"; X=0; Y=-3; Width=-1; Height=1; IsFocusable=$true },
        @{ Name="StatusLine"; Type="LabelView"; X=0; Y=-2; Width=-1; Height=1; Text="" }
    );
    Actions = @{
        '0' = { $null = Navigate-Back };
        'A' = { Add-Note }; # Add-Note will refresh the screen via OnLoad if successful
    };
    ItemCount = { $script:SelectionScreenItems.Count };
    HandleItemSelect = {
        param($selectedItemObject)
        if ($null -eq $selectedItemObject) { Show-Warning "Invalid item selected."; return }
        $selectedFileObject = $selectedItemObject.Item
        if ($selectedFileObject) {
            Write-AppLog "Selected Note '$($selectedFileObject.Name)' for action." "INFO"
            Select-And-Action-Note_ActionMenu -SelectedFileObject $selectedFileObject
        } else { Show-Warning "Could not find matching note file." 5 }
    }
}

# --- Commands Screen ---
$CommandsScreen = @{
    Name = "CommandsScreen";
    AvailableActions = "[Tab]Focus [Enter]Select [A]dd Snippet [S]earch [0]Back ?";
    BackActionKey = '0'; DefaultFocusViewName = "CommandsList";
    OnLoad = {
        # Load commands and prepare for display
        if (-not (Initialize-CommandSnippetFolder)) { Show-Error "Command Snippet folder could not be initialized."; Navigate-Back | Out-Null; return }
        $commandFiles = @(); try { $commandFiles = @(Get-ChildItem -Path $Global:AppConfig.commandsFolder -Filter "*.txt" -File -EA Stop | Sort-Object Name) } catch { Handle-Error $_ "Listing command snippets from '$($Global:AppConfig.commandsFolder)'"; Navigate-Back | Out-Null; return }
        if ($commandFiles.Count -eq 0) {
            $script:SelectionScreenItems = @()
            $script:SelectionScreenItemMap = @{}
            Show-Warning "No command snippets found. Use [A]dd to create one." 5
        } else {
            $script:SelectionScreenItems = @($commandFiles | ForEach-Object -Begin {$idx=1} -Process {
                $name = $_.BaseName; $description = "";
                try { $headerLines = Get-Content -Path $_.FullName -TotalCount 3 -Encoding utf8 -EA SilentlyContinue; $descLine = $headerLines | Where-Object { $_ -match '^\s*#\s*Description:\s*(.+)' } | Select-Object -First 1; if ($descLine) { $description = $matches[1].Trim() } } catch {};
                [PSCustomObject]@{ Index=$idx++; Item = $_; BaseName = $name; FullName=$_.FullName; Description = $description }
            })
            $script:SelectionScreenItemMap = @{}
            $script:SelectionScreenItems | ForEach-Object { $script:SelectionScreenItemMap[$_.Index] = $_ }
        }
        $script:SelectionScreenViewType = "CommandSelection"
        $script:SelectionScreenRowColors = @{}
    };
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text=" COMMAND SNIPPETS "; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="CommandsList"; Type="ListView"; X=0; Y=1; Width=-1; Height=-5; IsFocusable=$true;
           ViewType = { $script:SelectionScreenViewType };
           DataSource = { $script:SelectionScreenItems };
           RowColors = { $script:SelectionScreenRowColors }
        },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-5; Width=-1; Height=1; Text="" },
        @{ Name="InputPromptArea";Type="InputPromptView"; X=0; Y=-4; Width=-1; Height=1 },
        @{ Name="InputArea"; Type="InputView"; X=0; Y=-3; Width=-1; Height=1; IsFocusable=$true },
        @{ Name="StatusLine"; Type="LabelView"; X=0; Y=-2; Width=-1; Height=1; Text="" }
    );
    Actions = @{
        '0' = { $null = Navigate-Back };
        'A' = { Add-CommandSnippet };
        'S' = { Search-CommandSnippets };
    };
    ItemCount = { $script:SelectionScreenItems.Count };
    HandleItemSelect = {
        param($selectedItemObject)
        if ($null -eq $selectedItemObject) { Show-Warning "Invalid item selected."; return }
        $selectedFileObject = $selectedItemObject.Item
        if ($selectedFileObject) {
            Write-AppLog "Selected Command Snippet '$($selectedFileObject.Name)' for action." "INFO"
            Select-And-Action-CommandSnippet_ActionMenu -SelectedFileObject $selectedFileObject -Description $selectedItemObject.Description
        } else { Show-Warning "Could not find matching command snippet file." 5 }
    }
}

# --- Settings Screen (v19.2 - Functional) ---
$SettingsScreen = @{
    Name = "SettingsScreen";
    AvailableActions = "[Tab]Navigate [Enter]Edit/Select [S]Save [0]Cancel ?";
    BackActionKey = '0'; DefaultFocusViewName = "Setting1Input";
    OnLoad = { Load-SettingsScreenData }; # Load data into $script:TempSettings
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text=" APPLICATION SETTINGS "; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },

        # CAA Template Path
        @{ Name="Setting1Label"; Type="LabelView"; X=1; Y=2; Width=25; Height=1; Text=" CAA Template Path:" },
        @{ Name="Setting1Input"; Type="InputView"; X=27; Y=2; Width=-28; Height=1; IsFocusable=$true; TabIndex=1;
           DataSource = { $script:TempSettings.caaTemplatePath ?? "" } # Read from TempSettings
           # Enter key handled by Process-NormalModeKey
        },

        # Log Max Size
        @{ Name="Setting2Label"; Type="LabelView"; X=1; Y=4; Width=25; Height=1; Text=" Log Max Size (MB):" },
        @{ Name="Setting2Input"; Type="InputView"; X=27; Y=4; Width=10; Height=1; IsFocusable=$true; TabIndex=2;
           DataSource = { ($script:TempSettings.logMaxSizeMB ?? 10).ToString() } # Read from TempSettings
           # Enter key handled by Process-NormalModeKey
        },

        # Default Theme
        @{ Name="ThemeLabel"; Type="LabelView"; X=1; Y=6; Width=25; Height=1; Text=" Default Theme:" },
        @{ Name="ThemeSelector"; Type="ButtonView"; X=27; Y=6; Width=-28; Height=1; IsFocusable=$true; TabIndex=3;
           Text = { " $($script:TempSettings.defaultTheme ?? 'None') " }; # Read from TempSettings
           OnClick = { Select-SettingsTheme } # Trigger theme selection list
        },

        # Save/Cancel Buttons
        @{ Name="SaveButton"; Type="ButtonView"; X=5; Y=-4; Width=15; Height=1; Text="Save"; IsFocusable=$true; TabIndex=4;
           OnClick={ Save-SettingsChanges } # Call save function
        },
        @{ Name="CancelButton"; Type="ButtonView"; X=25; Y=-4; Width=15; Height=1; Text="Cancel"; IsFocusable=$true; TabIndex=5;
           OnClick={ $script:TempSettings = $null; Navigate-Back | Out-Null } # Discard temp settings and go back
        },

        # Standard Footer Views
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-3; Width=-1; Height=1; Text="" },
        @{ Name="InputPromptArea";Type="InputPromptView"; X=0; Y=-2; Width=-1; Height=1 }, # For potential future input
        @{ Name="StatusLine"; Type="LabelView"; X=0; Y=-1; Width=-1; Height=1; Text="" }
    );
    Actions = @{
        '0' = { $script:TempSettings = $null; Navigate-Back | Out-Null }; # Cancel action
        'S' = { Save-SettingsChanges } # Save action
    };
    ItemCount = { 0 }; # No list items
    HandleItemSelect = $null # No list view
}

# --- Help Screen ---
$HelpScreen = @{
    Name = "HelpScreen";
    AvailableActions = "[Any Key] Close";
    BackActionKey = '0'; # Not used due to override
    Views = @(
        @{ Name="HelpBackground"; Type="LabelView"; X=4; Y=2; Width=-8; Height=-4; Text=""; BG_Ansi = { Get-PmcThemeAnsiCode "HelpOverlay.BG" } },
        @{ Name="HelpBorder"; Type="LabelView"; X=4; Y=2; Width=-8; Height=-4; Text=""; RenderOverride = { param($viewDef); Draw-BoxToBuffer -X $viewDef.X -Y $viewDef.Y -Width $viewDef.Width -Height $viewDef.Height -BorderStyle "Double" -FG_Ansi (Get-PmcThemeAnsiCode "HelpOverlay.FG") -BG_Ansi (Get-PmcThemeAnsiCode "HelpOverlay.BG") } },
        @{ Name="HelpTitle"; Type="LabelView"; X=5; Y=3; Width=-10; Height=1; HAlign="Center"; Text=" --- HELP --- "; FG_Ansi = { Get-PmcThemeAnsiCode "HelpOverlay.FG" }; BG_Ansi = { Get-PmcThemeAnsiCode "HelpOverlay.BG" } },
        @{ Name="HelpContent"; Type="LabelView"; X=5; Y=5; Width=-10; Height=-8; Text = { $logFunc = { param($Msg, $Lvl="DEBUG") Write-AppLog $Msg $Lvl }; $logFunc.Invoke("Rendering HelpContent. Text: '$($script:HelpScreenText)'", "TRACE"); $helpContent = $script:HelpScreenText -split "`n"; $boxWidth = $script:BufferWidth - 12; $maxHeight = $script:BufferHeight - 10; $wrappedLines = @(); foreach($line in $helpContent) { $wrappedLines += Get-TextWrapped -Text $line -Width $boxWidth -BreakOnWords $true }; if ($wrappedLines.Count -gt $maxHeight) { $wrappedLines = $wrappedLines | Select-Object -First ($maxHeight -1); $wrappedLines += " ... (more help available)".PadRight($boxWidth) }; $paddedLines = $wrappedLines | ForEach-Object { $_.PadRight($boxWidth) }; return $paddedLines -join "`n" }; FG_Ansi = { Get-PmcThemeAnsiCode "HelpOverlay.FG" }; BG_Ansi = { Get-PmcThemeAnsiCode "HelpOverlay.BG" } },
        @{ Name="HelpClosePrompt"; Type="LabelView"; X=5; Y=-5; Width=-10; Height=1; HAlign="Center"; Text=" [ Press any key to close ] "; FG_Ansi = { Get-PmcThemeAnsiCode "HelpOverlay.FG" }; BG_Ansi = { Get-PmcThemeAnsiCode "HelpOverlay.BG" } }
    );
    Actions = @{ }; # No standard actions
    ProcessKeyPressOverride = {
        param($KeyInfo)
        Write-AppLog "HelpScreen: Any key pressed, navigating back." "DEBUG"
        Navigate-Back | Out-Null
    }
}

# --- Selection Screen ---
$SelectionScreen = @{
    Name = "SelectionScreen";
    AvailableActions = {
        $actions = "[Up/Down/PgUp/PgDn]Navigate [Enter]Select"
        if ($script:SelectionScreenTotalPages -gt 1) {
            if ($script:SelectionScreenPage -gt 0) { $actions += " [98]Prev" }
            if ($script:SelectionScreenPage -lt ($script:SelectionScreenTotalPages - 1)) { $actions += " [99]Next" }
        }
        $actions += " [0/Esc]Cancel ?"
        return $actions
    };
    PromptContextLabel = { $script:SelectionScreenPrompt };
    BackActionKey = '0'; DefaultFocusViewName = "SelectionList";
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text= { " $($script:SelectionScreenTitle) " }; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="PageInfo"; Type="LabelView"; X=0; Y=1; Width=-1; Height=1; HAlign="Center"; Text= { if($script:SelectionScreenTotalPages -gt 1){ "Page $($script:SelectionScreenPage + 1) of $($script:SelectionScreenTotalPages)" } else { "" } } },
        @{ Name="SelectionList"; Type="ListView"; X=0; Y=2; Width=-1; Height=-3; IsFocusable=$true;
           ViewType= { $script:SelectionScreenViewType };
           DataSource= { $script:SelectionScreenItems };
           RowColors = { $script:SelectionScreenRowColors }
        },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-3; Width=-1; Height=1; Text="" }
    );
    Actions = @{
        '0' = { Process-KeyPress -KeyInfo ([System.ConsoleKeyInfo]::new($null, [System.ConsoleKey]::Escape, $false, $false, $false)) }; # Simulate Escape
        '98' = { if ($script:SelectionScreenPage -gt 0) { $script:SelectionScreenPage--; Update-SelectionScreenPagedData; $script:InputState.CurrentSelectionIndex = 0; Update-SelectionScreenRowColors; Invoke-PmcRenderRequest -ForceRedraw $true } };
        '99' = { if ($script:SelectionScreenPage -lt ($script:SelectionScreenTotalPages - 1)) { $script:SelectionScreenPage++; Update-SelectionScreenPagedData; $script:InputState.CurrentSelectionIndex = 0; Update-SelectionScreenRowColors; Invoke-PmcRenderRequest -ForceRedraw $true } }
    };
    ItemCount = { $script:SelectionScreenItems.Count };
    HandleItemSelect = { # This is called when Enter is pressed on the list view
        param($selectedItemObject)
        if ($null -eq $selectedItemObject) { Show-Warning "Invalid item selected."; return }
        Write-AppLog "SelectionMode confirmed item via Enter." "DEBUG"
        $onSelectCallback = $script:SelectionScreenOnItemSelected
        $tempDataFromSelection = $script:TempDataForSelection
        Reset-InputState; Navigate-Back | Out-Null # Reset state and go back BEFORE calling callback
        if ($onSelectCallback -ne $null) {
            try { & $onSelectCallback $selectedItemObject $tempDataFromSelection } catch { Handle-Error $_ "executing SelectionScreen OnItemSelected callback" }
        }
    }
}

# --- Display List Screen (Non-interactive List) ---
$DisplayListScreen = @{
    Name = "DisplayListScreen";
    AvailableActions = "[0]Close ?";
    BackActionKey = '0'; DefaultFocusViewName = "DisplayList";
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text= { " $($script:SelectionScreenTitle) " }; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="DisplayList"; Type="ListView"; X=0; Y=1; Width=-1; Height=-3; IsFocusable=$false; # Not focusable
           ViewType= { $script:SelectionScreenViewType };
           DataSource= { $script:SelectionScreenItems };
           RowColors = { $script:SelectionScreenRowColors }
        },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-3; Width=-1; Height=1; Text="" }
    );
    Actions = @{ '0' = { $null = Navigate-Back } };
    ItemCount = { 0 }; # Not relevant for selection
    HandleItemSelect = $null # Not selectable
}

# --- Calendar Screen ---
$CalendarScreen = @{
    Name = "CalendarScreen";
    AvailableActions = "[Left/Right] Prev/Next Month [0]Back ?";
    BackActionKey = '0';
    DefaultFocusViewName = "CalendarView"; # Calendar itself isn't focusable yet
    OnLoad = { $script:CalendarCurrentMonth = (Get-Date).Date }; # Reset to current month on load
    Views = @(
        @{ Name="TitleBar"; Type="LabelView"; X=0; Y=0; Width=-1; Height=1; HAlign="Center"; Text={ " CALENDAR - $($script:CalendarCurrentMonth.ToString("MMMM yyyy")) " }; FG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.FG" '97' }; BG_Ansi = { Get-PmcThemeAnsiCode "WindowTitle.BG" '44' } },
        @{ Name="CalendarView"; Type="CalendarView"; X=0; Y=1; Width=-1; Height=-3; IsFocusable=$false; },
        @{ Name="ActionListLine"; Type="LabelView"; X=0; Y=-3; Width=-1; Height=1; Text="" },
        @{ Name="StatusLine"; Type="LabelView"; X=0; Y=-2; Width=-1; Height=1; Text="" }
    );
    Actions = @{ '0' = { $null = Navigate-Back }; };
    ItemCount = { 0 }; # No list items
    HandleItemSelect = $null; # No item selection yet
    ProcessKeyPressOverride = {
        param([System.ConsoleKeyInfo]$KeyInfo)
        $redraw = $false
        if ($KeyInfo.Key -eq 'LeftArrow') {
            $script:CalendarCurrentMonth = $script:CalendarCurrentMonth.AddMonths(-1)
            Write-AppLog "Calendar: Navigated to previous month: $($script:CalendarCurrentMonth.ToString('yyyy-MM'))" "DEBUG"
            $redraw = $true
        } elseif ($KeyInfo.Key -eq 'RightArrow') {
            $script:CalendarCurrentMonth = $script:CalendarCurrentMonth.AddMonths(1)
            Write-AppLog "Calendar: Navigated to next month: $($script:CalendarCurrentMonth.ToString('yyyy-MM'))" "DEBUG"
            $redraw = $true
        } elseif ($KeyInfo.Key -eq 'Escape' -or $KeyInfo.KeyChar -eq '0') {
            Navigate-Back | Out-Null
        } elseif ($KeyInfo.KeyChar -eq '?') {
             $helpText = $CalendarScreen.AvailableActions; $script:HelpScreenText = $helpText; Set-CurrentScreen -ScreenDefinition $HelpScreen
        }
        if ($redraw) { Invoke-PmcRenderRequest -ForceRedraw $true }
    }
}
# ===============================================
# --- End SCREEN DEFINITIONS ---
# ===============================================

#endregion Screen Definitions

    # --- Prepare Console and Start Main UI Loop ---
    $originalCursorVisible = $true
    try {
        try { $originalCursorVisible = [System.Console]::CursorVisible } catch { Write-Warning "Could not get initial console cursor visibility." }
        try { [System.Console]::CursorVisible = $false } catch { Write-Warning "Failed to hide cursor using [System.Console]." }
        Write-AppLog "Host cleared and cursor hidden before main loop." "DEBUG"
        Show-MainMenu
    } catch {
        $script:ScriptErrored = $true
        Write-Error "An unexpected critical error occurred in the main execution scope: $($_.Exception.Message)"
        Write-Error $_.ScriptStackTrace
        if (Get-Command 'Write-AppLog' -ErrorAction SilentlyContinue) { Write-AppLog "CRITICAL UNHANDLED ERROR (Main Scope): $($_.Exception.ToString())" "ERROR" }
    } finally {
        Write-Host "`n--- Cleaning up ---" -ForegroundColor Yellow
        try { Write-Host "Making cursor visible (using [Console])..."; [System.Console]::CursorVisible = $originalCursorVisible } catch { $errMsg = "Cursor visibility restore failed: $($_.Exception.Message)"; Write-Warning $errMsg; if (Get-Command 'Write-AppLog' -ErrorAction SilentlyContinue) { Write-AppLog $errMsg "WARN" } }
        try { Write-Host "Resetting ANSI..."; Write-Host $global:ansiReset } catch { $errMsg = "ANSI reset failed: $($_.Exception.Message)"; Write-Warning $errMsg; if (Get-Command 'Write-AppLog' -ErrorAction SilentlyContinue) { Write-AppLog $errMsg "WARN" } }
        Write-Host "Application finished." -ForegroundColor Green
    }

} # <<<===### CLOSING BRACE for Start-ProjectManagement ###===>>>
#endregion

# =============================================================
# Main Script Execution Call
# =============================================================
Start-ProjectManagement

# Final pause after the function returns and cleanup is done
if ($script:ScriptErrored) { Read-Host "Errors occurred during execution. Press Enter to exit." } else { Read-Host "Press Enter to exit." }
# =============================================================
# END: pmc19_corrected_v2.ps1
# =============================================================
